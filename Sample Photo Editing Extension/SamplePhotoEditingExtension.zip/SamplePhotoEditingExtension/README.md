# Sample Photo Editing Extension

This sample shows how to implement a Photo Editing extension. This extension allows the user to select a filter effect to apply to the photo or video selected in Photos or Camera.

Note that the app in this sample only serves as a host for the extension. To use the sample extension, edit a photo or video using the Photos app, and tap the extension icon.

## Requirements

### Build

iOS 8 SDK

### Runtime

iOS 8 or later

Copyright (C) 2014 Apple Inc. All rights reserved.
