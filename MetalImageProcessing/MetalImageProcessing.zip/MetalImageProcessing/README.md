# MetalImageProcessing

This sample shows how to load a texture into a 2D Quad and perform a simple grayscale conversion compute post processing pass using Metal.

## Requirements

### Build

iOS 8 SDK

### Runtime

iOS 8 on A7 based devices

Copyright (C) 2014 Apple Inc. All rights reserved.
