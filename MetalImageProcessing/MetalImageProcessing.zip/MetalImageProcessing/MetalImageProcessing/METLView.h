/*
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 
  Simple Metal view class.
  
 */

#import <UIKit/UIKit.h>

@interface METLView : UIView

@end
