/*
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 
  Metal render view controller class.
  
 */

#import <UIKit/UIKit.h>

@interface METLViewController : UIViewController

@end
