/*
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 
  Metal render view controller class.
  
 */

#import <string.h>

#import <Metal/Metal.h>
#import <QuartzCore/CAMetalLayer.h>
#import <simd/simd.h>

#import "METLTransforms.h"
#import "METLTexture.h"
#import "METLView.h"

#import "METLViewController.h"

static const float kUIInterfaceOrientationLandscapeAngle = 35.0f;
static const float kUIInterfaceOrientationPortraitAngle  = 50.0f;

static const float kPrespectiveNear = 0.1f;
static const float kPrespectiveFar  = 100.0f;

static const uint32_t kSzSIMDFloat4x4 = sizeof(simd::float4x4);

static const uint32_t kCntQuadTexCoords = 6;
static const uint32_t kSzQuadTexCoords  = kCntQuadTexCoords * sizeof(simd::float2);

static const uint32_t kCntQuadVertices = kCntQuadTexCoords;
static const uint32_t kSzQuadVertices  = kCntQuadVertices * sizeof(simd::float4);

static const simd::float4 kQuadVertices[kCntQuadVertices] =
{
    { -1.0f,  -1.0f, 0.0f, 1.0f },
    {  1.0f,  -1.0f, 0.0f, 1.0f },
    { -1.0f,   1.0f, 0.0f, 1.0f },
    
    {  1.0f,  -1.0f, 0.0f, 1.0f },
    { -1.0f,   1.0f, 0.0f, 1.0f },
    {  1.0f,   1.0f, 0.0f, 1.0f }
};

static const simd::float2 kQuadTexCoords[kCntQuadTexCoords] =
{
    { 0.0f, 0.0f },
    { 1.0f, 0.0f },
    { 0.0f, 1.0f },
    
    { 1.0f, 0.0f },
    { 0.0f, 1.0f },
    { 1.0f, 1.0f }
};

// Only allow 3 command buffers in flight at any given time.
static const uint32_t kInFlightCommandBuffers = 3;
static const uint32_t kMaxBufferBytesPerFrame = kSzSIMDFloat4x4;

@implementation METLViewController
{
@private
    // Interface Orientation
    UIInterfaceOrientation  mnOrientation;
    
    // Renderer globals
    id <MTLDevice>             m_Device;
    id <MTLCommandQueue>       m_CommandQueue;
    id <MTLLibrary>            m_ShaderLibrary;
    id <MTLDepthStencilState>  m_DepthState;
    
    // App control
    CADisplayLink               *mpTimer;
    dispatch_semaphore_t   m_InflightSemaphore;
    
    // textured Quad
    METLTexture                   *mpInTexture;
    id <MTLTexture>                m_OutTexture;
    id <MTLRenderPipelineState>    m_PipelineState;
    id <MTLSamplerState>           m_QuadSampler;
    id <MTLBuffer>                 m_VertexBuffer;
    id <MTLBuffer>                 m_TexCoordBuffer;
    id <MTLComputePipelineState>   m_Kernel;
    
    // Dimensions
    CGSize  m_Size;
    CGRect  m_Bounds;
    float   m_Aspect;
    
    // Vertex buffer
    float m_Vertices[24];
    
    // Viewing matrix is derived from an eye point, a reference point
    // indicating the center of the scene, and an up vector.
    simd::float4x4 m_LookAt;
    
    // Translate the object in (x,y,z) space.
    simd::float4x4 m_Translate;
    
    // Quad transform buffers
    simd::float4x4  m_Transform;
    id <MTLBuffer>  m_TransformBuffer;
    
    // Framebuffer/drawable
    MTLViewport   m_Viewport;
    CAMetalLayer *mpRenderingLayer;
    
    // Clear values
    MTLClearValue m_ClearColor;
    MTLClearValue m_ClearDepth;
    
    // Compute sizes
    MTLSize m_WorkgroupSize;
	MTLSize m_WorkgroupCount;
}

- (void) _cleanUp
{
    mpInTexture       = nil;
    m_OutTexture      = nil;
    m_PipelineState   = nil;
    m_Kernel          = nil;
    m_ShaderLibrary   = nil;
    m_TexCoordBuffer  = nil;
    m_VertexBuffer    = nil;
    m_QuadSampler     = nil;
    m_TransformBuffer = nil;
    m_DepthState      = nil;
    m_CommandQueue    = nil;
    m_Device          = nil;
    mpRenderingLayer  = nil;
    
    if(mpTimer)
    {
        [mpTimer invalidate];
    } // if
    
    mpTimer = nil;
} // _cleanUp

- (void) dealloc
{
    [self _cleanUp];
} // dealloc

- (BOOL) _setup:(NSString *)texStr
            ext:(NSString *)extStr
{
    NSError *pError = nil;
    
    m_ShaderLibrary = [m_Device newDefaultLibrary];
    
    if(!m_ShaderLibrary)
    {
        NSLog(@">> ERROR: Failed creating a shared library!");
        
        return NO;
    } // if
    
    // Create a compute kernel function
    id <MTLFunction> function = [m_ShaderLibrary newFunctionWithName:@"grayscale"];

    if(!function)
    {
        return NO;
    } // if

    // Create a compute kernel
    m_Kernel = [m_Device newComputePipelineStateWithFunction:function
                                                       error:&pError];

    if(!m_Kernel)
    {
        NSLog(@">> ERROR - Failed creating a compute kernel: %@", pError);
        
        return NO;
    } // if
    
    // load the fragment program into the library
    id <MTLFunction> fragment_program = [m_ShaderLibrary newFunctionWithName:@"texturedQuadFragment"];
    
    if(!fragment_program)
    {
        NSLog(@">> ERROR: Failed creating a fragment shader!");
        
        return NO;
    } // if
    
    // load the vertex program into the library
    id <MTLFunction> vertex_program = [m_ShaderLibrary newFunctionWithName:@"texturedQuadVertex"];
    
    if(!vertex_program)
    {
        NSLog(@">> ERROR: Failed creating a vertex shader!");
        
        return NO;
    } // if
    
    //  create a pipeline state for the quad
    MTLRenderPipelineDescriptor *pQuadPipelineStateDescriptor = [MTLRenderPipelineDescriptor new];
    
    if(!pQuadPipelineStateDescriptor)
    {
        NSLog(@">> ERROR: Failed creating a pipeline state descriptor!");
        
        return NO;
    } // if
    
    [pQuadPipelineStateDescriptor setPixelFormat:MTLPixelFormatBGRA8Unorm
                                         atIndex:MTLFramebufferAttachmentIndexColor0];
    
    [pQuadPipelineStateDescriptor setPixelFormat:MTLPixelFormatDepth32Float
                                         atIndex:MTLFramebufferAttachmentIndexDepth];
    
    [pQuadPipelineStateDescriptor setVertexFunction:vertex_program];
    [pQuadPipelineStateDescriptor setFragmentFunction:fragment_program];
    
    [pQuadPipelineStateDescriptor setDepthWriteEnabled: YES];
    
    m_PipelineState = [m_Device newRenderPipelineStateWithDescriptor:pQuadPipelineStateDescriptor
                                                               error:&pError];
    
    pQuadPipelineStateDescriptor = nil;
    
    vertex_program   = nil;
    fragment_program = nil;
    
    if(!m_PipelineState)
    {
        NSLog(@">> ERROR: Failed acquiring pipeline state descriptor: %@", pError);
        
        return NO;
    } // if
    
    // _setup the vertex buffers
    m_VertexBuffer = [m_Device newBufferWithBytes:kQuadVertices
                                           length:kSzQuadVertices
                                          options:MTLResourceOptionCPUCacheModeDefault];
    
    if(!m_VertexBuffer)
    {
        NSLog(@">> ERROR: Failed creating a vertex buffer for a quad!");
        
        return NO;
    } // if
    
    m_TexCoordBuffer = [m_Device newBufferWithBytes:kQuadTexCoords
                                             length:kSzQuadTexCoords
                                            options:MTLResourceOptionCPUCacheModeDefault];
    
    if(!m_TexCoordBuffer)
    {
        NSLog(@">> ERROR: Failed creating a 2d texture coordinate buffer!");
        
        return NO;
    } // if
    
    mpInTexture = [[METL2DTexture alloc] initWithResourceName:texStr
                                                  extension:extStr];
    
    BOOL isAcquired = [mpInTexture finalize:m_Device];
    
    if(!isAcquired)
    {
        NSLog(@">> ERROR: Failed creating an input 2d texture!");
        
        return NO;
    } // if
    
    m_Size.width  = mpInTexture.width;
    m_Size.height = mpInTexture.height;
    
    MTLTextureDescriptor *pTexDesc = [MTLTextureDescriptor texture2DDescriptorWithPixelFormat:MTLPixelFormatRGBA8Unorm
                                                                                        width:m_Size.width
                                                                                       height:m_Size.height
                                                                                    mipmapped:NO];
    
    if(!pTexDesc)
    {
        return NO;
    } // if
    
    m_OutTexture = [m_Device newTextureWithDescriptor:pTexDesc];
    
    pTexDesc = nil;
    
    if(!m_OutTexture)
    {
        NSLog(@">> ERROR: Failed creating an output 2d texture!");
        
        return NO;
    } // if
    
    // Set the compute kernel's workgroup size and count
    m_WorkgroupSize  = MTLSizeMake(1, 1, 1);
	m_WorkgroupCount = MTLSizeMake(m_Size.width, m_Size.height, 1);
    
    // create a sampler for the quad
    MTLSamplerDescriptor *pSamplerDescriptor = [MTLSamplerDescriptor new];
    
    if(!pSamplerDescriptor)
    {
        NSLog(@">> ERROR: Failed creating a sampler descriptor!");
        
        return NO;
    } // if
    
    pSamplerDescriptor.minFilter             = MTLSamplerMinMagFilterNearest;
    pSamplerDescriptor.magFilter             = MTLSamplerMinMagFilterNearest;
    pSamplerDescriptor.mipFilter             = MTLSamplerMipFilterNotMipmapped;
    pSamplerDescriptor.maxAnisotropy         = 1.0f;
    pSamplerDescriptor.sAddressMode          = MTLSamplerAddressModeClampToEdge;
    pSamplerDescriptor.tAddressMode          = MTLSamplerAddressModeClampToEdge;
    pSamplerDescriptor.rAddressMode          = MTLSamplerAddressModeClampToEdge;
    pSamplerDescriptor.normalizedCoordinates = YES;
    pSamplerDescriptor.lodMinClamp           = 0;
    pSamplerDescriptor.lodMaxClamp           = FLT_MAX;
    
    m_QuadSampler = [m_Device newSamplerStateWithDescriptor:pSamplerDescriptor];
    
    pSamplerDescriptor = nil;
    
    if(!m_QuadSampler)
    {
        NSLog(@">> ERROR: Failed creating a sampler state descriptor!");
        
        return NO;
    } // if
    
    MTLDepthStencilDescriptor *pDepthStateDesc = [MTLDepthStencilDescriptor new];
    
    if(!pDepthStateDesc)
    {
        NSLog(@">> ERROR: Failed creating a depth stencil descriptor!");
        
        return NO;
    } // if
    
    pDepthStateDesc.depthCompareFunction = MTLCompareFunctionAlways;
    pDepthStateDesc.depthWriteEnabled    = YES;
    
    m_DepthState = [m_Device newDepthStencilStateWithDescriptor:pDepthStateDesc];
    
    pDepthStateDesc = nil;
    
    if(!m_DepthState)
    {
        NSLog(@">> ERROR: Failed creating a depth stencil state descriptor!");
        
        return NO;
    } // if
    
    // allocate regions of memory for the constant buffer
    m_TransformBuffer = [m_Device newBufferWithLength:kMaxBufferBytesPerFrame
                                              options:0];
    
    if(!m_TransformBuffer)
    {
        NSLog(@">> ERROR: Failed creating a transform buffer!");
        
        return NO;
    } // if
    
    m_TransformBuffer.label = @"TransformBuffer";
    
    // Initialize vertices
    memcpy(m_Vertices, kQuadVertices, kSzQuadVertices);
    
    return YES;
} // _setupWithTexture

- (BOOL) _setup
{
    return [self _setup:@"Default"
                    ext:@"jpg"];
} // _setup

- (BOOL) _start
{
    // Default orientation is unknown
    mnOrientation = UIInterfaceOrientationUnknown;
    
    // grab the CAALayer created by the nib
    METLView *pRenderView = (METLView *)self.view;
    
    mpRenderingLayer = (CAMetalLayer *)pRenderView.layer;
    
    if(!mpRenderingLayer)
    {
        NSLog(@">> ERROR: Failed acquring Core Animation Metal layer!");
        
        return NO;
    } // if
    
    mpRenderingLayer.presentsWithTransaction = NO;
    mpRenderingLayer.drawsAsynchronously     = YES;
    
    CGRect viewBounds = mpRenderingLayer.frame;
    
    MTLViewport viewport = {0.0f, 0.0f, viewBounds.size.width, viewBounds.size.height, 0.0f, 1.0f};
    
    m_Viewport = viewport;
    
    // set a background color to make sure the layer appears
    CGColorSpaceRef pColorSpace = CGColorSpaceCreateDeviceRGB();
    
    if(pColorSpace != NULL)
    {
        CGFloat components[4] = {0.5, 0.5, 0.5, 1.0};
        
        CGColorRef pGrayColor = CGColorCreate(pColorSpace,components);
        
        if(pGrayColor != NULL)
        {
            mpRenderingLayer.backgroundColor = pGrayColor;
            
            CFRelease(pGrayColor);
        } // if
        
        CFRelease(pColorSpace);
    } // if
    
    // find a usable Device
    m_Device = MTLCreateSystemDefaultDevice();
    
    if(!m_Device)
    {
        NSLog(@">> ERROR: Failed creating a default system device!");
        
        return NO;
    } // if
    
    // set the device on the rendering layer and provide a pixel format
    mpRenderingLayer.device          = m_Device;
    mpRenderingLayer.pixelFormat     = MTLPixelFormatBGRA8Unorm;
    mpRenderingLayer.framebufferOnly = YES;
    
    // create a new command queue
    m_CommandQueue = [m_Device newCommandQueue];
    
    if(!m_CommandQueue)
    {
        NSLog(@">> ERROR: Failed creating a new command queue!");
        
        return NO;
    } // if
    
    m_ClearColor = MTLClearValueMakeColor(0.65f, 0.65f, 0.65f, 1.0f);
    m_ClearDepth = MTLClearValueMakeDepth(1.0);
    
    // Create a viewing matrix derived from an eye point, a reference point
    // indicating the center of the scene, and an up vector.
    simd::float3 eye    = {0.0, 0.0, 0.0};
    simd::float3 center = {0.0, 0.0, 1.0};
    simd::float3 up     = {0.0, 1.0, 0.0};
    
    m_LookAt = METL::lookAt(eye, center, up);
    
    // Translate the object in (x,y,z) space.
    m_Translate = METL::translate(0.0f, -0.25f, 2.0f);
    
    return YES;
} // _start

- (void) _transform
{
    // Based on the device orientation, set the angle in degrees
    // between a plane which passes through the camera position
    // and the top of your screen and another plane which passes
    // through the camera position and the bottom of your screen.
    float dangle = 0.0f;
    
    m_Aspect = fabsf(m_Bounds.size.width / m_Bounds.size.height);
    
    switch(mnOrientation)
    {
        case UIInterfaceOrientationLandscapeLeft:
        case UIInterfaceOrientationLandscapeRight:
            dangle   = kUIInterfaceOrientationLandscapeAngle;
            break;
            
        case UIInterfaceOrientationPortrait:
        case UIInterfaceOrientationPortraitUpsideDown:
        default:
            dangle   = kUIInterfaceOrientationPortraitAngle;
            break;
    } // switch
    
    // Describes a tranformation matrix that produces a perspective projection
    const float near   = kPrespectiveNear;
    const float far    = kPrespectiveFar;
    const float rangle = METL::radians(dangle);
    const float length = near * tanf(rangle);
    
    float right   = length/m_Aspect;
    float left    = -right;
    float top     = length;
    float bottom  = -top;
    
    simd::float4x4 perspective = METL::frustum_oc(left, right, bottom, top, near, far);
    
    // Create a viewing matrix derived from an eye point, a reference point
    // indicating the center of the scene, and an up vector.
    m_Transform = m_LookAt * m_Translate;
    
    // Create a linear _transformation matrix
    m_Transform = perspective * m_Transform;
    
    // Update the buffer associated with the linear _transformation matrix
    float *pTransform = (float *)[m_TransformBuffer contents];
    
    memcpy(pTransform, &m_Transform, kSzSIMDFloat4x4);
} // _transform

- (void) _quad
{
    // Determine the scaled bounds for th quad
    float sx = 1.0f;
    float sy = 1.0f;
    
    // If the texture bounds are not equal (i.e., aspect ratio is
    // different than 1), determine the scaled quad bounds
    if(m_Size.width != m_Size.height)
    {
        float aspect = 1.0f/m_Aspect;
        
        sx = aspect * m_Size.width / m_Bounds.size.width;
        sy = m_Size.height / m_Bounds.size.height;
    } // else
    
    // Set the (x,y) bounds of the quad
    
    // First triangle
    m_Vertices[0] = -sx;
    m_Vertices[1] = -sy;
    
    m_Vertices[4] =  sx;
    m_Vertices[5] = -sy;
    
    m_Vertices[8] = -sx;
    m_Vertices[9] =  sy;
    
    // Second triangle
    m_Vertices[12] =  sx;
    m_Vertices[13] = -sy;
    
    m_Vertices[16] = -sx;
    m_Vertices[17] =  sy;
    
    m_Vertices[20] =  sx;
    m_Vertices[21] =  sy;
    
    // Update the vertex buffer with the quad bounds
    float *pVertices = (float *)[m_VertexBuffer contents];
    
    memcpy(pVertices, m_Vertices, sizeof(m_Vertices));
} // _quad

- (void) _update
{
    // To correctly compute the aspect ration determine the device
    // interface orientation.
    UIInterfaceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation;
    
    // Update the quad and linear _transformation matrices, if and
    // only if, the device orientation is changed.
    if(mnOrientation != orientation)
    {
        // Update the device orientation
        mnOrientation = orientation;
        
        // Get the bounds for the current rendering layer
        m_Bounds = mpRenderingLayer.frame;
        
        // Determine the linear transformation matrix
        [self _transform];
        
        // Generate a quad with correct aspect ratios
        [self _quad];
    } // if
} // _update

- (id <MTLFramebuffer>) _framebuffer:(id <MTLCommandBuffer>)commandBuffer
                            drawable:(id <CAMetalDrawable>)drawable
{
    MTLAttachmentDescriptor *pColorAttachment
    = [MTLAttachmentDescriptor attachmentDescriptorWithTexture:drawable.texture];
    
    [pColorAttachment setLoadAction:MTLLoadActionClear];
    [pColorAttachment setClearValue:m_ClearColor];
    
    // create a framebuffer with a color and depth attachment
    MTLTextureDescriptor *pDepthTexDesc
    = [MTLTextureDescriptor texture2DDescriptorWithPixelFormat:MTLPixelFormatDepth32Float
                                                         width:m_Viewport.width
                                                        height:m_Viewport.height
                                                     mipmapped:NO];
    
    id<MTLTexture> depthTex
    = [m_CommandQueue.device newTextureWithDescriptor:pDepthTexDesc];
    
    MTLAttachmentDescriptor *pDepthAttachment
    = [MTLAttachmentDescriptor attachmentDescriptorWithTexture:depthTex];
    
    [pDepthAttachment setLoadAction:MTLLoadActionClear];
    [pDepthAttachment setClearValue:m_ClearDepth];
    
    MTLFramebufferDescriptor *pFramebufferDescriptor
    = [MTLFramebufferDescriptor framebufferDescriptorWithColorAttachment:pColorAttachment
                                                         depthAttachment:pDepthAttachment
                                                       stencilAttachment:nil];
    
    pColorAttachment = nil;
    pDepthAttachment = nil;
    pDepthTexDesc    = nil;
    
    return [commandBuffer.device newFramebufferWithDescriptor:pFramebufferDescriptor];
} // _framebuffer

- (void) _compute:(id <MTLCommandBuffer>)commandBuffer
{
	id <MTLComputeCommandEncoder> computeEncoder = [commandBuffer computeCommandEncoder];

	[computeEncoder setComputePipelineState:m_Kernel];

	[computeEncoder setTexture:mpInTexture.texture
                       atIndex: 0];

	[computeEncoder setTexture:m_OutTexture
                       atIndex:1];

	[computeEncoder executeKernelWithWorkGroupSize:m_WorkgroupSize
                                    workGroupCount:m_WorkgroupCount];

    [computeEncoder endEncoding];

    computeEncoder = nil;
} // compute

- (void) _encode:(id <MTLRenderCommandEncoder>)renderEncoder
{
    // set context state with the render encoder
    [renderEncoder setViewport:m_Viewport];
    [renderEncoder setFrontFacingWinding:MTLWindingCounterClockwise];
    [renderEncoder setDepthStencilState:m_DepthState];
    
    [renderEncoder setRenderPipelineState:m_PipelineState];
    
    [renderEncoder setVertexBuffer:m_VertexBuffer
                            offset:0
                           atIndex:0 ];
    
    [renderEncoder setVertexBuffer:m_TexCoordBuffer
                            offset:0
                           atIndex:1 ];
    
    [renderEncoder setVertexBuffer:m_TransformBuffer
                            offset:0
                           atIndex:2 ];
    
    [renderEncoder setFragmentTexture:m_OutTexture
                              atIndex:0];
    
    [renderEncoder setFragmentSamplerState:m_QuadSampler
                                   atIndex:0];
    
    // tell the render context we want to draw our primitives
    [renderEncoder drawPrimitives:MTLPrimitiveTypeTriangle
                      vertexStart:0
                      vertexCount:6
                    instanceCount:1];
    
    [renderEncoder endEncoding];
} // _encode

- (void) _render:(id <MTLCommandBuffer>)commandBuffer
        drawable:(id <CAMetalDrawable>)drawable
{
    // Get a framebuffer
    id <MTLFramebuffer> framebuffer = [self _framebuffer:commandBuffer
                                                drawable:drawable];
    
    // Get a render encoder
    id <MTLRenderCommandEncoder>  renderEncoder = [commandBuffer renderCommandEncoderWithFramebuffer:framebuffer];
    
    // Encode into a renderer
    [self _encode:renderEncoder];
    
    // Discard renderer and framebuffer
    renderEncoder = nil;
    framebuffer   = nil;
} // _render

- (void) _dispatch:(id <MTLCommandBuffer>)commandBuffer
{
    __block dispatch_semaphore_t dispatchSemaphore = m_InflightSemaphore;
    
    [commandBuffer addCompletedHandler:^(id <MTLCommandBuffer> cmdb){
        dispatch_semaphore_signal(dispatchSemaphore);
    }];
} // _dispatch

- (void) _commit:(id <MTLCommandBuffer>)commandBuffer
        drawable:(id <CAMetalDrawable>)drawable
{
    [commandBuffer addScheduledPresent:drawable];
    [commandBuffer commit];
} // commit

- (void) render:(id)sender
{
    dispatch_semaphore_wait(m_InflightSemaphore, DISPATCH_TIME_FOREVER);
    
    [self _update];
    
    id <CAMetalDrawable>  drawable      = [mpRenderingLayer newDrawable];
    id <MTLCommandBuffer> commandBuffer = [m_CommandQueue commandBuffer];
    
    [self _compute:commandBuffer];
    
    [self _render:commandBuffer
         drawable:drawable];
    
    [self _dispatch:commandBuffer];
    
    [self _commit:commandBuffer
         drawable:drawable];
    
    commandBuffer = nil;
    drawable      = nil;
} // render

- (void) viewDidLoad
{
    [super viewDidLoad];
    
    if(![self _start])
    {
        NSLog(@">> ERROR: Failed initializations!");
        
        [self _cleanUp];
        
        exit(-1);
    } // if
    else
    {
        if(![self _setup])
        {
            NSLog(@">> ERROR: Failed creating assets!");
            
            [self _cleanUp];
            
            exit(-1);
        } // if
        else
        {
            m_InflightSemaphore = dispatch_semaphore_create(kInFlightCommandBuffers);
            
            // as the timer fires, we render
            mpTimer = [CADisplayLink displayLinkWithTarget:self selector:@selector(render:)];
            [mpTimer addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSDefaultRunLoopMode];
            
        } // else
    } // else
} // viewDidLoad

- (void) didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
    if([self isViewLoaded] && ([[self view] window] == nil))
    {
        self.view = nil;
        
        [self _cleanUp];
    } // if
} // didReceiveMemoryWarning

@end
