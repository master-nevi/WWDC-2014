/*
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 
         Presents a UIImageView along with an Action button to share the UIImage contained in the UIImageView.
      
 */

#import <UIKit/UIKit.h>

@interface AAPLImageShareVC : UIViewController

@end
