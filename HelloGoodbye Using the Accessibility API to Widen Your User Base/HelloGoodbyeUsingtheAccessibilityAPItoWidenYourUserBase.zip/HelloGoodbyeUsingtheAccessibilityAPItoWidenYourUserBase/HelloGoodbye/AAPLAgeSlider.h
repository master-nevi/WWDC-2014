/*
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 
  A custom slider that allows users to adjust their age.
  
 */

@import UIKit;

@interface AAPLAgeSlider : UISlider

@end
