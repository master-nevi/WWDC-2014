/*
    Copyright (C) 2014 Apple Inc. All Rights Reserved.
    See LICENSE.txt for this sample’s licensing information
    
    Abstract:
    
                Main source for this sample. Defines the application delegate class and begins the application run loop.
            
 */


// The symbols from the 'Foundation' framework are available by default.
// Use the ObjC.import() method load other frameworks and make their
// symbols available.

ObjC.import('Cocoa')


// Define the application delegate; it will be a subclass of NSObject.
// This class must be registered before the MainMenu.xib is loaded,
// because the xib contains a serialized instance of the AppDelegate
// class.

var appDelegateDefinition = {
    name: 'AAPLAppDelegate',
    protocols: ['NSApplicationDelegate'],
    properties: {
        window: 'id',
        expressionString: 'id',
    },
    methods: {
        'applicationDidFinishLaunching:': function (notification) {
            this.expressionString = "Math.PI * 2"
        },
        'eval:': {
            types: [ 'void', ['id']],
            implementation: function (sender) {
                var result = eval(this.expressionString.js)
                this.expressionString = JSON.stringify(result) || "undefined"
            },
        },
    },
}


// Register the subclass with the Objective-C runtime. The class can now be
// instantiated.

ObjC.registerSubclass(appDelegateDefinition)


// Tell Cocoa to perform the usual Cocoa application setup, including loading
// the MainMenu.xib. This function ends up running a run loop, and does
// not return.

$.NSApplicationMain(0, undefined)