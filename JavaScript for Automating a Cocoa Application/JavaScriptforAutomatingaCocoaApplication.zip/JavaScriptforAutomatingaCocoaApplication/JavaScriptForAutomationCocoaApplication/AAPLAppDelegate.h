/*
    Copyright (C) 2014 Apple Inc. All Rights Reserved.
    See LICENSE.txt for this sample’s licensing information
    
    Abstract:
    
                 Supporting header for this sample. This interface allows Interface Builder to know about the application delegate's IBOutlets and IBActions. It is not used for compilation, or at runtime.
            
 */

@interface AAPLAppDelegate : NSObject

@property IBOutlet NSWindow *window;

- (IBAction)eval:(id)sender;

@end