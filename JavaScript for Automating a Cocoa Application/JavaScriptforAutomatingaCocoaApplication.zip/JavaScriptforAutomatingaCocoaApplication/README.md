# JavaScript for Automation Cocoa Application

This sample shows how to use an Xcode project to build a Cocoa application written entirely in JavaScript for Automation.  The project includes a build phase which compiles the main script using 'osacompile' and then copies the compiled script and its supporting resources into an application bundle.  The script itself implements an application delegate, demonstrating the interaction between the application object, the nib elements, and the classes defined in the script file.

## Requirements

### Build

Xcode 6.0, OS X 10.10 SDK

### Runtime

OS X 10.10 or later

Copyright (C) 2014 Apple Inc. All rights reserved.
