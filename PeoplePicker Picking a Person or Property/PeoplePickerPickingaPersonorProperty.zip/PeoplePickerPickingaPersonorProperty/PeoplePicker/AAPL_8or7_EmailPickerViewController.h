/*
    Copyright (C) 2014 Apple Inc. All Rights Reserved.
    See LICENSE.txt for this sample’s licensing information
    
    Abstract:
    
                The view controller class used for the fourth tab in our tab bar controller.
            
 */

@import UIKit;


@interface AAPL_8or7_EmailPickerViewController : UIViewController

@end

