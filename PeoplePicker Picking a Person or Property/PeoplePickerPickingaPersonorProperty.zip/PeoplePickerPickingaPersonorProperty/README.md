# PeoplePicker: Using AddressBookUI

A more thorough description of "Shows how to use the AddressBookUI framework to pick contacts."

## Requirements

### Build

iOS 8 SDK and Xcode 6

### Runtime

iOS 7

Copyright (C) 2014 Apple Inc. All rights reserved.
