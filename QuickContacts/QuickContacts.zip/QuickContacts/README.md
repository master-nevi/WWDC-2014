# QuickContacts: Browse, Edit, Create Contacts with AddressBookUI

QuickContacts demonstrates how to use the Address Book UI controllers and properties such as displayedProperties, allowsAddingToAddressBook, and displayPerson. It shows how to browse a list of Address Book contacts, display and edit a contact record, create a new contact record, and update a partial contact record.

## Requirements

### Build

iOS 8 SDK and Xcode 6

### Runtime

iOS 8 SDK

Copyright (C) 2014 Apple Inc. All rights reserved.
