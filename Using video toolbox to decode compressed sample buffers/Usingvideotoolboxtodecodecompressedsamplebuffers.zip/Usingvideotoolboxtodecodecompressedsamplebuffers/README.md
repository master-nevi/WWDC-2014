# Using video toolbox to decode compressed sample buffers

VideoTimeline shows how to use VTDecompressionSession to get direct access to the hardware video decoder on iOS. This sample demonstrates how to decode compresed sample buffers to CVPixelBuffers and draw them using OpenGLES. This sample is ARC-enabled.

## Requirements

### Build

iOS 8 SDK

### Runtime

iOS 8 or later

Copyright (C) 2014 Apple Inc. All rights reserved.
