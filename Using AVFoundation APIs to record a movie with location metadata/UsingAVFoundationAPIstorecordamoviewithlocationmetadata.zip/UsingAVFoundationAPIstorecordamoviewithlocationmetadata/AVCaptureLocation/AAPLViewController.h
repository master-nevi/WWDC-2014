/*
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 
 View controller for the camera interface and selecting location capture mode.
  
 */

@import UIKit;

@interface AAPLViewController : UIViewController

@end
