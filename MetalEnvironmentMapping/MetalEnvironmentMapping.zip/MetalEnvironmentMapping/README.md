# MetalEnvironmentMapping

This sample demonstrates environment mapping by combining 2D mipmap PVRTC textures, cube map textures and lighting in Metal.

## Requirements

### Build

iOS 8

### Runtime

iOS 8, A7 devices

Copyright (C) 2014 Apple Inc. All rights reserved.
