/*
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 
  Metal Renderer for Metal Envinroment mapping sample. Acts as the update and render delegate for the view controller and performs rendering. In Metal environment mapping sample, a cubemap is rendered, and a textured quad is rendered reflecting the cubemap. This demonstrates the use of mipmap pvrtc textures in Metal and cubemap textures in Metal.
  
 */

#import "METLRenderer.h"
#import "METLViewController.h"
#import "METLView.h"
#import "METLSharedTypes.h"
#import "METLPVRTexture.h"
#import "METLTransforms.h"

#import <simd/simd.h>

static const long kMaxBufferBytesPerFrame = 1024*1024;
static const long kInFlightCommandBuffers = 3;

static const float kFOVY          = 65.0f;
static const simd::float3 kEye    = {0.0f, 0.0f, 0.0f};
static const simd::float3 kCenter = {0.0f, 0.0f, 1.0f};
static const simd::float3 kUp     = {0.0f, 1.0f, 0.0f};

static const float kQuadWidth  = 1.0f;
static const float kQuadHeight = 1.0f;
static const float kQuadDepth  = 1.0f;

static const float quad[] =
{
    // verticies (xyz), normal (xyz), texCoord (uv)
    kQuadWidth, -kQuadHeight, -kQuadDepth,  0.0,  0.0, -1.0,  1.0, 1.0,
    -kQuadWidth, -kQuadHeight, -kQuadDepth, 0.0,  0.0, -1.0,  0.0, 1.0,
    -kQuadWidth, kQuadHeight, -kQuadDepth,  0.0,  0.0, -1.0,  0.0, 0.0,
    kQuadWidth, kQuadHeight, -kQuadDepth,   0.0,  0.0, -1.0,  1.0, 0.0,
    kQuadWidth, -kQuadHeight, -kQuadDepth,  0.0,  0.0, -1.0,  1.0, 1.0,
    -kQuadWidth, kQuadHeight, -kQuadDepth,  0.0,  0.0, -1.0,  0.0, 0.0
};

static const simd::float4 cubeVertexData[] =
{
    // posx
    { -1.0f,  1.0f,  1.0f, 1.0f },
    { -1.0f, -1.0f,  1.0f, 1.0f },
    { -1.0f,  1.0f, -1.0f, 1.0f },
    { -1.0f, -1.0f, -1.0f, 1.0f },
    
    // negz
    { -1.0f,  1.0f, -1.0f, 1.0f },
    { -1.0f, -1.0f, -1.0f, 1.0f },
    { 1.0f,  1.0f, -1.0f, 1.0f },
    { 1.0f, -1.0f, -1.0f, 1.0f },
    
    // negx
    { 1.0f,  1.0f, -1.0f, 1.0f },
    { 1.0f, -1.0f, -1.0f, 1.0f },
    { 1.0f,  1.0f,  1.0f, 1.0f },
    { 1.0f, -1.0f,  1.0f, 1.0f },
    
    // posz
    { 1.0f,  1.0f,  1.0f, 1.0f },
    { 1.0f, -1.0f,  1.0f, 1.0f },
    { -1.0f,  1.0f,  1.0f, 1.0f },
    { -1.0f, -1.0f,  1.0f, 1.0f },
    
    // posy
    { 1.0f,  1.0f, -1.0f, 1.0f },
    { 1.0f,  1.0f,  1.0f, 1.0f },
    { -1.0f,  1.0f, -1.0f, 1.0f },
    { -1.0f,  1.0f,  1.0f, 1.0f },
    
    // negy
    { 1.0f, -1.0f,  1.0f, 1.0f },
    { 1.0f, -1.0f, -1.0f, 1.0f },
    { -1.0f, -1.0f,  1.0f, 1.0f },
    { -1.0f, -1.0f, -1.0f, 1.0f },
};

@implementation METLRenderer
{
    id <MTLDevice> _device;
    id <MTLCommandQueue> _commandQueue;
    id <MTLLibrary> _defaultLibrary;
    
    dispatch_semaphore_t _inflight_semaphore;
    id <MTLBuffer> _dynamicUniformBuffer[kInFlightCommandBuffers];
    
    // model shader constants
    float _rotation;
    METL::uniforms_t _uniform_buffer;
    
    // offsets into unifomr buffer
    size_t _quad_constant_vertexbuffer_offset;
    size_t _skybox_constant_vertexbuffer_offset;
    size_t _quad_invertedViewMatrix_fragmentbuffer_offset;
    
    // render stage
    id <MTLRenderPipelineState> _pipelineState;
    id <MTLBuffer> _vertexBuffer;
    id <MTLDepthStencilState> _depthState;
    
    // global transform data
    simd::float4x4 _projectionMatrix;
    simd::float4x4 _viewMatrix;
    simd::float4x4 _inverted_view_matrix;
    
    // skybox
    METLTexture *_skyboxTex;
    id <MTLRenderPipelineState> _skyboxPipelineState;
    id <MTLSamplerState> _skyboxSampler;
    id <MTLBuffer> _skyboxVertexBuffer;
    simd::float4x4 _skybox_modelview_projection_matrix;
    float _skyboxRotation;
    
    // texturedQuad
    METLTexture *_quadTex;
    id <MTLRenderPipelineState> _quadPipelineState;
    id <MTLSamplerState> _quadSampler;
    id <MTLBuffer> _quadVertexBuffer;
    id <MTLBuffer> _quadNormalBuffer;
    id <MTLBuffer> _quadTexCoordBuffer;
}

- (void)dealloc
{
    // discard hints to destroy objects right away on dealloc
    _device = nil;
    _commandQueue = nil;
    _defaultLibrary = nil;
    
    for (int i = 0; i < kInFlightCommandBuffers; i++)
        _dynamicUniformBuffer[i] = nil;
    
    _pipelineState = nil;
    _vertexBuffer = nil;
    _depthState = nil;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        
        _sampleCount = 4;
        _depthPixelFormat = MTLPixelFormatDepth32Float;
        _stencilPixelFormat = MTLPixelFormatInvalid;
        
        // find a usable Device
        _device = MTLCreateSystemDefaultDevice();
        
        // create a new command queue
        _commandQueue = [_device newCommandQueue];
    
        _defaultLibrary = [_device newDefaultLibrary];
        if(!_defaultLibrary) {
            NSLog(@">> ERROR: Couldnt create a default shader library");
            
            // assert here becuase if the shader libary isnt loading, shaders arent compiling
            assert(0);
        }
        
        _constantDataBufferIndex = 0;
        _inflight_semaphore = dispatch_semaphore_create(kInFlightCommandBuffers);
    }
    return self;
}

#pragma mark RENDER VIEW DELEGATE METHODS

- (void)_loadQuadAssets
{
    // read the vertex and fragment shader functions from the library
    id <MTLFunction> vertexProgram = [_defaultLibrary newFunctionWithName:@"reflectQuadVertex"];
    id <MTLFunction> fragmentProgram = [_defaultLibrary newFunctionWithName:@"reflectQuadFragment"];
    
    //  create a pipeline state descriptor for the quad
    MTLRenderPipelineDescriptor *quadPipelineStateDescriptor = [[MTLRenderPipelineDescriptor alloc] init];
    quadPipelineStateDescriptor.label = @"EnvironmentMapPipelineState";
    
    // set pixel formats that match the framebuffer we are drawing into
    [quadPipelineStateDescriptor setPixelFormat:MTLPixelFormatBGRA8Unorm atIndex:MTLFramebufferAttachmentIndexColor0];
    [quadPipelineStateDescriptor setPixelFormat:MTLPixelFormatDepth32Float atIndex:MTLFramebufferAttachmentIndexDepth];
    [quadPipelineStateDescriptor setSampleCount:_sampleCount];
    
    // set the vertex and fragment programs
    [quadPipelineStateDescriptor setVertexFunction:vertexProgram];
    [quadPipelineStateDescriptor setFragmentFunction:fragmentProgram];
    
    // enable depth
    [quadPipelineStateDescriptor setDepthWriteEnabled: YES];
    
    // generate the pipeline state
    _quadPipelineState = [_device newRenderPipelineStateWithDescriptor:quadPipelineStateDescriptor error:nil];
    
    // setup the skybox vertex, texCoord and normal buffers
    _quadVertexBuffer = [_device newBufferWithBytes:quad length:sizeof(quad) options:MTLResourceOptionCPUCacheModeDefault];
    _quadVertexBuffer.label = @"EnvironmentMapVertexBuffer";
}

- (void)_loadSkyboxAssets
{
    id <MTLFunction> vertexProgram = [_defaultLibrary newFunctionWithName:@"skyboxVertex"];
    id <MTLFunction> fragmentProgram = [_defaultLibrary newFunctionWithName:@"skyboxFragment"];
    
    //  create a pipeline state for the skybox
    MTLRenderPipelineDescriptor *skyboxPipelineStateDescriptor = [[MTLRenderPipelineDescriptor alloc] init];
    skyboxPipelineStateDescriptor.label = @"SkyboxPipelineState";
    
    // the pipeline state must match the drawable framebuffer we are rendering into
    [skyboxPipelineStateDescriptor setPixelFormat:MTLPixelFormatBGRA8Unorm atIndex:MTLFramebufferAttachmentIndexColor0];
    [skyboxPipelineStateDescriptor setPixelFormat:MTLPixelFormatDepth32Float atIndex:MTLFramebufferAttachmentIndexDepth];
    [skyboxPipelineStateDescriptor setSampleCount:_sampleCount];
    
    // attach the skybox shaders to the pipeline state
    [skyboxPipelineStateDescriptor setVertexFunction:vertexProgram];
    [skyboxPipelineStateDescriptor setFragmentFunction:fragmentProgram];
    
    // enable depth
    [skyboxPipelineStateDescriptor setDepthWriteEnabled: YES];
    
    // finally, read out the pipeline state
    _skyboxPipelineState = [_device newRenderPipelineStateWithDescriptor:skyboxPipelineStateDescriptor error:nil];
    
    // create the skybox vertex buffer
    _skyboxVertexBuffer = [_device newBufferWithBytes:cubeVertexData length:sizeof(cubeVertexData) options:MTLResourceOptionCPUCacheModeDefault];
    _skyboxVertexBuffer.label = @"SkyboxVertexBuffer";
}

- (void)loadAssets
{
    // allocate one region of memory for the constant buffer
    for (int i = 0; i < kInFlightCommandBuffers; i++)
    {
        _dynamicUniformBuffer[i] = [_device newBufferWithLength:kMaxBufferBytesPerFrame options:0];
        _dynamicUniformBuffer[i].label = [NSString stringWithFormat:@"ConstantBuffer%i", i];
    }
    
    // load the quad's pipeline state and buffer data
    [self _loadQuadAssets];
    
    // load the skybox pipeline state and buffer data
    [self _loadSkyboxAssets];
    
    // read a mipmapped pvrtc encoded texture
    _quadTex = [[METLPVRTexture alloc] initWithResourceName:@"copper_mipmap_4" extension:@"pvr"];
    BOOL loaded = [_quadTex loadIntoTextureWithDevice:_device];
    if (!loaded)
        NSLog(@"failed to load PVRTC Texture for quad");
    
    // load the skybox
    _skyboxTex = [[METLTextureCubeMap alloc] initWithResourceName:@"skybox" extension:@"png"];
    loaded = [_skyboxTex loadIntoTextureWithDevice:_device];
    if (!loaded)
        NSLog(@"failed to load skybox texture");
    
    // create a sampler for the mipmapped 2d texture
    MTLSamplerDescriptor *desc = [[MTLSamplerDescriptor alloc] init];
    desc.minFilter = MTLSamplerMinMagFilterLinear;
    desc.magFilter = MTLSamplerMinMagFilterLinear;
    desc.mipFilter = MTLSamplerMipFilterLinear;
    _quadSampler = [_device newSamplerStateWithDescriptor:desc];
    
    // create a sampler for the skybox texture
    desc = [[MTLSamplerDescriptor alloc] init];
    desc.minFilter = MTLSamplerMinMagFilterLinear;
    desc.magFilter = MTLSamplerMinMagFilterLinear;
    _skyboxSampler = [_device newSamplerStateWithDescriptor:desc];
    
    // setup the depth state
    MTLDepthStencilDescriptor *depthStateDesc = [[MTLDepthStencilDescriptor alloc] init];
    depthStateDesc.depthCompareFunction = MTLCompareFunctionAlways;
    depthStateDesc.depthWriteEnabled = YES;
    _depthState = [_device newDepthStencilStateWithDescriptor:depthStateDesc];
}

- (void)_renderSkybox:(id <MTLRenderCommandEncoder>)renderEncoder view:(METLView *)view name:(NSString *)name
{
    // setup for GPU debugger
    [renderEncoder pushDebugGroup:name];
    
    // set the pipeline state object for the quad which contains its precompiled shaders
    [renderEncoder setRenderPipelineState:_skyboxPipelineState];
    
    // set the vertex buffers for the skybox at both indicies 0 and 1 since we are using its vertices as texCoords in the shader
    [renderEncoder setVertexBuffer:_skyboxVertexBuffer offset:0 atIndex:SKYBOX_VERTEX_INDEX];
    [renderEncoder setVertexBuffer:_skyboxVertexBuffer offset:0 atIndex:SKYBOX_TEXCOORD_INDEX];
    
    // set the model view projection matrix for the skybox
    [renderEncoder setVertexBuffer:_dynamicUniformBuffer[_constantDataBufferIndex] offset:_skybox_constant_vertexbuffer_offset atIndex:SKYBOX_CONSTANT_BUFFER];
    
    // set the fragment shader's texture and sampler
    [renderEncoder setFragmentTexture:_skyboxTex.texture atIndex:SKYBOX_IMAGE_TEXTURE];
    [renderEncoder setFragmentSamplerState:_skyboxSampler atIndex:SKYBOX_IMAGE_SAMPLER];
    
    for (int i = 0; i < 6; ++i)
        [renderEncoder drawPrimitives: MTLPrimitiveTypeTriangleStrip vertexStart: i * 4 vertexCount: 4];
    
    [renderEncoder popDebugGroup];
}

- (void)_renderTexturedQuad:(id <MTLRenderCommandEncoder>)renderEncoder view:(METLView *)view name:(NSString *)name
{
    // setup for GPU debugger
    [renderEncoder pushDebugGroup:name];
    
    // set the pipeline state object for the skybox which contains its precompiled shaders
    [renderEncoder setRenderPipelineState:_quadPipelineState];
    
    // set the static vertex buffers
    [renderEncoder setVertexBuffer:_quadVertexBuffer offset:0 atIndex:QUAD_VERTEX_INDEX];
    
    // read the model view project matrix data from the constant buffer
    [renderEncoder setVertexBuffer:_dynamicUniformBuffer[_constantDataBufferIndex] offset:_quad_constant_vertexbuffer_offset atIndex:QUAD_CONSTANT_BUFFER];
    
    // fragment texture for environment
    [renderEncoder setFragmentTexture:_skyboxTex.texture atIndex:QUAD_ENVMAP_TEXTURE];
    
    // fragment texture for image to be mixed with reflection
    [renderEncoder setFragmentTexture:_quadTex.texture atIndex:QUAD_IMAGE_TEXTURE];
    
    // samplers for reading from the skybox and quad textures
    [renderEncoder setFragmentSamplerState:_skyboxSampler atIndex:QUAD_ENVMAP_SAMPLER];
    [renderEncoder setFragmentSamplerState:_quadSampler atIndex:QUAD_IMAGE_SAMPLER];
    
    // inverted view matrix fragment buffer for environment mapping
    [renderEncoder setFragmentBuffer:_dynamicUniformBuffer[_constantDataBufferIndex] offset:_quad_invertedViewMatrix_fragmentbuffer_offset atIndex:QUAD_INVERTED_VIEW_FRAG_BUFFER];
    
    // tell the render context we want to draw our primitives
    [renderEncoder drawPrimitives:MTLPrimitiveTypeTriangle vertexStart:0 vertexCount:6 instanceCount:1];
    
    [renderEncoder popDebugGroup];
}

- (void)render:(METLView *)view
{
    dispatch_semaphore_wait(_inflight_semaphore, DISPATCH_TIME_FOREVER);
    
    // prepare assets
    [self _prepareToDraw:view];
    
    // create a new command buffer for each renderpass to the current drawable
    id <MTLCommandBuffer> commandBuffer = [_commandQueue commandBuffer];
    
    // create a render command encoder so we can render into something
    id <MTLRenderCommandEncoder> renderEncoder = [commandBuffer renderCommandEncoderWithFramebuffer:view.currentFramebuffer];
    [renderEncoder setDepthStencilState:_depthState];
    
    // render the skybox and the quad
    [self _renderSkybox:renderEncoder view:view name:@"skybox"];
    [self _renderTexturedQuad:renderEncoder view:view name:@"envmapQuadMix"];
    
    [renderEncoder endEncoding];
    
    // call the view's completion handler which is required by the view since it will signal its semaphore and set up the next buffer
    __block dispatch_semaphore_t block_sema = _inflight_semaphore;
    [commandBuffer addCompletedHandler:^(id<MTLCommandBuffer> buffer) {
        dispatch_semaphore_signal(block_sema);
    }];
    
    // the renderview assumes it can now increment the buffer index and that the previous index wont be touched
    // until we cycle back around to the same index
    _constantDataBufferIndex = (_constantDataBufferIndex + 1) % kInFlightCommandBuffers;
    
    // schedule a present once the framebuffer is complete
    [commandBuffer addScheduledPresent:view.currentDrawable];
    
    // finalize rendering here. this will push the command buffer to the GPU
    [commandBuffer commit];
}

- (void)_prepareToDraw:(METLView *)view
{
    // read shader constant data for the current buffer index cycle into the appropriate Balsa buffers for this round of rendering
    _quad_constant_vertexbuffer_offset = 0;
    _skybox_constant_vertexbuffer_offset = 0;
    _quad_invertedViewMatrix_fragmentbuffer_offset = 0;
    
    // store the base pointer to the current buffer's starting memeory region
    uint8_t *bufferPointer = (uint8_t *)[_dynamicUniformBuffer[_constantDataBufferIndex] contents];
    uint8_t *basePointer = bufferPointer;
    
    // skybox
    // copy skybox data into the buffer then increment the buffer pointer
    memcpy(bufferPointer, &_skybox_modelview_projection_matrix, sizeof(simd::float4x4));
    bufferPointer += sizeof(simd::float4x4);
    
    // quad inverted view matrix for framgent shader
    // copy quad inverted view matrix buffer data into the region of memory then increment buffer pointer,
    // also store off its offset for use when setting the buffer on the render context
    memcpy(bufferPointer, &_inverted_view_matrix, sizeof(simd::float4x4));
    _quad_invertedViewMatrix_fragmentbuffer_offset = bufferPointer-basePointer;
    bufferPointer += sizeof(simd::float4x4);
    
    // quad transformation data
    // copy quad transformation data into its region of memory then increment buffer pointer,
    // also store off its offset for use when setting the buffer on the render context
    memcpy(bufferPointer, &_uniform_buffer, sizeof(METL::uniforms_t));
    _quad_constant_vertexbuffer_offset = bufferPointer-basePointer;
}


- (void)reshape:(METLView *)view
{
    // when reshape is called, update the view and projection matricies since this means the view orientation or size changed
    float aspect = fabsf(view.bounds.size.width / view.bounds.size.height);
    _projectionMatrix = METL::perspective_fov(kFOVY, aspect, 0.1f, 100.0f);
    _viewMatrix = METL::lookAt(kEye, kCenter, kUp);
    _inverted_view_matrix = simd::inverse(_viewMatrix);
}

#pragma mark VIEW CONTROLLER DELEGATE METHODS

- (void)renderViewControllerUpdate:(METLViewController *)controller
{
    simd::float4x4 base_model = METL::translate(0.0f, 0.0f, 5.0f) * METL::rotate(_rotation, 0.0f, 1.0f, 0.0f);
    simd::float4x4 quad_mv = _viewMatrix * base_model;
    
    _uniform_buffer.modelview_matrix = quad_mv;
    _uniform_buffer.normal_matrix = simd::inverse(simd::transpose(quad_mv));
    _uniform_buffer.modelview_projection_matrix = _projectionMatrix * quad_mv;
    
    // calculate the model view projection data for the skybox
    simd::float4x4 skyboxModelMatrix = METL::scale(10.0f) * METL::rotate(_skyboxRotation, 0.0f, 1.0f, 0.0f);
    simd::float4x4 skyboxModelViewMatrix = _viewMatrix * skyboxModelMatrix;
    
    // write the skybox transformation data into the current constant buffer
    _skybox_modelview_projection_matrix = _projectionMatrix * skyboxModelViewMatrix;
    
    _rotation += controller.timeSinceLastDraw * 20.0f;
    _skyboxRotation += controller.timeSinceLastDraw * 1.0f;
}

- (void)renderViewController:(METLViewController *)controller willPause:(BOOL)pause
{
    // timer is suspended/resumed
    // Can do any non-rendering related background work here when suspended
}


@end
