/*
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 
  A renderer class for visualizing 2 rotating 3d cubes bounded to
  a plasma shader.
  
 */

#import "METLView.h"
#import "METLViewController.h"

#import "METLCube.h"
#import "METLPlasmaUniforms.h"

#import "METLRenderer.h"

static const uint32_t kInFlightCommandBuffers = 3;

@implementation METLRenderer
{
@private
    METLCube                    *mpCube;
    METLPlasmaUniforms          *mpPlasmaUniforms;
    dispatch_semaphore_t         m_InflightSemaphore;
    id <MTLCommandQueue>         m_CommandQueue;
    id <MTLLibrary>              m_ShaderLibrary;
    id <MTLDepthStencilState>    m_DepthState;
    id <MTLRenderPipelineState>  m_PipelineState;
}

- (void) dealloc
{
    // Private
    m_PipelineState  = nil;
    m_ShaderLibrary  = nil;
    m_DepthState     = nil;
    m_CommandQueue   = nil;
    mpPlasmaUniforms = nil;
    mpCube           = nil;
    
    // Protected
    _device = nil;
}

- (instancetype) init
{
    self = [super init];
    
    if(self)
    {
        // Set the default pixel sample count
        _sampleCount = 4;
        
        // Set the default pixel formats
        _depthPixelFormat   = MTLPixelFormatDepth32Float;
        _stencilPixelFormat = MTLPixelFormatInvalid;
        
        // find a usable Device
        _device = MTLCreateSystemDefaultDevice();
        
        if(!_device)
        {
            NSLog(@">> ERROR: Failed creating a default system device!");
            
            exit(-1);
        } // if
        
        // setup a semaphore to synchronize between command buffer encoding and submission
        m_InflightSemaphore = dispatch_semaphore_create(kInFlightCommandBuffers);
    }
    
    return self;
} // init

#pragma mark -
#pragma mark - Delegates - Render View

- (BOOL) _setup
{
    NSError  *pError = nil;
    
    // create a new command queue
    m_CommandQueue = [_device newCommandQueue];
    
    if(!m_CommandQueue)
    {
        NSLog(@">> ERROR: Failed creating a new command queue!");
        
        return NO;
    } // if
    
    // load offline compiled shaders
    m_ShaderLibrary = [_device newDefaultLibrary];

    if(!m_ShaderLibrary)
    {
        NSLog(@">> ERROR: Failed creating a new library!");
        
        return NO;
    } // if
    
    // load the vertex program into the library
    id <MTLFunction> vertexProgram = [m_ShaderLibrary newFunctionWithName:@"plasmaVertex"];
    
    if(!vertexProgram)
    {
        NSLog(@">> ERROR: Failed creating a new vertex program!");
        
        return NO;
    } // if
    
    // load the fragment program into the library
    id <MTLFunction> fragmentProgram = [m_ShaderLibrary newFunctionWithName:@"plasmaFragment"];
    
    if(!fragmentProgram)
    {
        NSLog(@">> ERROR: Failed creating a new fragment program!");
        
        return NO;
    } // if
    
    //  create a reusable pipeline state
    MTLRenderPipelineDescriptor *pPipelineStateDescriptor = [MTLRenderPipelineDescriptor new];
    
    if(!pPipelineStateDescriptor)
    {
        NSLog(@">> ERROR: Failed creating a new pipeline state descriptor!");
        
        return NO;
    } // if
    
    [pPipelineStateDescriptor setPixelFormat:MTLPixelFormatBGRA8Unorm
                                     atIndex:MTLFramebufferAttachmentIndexColor0];
    
    [pPipelineStateDescriptor setPixelFormat:_depthPixelFormat
                                     atIndex:MTLFramebufferAttachmentIndexDepth];
    
    [pPipelineStateDescriptor setPixelFormat:_stencilPixelFormat
                                     atIndex:MTLFramebufferAttachmentIndexStencil];
    
    [pPipelineStateDescriptor setSampleCount:_sampleCount];
    
    [pPipelineStateDescriptor setVertexFunction:vertexProgram];
    [pPipelineStateDescriptor setFragmentFunction:fragmentProgram];
    
    pPipelineStateDescriptor.depthWriteEnabled = YES;
    
    m_PipelineState = [_device newRenderPipelineStateWithDescriptor:pPipelineStateDescriptor
                                                              error:&pError];
    
    pPipelineStateDescriptor = nil;
    
    fragmentProgram = nil;
    vertexProgram   = nil;
    
    if(!m_PipelineState)
    {
        NSLog(@">> ERROR: Failed creating a new render pipeline state descriptor: %@", pError);
        
        return NO;
    } // if
    
    METL::Vector3 size = {0.75f, 0.75f, 0.75f};
    
    mpCube = [[METLCube alloc] initWithSize:size
                                     device:_device];
    
    if(!mpCube)
    {
        NSLog(@">> ERROR: Failed creating 3d cube!");
        
        return NO;
    } // if
    
    // allocate one region of memory for the constant buffer per max in
    // flight command buffers so that memory is properly syncronized.
    
    mpPlasmaUniforms = [[METLPlasmaUniforms alloc] initWithCapacity:kInFlightCommandBuffers
                                                             device:_device];
    
    if(!mpPlasmaUniforms)
    {
        NSLog(@">> ERROR: Failed creating plasma constants!");
        
        return NO;
    } // if
    
    MTLDepthStencilDescriptor *pDepthStateDesc = [MTLDepthStencilDescriptor new];
    
    if(!pDepthStateDesc)
    {
        NSLog(@">> ERROR: Failed creating a depth stencil descriptor!");
        
        return NO;
    } // if
    
    pDepthStateDesc.depthCompareFunction = MTLCompareFunctionLess;
    pDepthStateDesc.depthWriteEnabled    = YES;
    
    m_DepthState = [_device newDepthStencilStateWithDescriptor:pDepthStateDesc];
    
    pDepthStateDesc = nil;
    
    if(!m_DepthState)
    {
        NSLog(@">> ERROR: Failed creating a depth stencil!");
        
        return NO;
    } // if
    
    return YES;
} // _setup

- (void) loadAssets
{
    if(![self _setup])
    {
        NSLog(@">> ERROR: Failed loading the assets!");
        
        exit(-1);
    }
} // loadAssets

- (void) _encode:(id <MTLRenderCommandEncoder>)renderEncoder
{
    // Set context state with the render encoder
    [renderEncoder setDepthStencilState:m_DepthState];
    [renderEncoder setRenderPipelineState:m_PipelineState];
    
    // Encode a 3d cube into renderer
    [mpCube encode:renderEncoder];
    
    // Encode into renderer the first set of vertex and fragment uniforms
    [mpPlasmaUniforms encode:renderEncoder];
    
    // Tell the render context we want to draw our first set of primitives
    [renderEncoder drawIndexedPrimitives:MTLPrimitiveTypeTriangle
                              indexCount:mpCube.indexCount
                               indexType:MTLIndexTypeUInt32
                             indexBuffer:mpCube.indexBuffer
                       indexBufferOffset:0];
    
    // Encode into renderer the second set of vertex and fragment uniforms
    [mpPlasmaUniforms encode:renderEncoder];
    
    // Tell the render context we want to draw our second set of primitives
    [renderEncoder drawIndexedPrimitives:MTLPrimitiveTypeTriangle
                              indexCount:mpCube.indexCount
                               indexType:MTLIndexTypeUInt32
                             indexBuffer:mpCube.indexBuffer
                       indexBufferOffset:0];
    
    // The encoding is now complete
    [renderEncoder endEncoding];
} // _encode

- (void) _render:(id <MTLCommandBuffer>)commandBuffer
            view:(METLView *)view
{
    // Get a render encoder
    id <MTLRenderCommandEncoder>  renderEncoder
    = [commandBuffer renderCommandEncoderWithFramebuffer:view.currentFramebuffer];
    
    // Encode into a renderer
    [self _encode:renderEncoder];
    
    // Discard the render encoder
    renderEncoder = nil;
} // _render

// Call the view's completion handler which is required by the view
// since it will signal its semaphore and set up the next buffer
- (void) _dispatch:(id <MTLCommandBuffer>)commandBuffer
{
    __block dispatch_semaphore_t dispatchSemaphore = m_InflightSemaphore;
    
    [commandBuffer addCompletedHandler:^(id <MTLCommandBuffer> cmdb){
        dispatch_semaphore_signal(dispatchSemaphore);
    }];
} // _dispatch

- (void) _commit:(id <MTLCommandBuffer>)commandBuffer
            view:(METLView *)view
{
    // Schedule a present once the framebuffer is complete
    [commandBuffer addScheduledPresent:view.currentDrawable];
    
    // Finalize rendering here & push the command buffer to the GPU
    [commandBuffer commit];
} // _commit

- (void) render:(METLView *)view
{
    // Wait on semaphore
    dispatch_semaphore_wait(m_InflightSemaphore, DISPATCH_TIME_FOREVER);
    
    // Upload the uniforms into the structure bound to shaders
    [mpPlasmaUniforms upload];
    
    // Acquire a command buffer
    id <MTLCommandBuffer> commandBuffer = [m_CommandQueue commandBuffer];
    
    // Encode into a renderer
    [self _render:commandBuffer
             view:view];
    
    // Dispatch the command buffer
    [self _dispatch:commandBuffer];
    
    // Commit the command buffer
    [self _commit:commandBuffer
             view:view];
    
    // Discard the command buffer
    commandBuffer = nil;
} // render

- (void) reshape:(METLView *)view
{
    mpPlasmaUniforms.bounds = view.bounds;
} // reshape

- (void) update:(METLViewController *)controller
{
    [mpPlasmaUniforms update];
} // update

- (void) pause:(METLViewController *)controller
     willPause:(BOOL)pause
{
    // timer is suspended/resumed
    // Can do any non-rendering related background work here when suspended
} // pause

@end
