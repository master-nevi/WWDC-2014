/*
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 
  Plasma structures, constants, and utility functions.
  
 */

#import <memory>

#import "METLPlasmaParams.h"

class METL::Plasma::ParamBlock
{
public:
    ParamBlock(const float& nValue,
               const float& nDelta,
               const float& nMin,
               const float& nMax,
               const float& nSgn)
    {
        mnValue = nValue;
        mnDelta = nDelta;
        mnMin   = nMin;
        mnMax   = nMax;
        mnSgn   = nSgn;
    }
    
    virtual ~ParamBlock()
    {
        mnValue = 0.0f;
        mnDelta = 0.0f;
        mnMin   = 0.0f;
        mnMax   = 0.0f;
        mnSgn   = 0.0f;
    }
    
    ParamBlock(const ParamBlock& rParams)
    {
        mnValue = rParams.mnValue;
        mnDelta = rParams.mnDelta;
        mnMin   = rParams.mnMin;
        mnMax   = rParams.mnMax;
        mnSgn   = rParams.mnSgn;
    }
    
    ParamBlock& operator=(const ParamBlock& rParams)
    {
        if(this != &rParams)
        {
            mnValue = rParams.mnValue;
            mnDelta = rParams.mnDelta;
            mnMin   = rParams.mnMin;
            mnMax   = rParams.mnMax;
            mnSgn   = rParams.mnSgn;
        }
        
        return *this;
    }
    
    ParamBlock& operator=(const float& k)
    {
        mnValue = k;
        mnDelta = k;
        mnMin   = k;
        mnMax   = k;
        mnSgn   = k;
        
        return *this;
    }
    
public:
    float  mnValue;
    float  mnDelta;
    float  mnMin;
    float  mnMax;
    float  mnSgn;
};

static METL::Plasma::ParamBlock kTime  = METL::Plasma::ParamBlock(0.0f, 0.08f, 0.0f, 12.0f * float(M_PI), 1.0f);
static METL::Plasma::ParamBlock kScale = METL::Plasma::ParamBlock(1.0f, 0.125f, 1.0f, 32.0f, 1.0f);

static float METLPlasmaParamBlockUpdate(METL::Plasma::ParamBlock& rParamBlock)
{
    rParamBlock.mnValue += (rParamBlock.mnSgn * rParamBlock.mnDelta);
    
    if( rParamBlock.mnValue >= rParamBlock.mnMax )
    {
        rParamBlock.mnSgn = -1.0f;
    } // if
    else if( rParamBlock.mnValue <= rParamBlock.mnMin )
    {
        rParamBlock.mnSgn = 1.0f;
    } // else if
    
    return rParamBlock.mnValue;
}

METL::Plasma::Params::Params()
: m_Time(kTime), m_Scale(kScale)
{
}

METL::Plasma::Params::Params(METL::Plasma::ParamBlock& rTime,
                             METL::Plasma::ParamBlock& rScale)
: m_Time(rTime), m_Scale(rScale)
{
}

METL::Plasma::Params::~Params()
{
    m_Time  = 0.0f;
    m_Scale = 0.0f;
}

METL::Plasma::Params::Params(const METL::Plasma::Params& rParams)
: m_Time(rParams.m_Time), m_Scale(rParams.m_Scale)
{
}

METL::Plasma::Params& METL::Plasma::Params::operator=(const METL::Plasma::Params& rParams)
{
    if(this != &rParams)
    {
        m_Time  = rParams.m_Time;
        m_Scale = rParams.m_Scale;
    }
    
    return *this;
}

METL::Vector2 METL::Plasma::Params::update()
{
    METL::Vector2 v;
    
    v.time  = METLPlasmaParamBlockUpdate(m_Time);
    v.scale = METLPlasmaParamBlockUpdate(m_Scale);
    
    return v;
}


