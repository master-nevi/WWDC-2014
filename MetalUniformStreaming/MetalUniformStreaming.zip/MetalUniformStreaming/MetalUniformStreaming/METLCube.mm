/*
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 
  3d cube vertices, normals, texture coordinates, and indices.
  
 */

#import "METLCube.h"

@implementation METLCube
{
@private
    METL::Vector3 m_Size;
    
    id <MTLBuffer>  m_VertexBuffer;
    id <MTLBuffer>  m_NormalBuffer;
    id <MTLBuffer>  m_TexCoordBuffer;
}

- (void) dealloc
{
    // Private
    m_VertexBuffer   = nil;
    m_NormalBuffer   = nil;
    m_TexCoordBuffer = nil;
    
    // Protected
    _indexBuffer = nil;
} // dealloc

- (id <MTLBuffer>) _newVertexBuffer:(METL::Vector3)size
                             device:(id <MTLDevice>)device
{
    m_Size = size;
    
    static const uint32_t kCntVertices = 24;
    static const uint32_t kSzVertices  = kCntVertices  * METL::kSzVector3;
    
    static const METL::Vector3 kVertices[kCntVertices] =
    {
        {-m_Size.width, -m_Size.height, -m_Size.depth},   //0
        {-m_Size.width, -m_Size.height, -m_Size.depth},   //0
        {-m_Size.width, -m_Size.height, -m_Size.depth},   //0
        
        {-m_Size.width, -m_Size.height, m_Size.depth},    //3
        {-m_Size.width, -m_Size.height, m_Size.depth},    //3
        {-m_Size.width, -m_Size.height, m_Size.depth},    //3
        
        {m_Size.width, -m_Size.height, -m_Size.depth},    //6
        {m_Size.width, -m_Size.height, -m_Size.depth},    //6
        {m_Size.width, -m_Size.height, -m_Size.depth},    //6
        
        {m_Size.width, -m_Size.height, m_Size.depth},     //9
        {m_Size.width, -m_Size.height, m_Size.depth},     //9
        {m_Size.width, -m_Size.height, m_Size.depth},     //9
        
        {m_Size.width, m_Size.height, -m_Size.depth},     //12
        {m_Size.width, m_Size.height, -m_Size.depth},     //12
        
        {m_Size.width, m_Size.height, m_Size.depth},      //14
        {m_Size.width, m_Size.height, m_Size.depth},      //14
        
        {-m_Size.width, m_Size.height, -m_Size.depth},    //16
        {-m_Size.width, m_Size.height, -m_Size.depth},    //16
        
        {-m_Size.width, m_Size.height, m_Size.depth},     //18
        {-m_Size.width, m_Size.height, m_Size.depth},     //18
        
        { m_Size.width, m_Size.height, -m_Size.depth},
        { m_Size.width, m_Size.height,  m_Size.depth},
        {-m_Size.width, m_Size.height, -m_Size.depth},
        {-m_Size.width, m_Size.height,  m_Size.depth}
    };
    
    // setup the vertex buffers
    id <MTLBuffer> vertexBuffer = [device newBufferWithBytes:kVertices
                                                      length:kSzVertices
                                                     options:MTLResourceOptionCPUCacheModeDefault];
    
    return vertexBuffer;
} // _newVertexBuffer

- (id <MTLBuffer>) _newNormalBuffer:(id <MTLDevice>)device
{
    static const uint32_t kCntNormals = 24;
    static const uint32_t kSzNormals  = kCntNormals * METL::kSzVector3;
    
    static const METL::Vector3 kNormals[kCntNormals] =
    {
        {  0.0,  0.0, -1.0 },
        { -1.0,  0.0,  0.0 },
        {  0.0, -1.0,  0.0 },
        
        {  0.0,  0.0, 1.0 },
        { -1.0,  0.0, 0.0 },
        {  0.0, -1.0, 0.0 },
        
        { 0.0,  0.0, -1.0 },
        { 1.0,  0.0,  0.0 },
        { 0.0, -1.0,  0.0 },
        
        { 0.0,  0.0,  1.0 },
        { 1.0,  0.0,  0.0 },
        { 0.0, -1.0,  0.0 },
        
        { 1.0, 0.0,  0.0 },
        { 0.0, 1.0,  0.0 },
        
        { 1.0, 0.0,  0.0 },
        { 0.0, 1.0,  0.0 },
        
        { -1.0, 0.0,  0.0 },
        {  0.0, 1.0,  0.0 },
        
        { -1.0, 0.0,  0.0 },
        {  0.0, 1.0,  0.0 },
        
        { 0.0, 0.0, -1.0 },
        { 0.0, 0.0,  1.0 },
        { 0.0, 0.0, -1.0 },
        { 0.0, 0.0,  1.0 }
    };
    
    id <MTLBuffer> normalBuffer = [device newBufferWithBytes:kNormals
                                                      length:kSzNormals
                                                     options:MTLResourceOptionCPUCacheModeDefault];
    
    return normalBuffer;
} // _newNormalBuffer

- (id <MTLBuffer>) _newTexCoordBuffer:(id <MTLDevice>)device
{
    static const uint32_t kCntTexCoords = 24;
    static const uint32_t kSzTexCoords = kCntTexCoords * METL::kSzVector2;
    
    static const METL::Vector2 kTexCoords[kCntTexCoords] =
    {
        {0.0, 1.0},
        {1.0, 0.0},
        {0.0, 0.0},
        
        {0.0, 0.0},
        {1.0, 1.0},
        {0.0, 1.0},
        
        {1.0, 1.0},
        {0.0, 0.0},
        {1.0, 0.0},
        
        {1.0, 0.0},
        {0.0, 1.0},
        {1.0, 1.0},
        
        {1.0, 0.0},
        {0.0, 0.0},
        
        {1.0, 1.0},
        {0.0, 1.0},
        
        {0.0, 0.0},
        {1.0, 0.0},
        
        {0.0, 1.0},
        {1.0, 1.0},
        
        {1.0, 0.0},
        {1.0, 1.0},
        {0.0, 0.0},
        {0.0, 1.0}
    };
    
    id <MTLBuffer> texCoordBuffer = [device newBufferWithBytes:kTexCoords
                                                        length:kSzTexCoords
                                                       options:MTLResourceOptionCPUCacheModeDefault];
    
    return texCoordBuffer;
} // _newTexCoordBuffer

- (id <MTLBuffer>) _newIndexBuffer:(id <MTLDevice>)device
{
    static const uint32_t kCntIndicies = 36;
    static const uint32_t kSzIndices   = kCntIndicies  * sizeof(uint32_t);
    
    static const uint32_t kIndices[kCntIndicies] =
    {
        11,  5,  2,
        8, 11,  2,
        14, 10,  7,
        12, 14,  7,
        19, 15, 13,
        17, 19, 13,
        4, 18, 16,
        1,  4, 16,
        21, 23,  3,
        3,  9, 21,
        6,  0, 22,
        20,  6, 22
    };
    
    _indexCount = kCntIndicies;
    
    id <MTLBuffer> indexBuffer = [device newBufferWithBytes:kIndices
                                                     length:kSzIndices
                                                    options:MTLResourceOptionCPUCacheModeDefault];
    
    return indexBuffer;
} // _newIndexBuffer

- (instancetype) initWithSize:(METL::Vector3)size
                       device:(id <MTLDevice>)device
{
    self = [super init];
    
    if(self)
    {
        if(!device)
        {
            NSLog(@">> ERROR: Invalid device!");
            
            return nil;
        } // if
        
        // setup the vertex buffers
        m_VertexBuffer = [self _newVertexBuffer:size
                                         device:device];
        
        if(!m_VertexBuffer)
        {
            NSLog(@">> ERROR: Failed creating a vertex buffer!");
            
            return nil;
        } // if
        
        m_NormalBuffer = [self _newNormalBuffer:device];
        
        if(!m_NormalBuffer)
        {
            NSLog(@">> ERROR: Failed creating a normals buffer!");
            
            m_VertexBuffer = nil;
            
            return nil;
        } // if
        
        m_TexCoordBuffer = [self _newTexCoordBuffer:device];
        
        if(!m_TexCoordBuffer)
        {
            NSLog(@">> ERROR: Failed creating a texture coordinate buffer!");
            
            m_VertexBuffer = nil;
            m_NormalBuffer = nil;
            
            return nil;
        } // if
        
        _indexBuffer = [self _newIndexBuffer:device];
        
        if(!_indexBuffer)
        {
            NSLog(@">> ERROR: Failed creating an index buffer!");
            
            m_VertexBuffer   = nil;
            m_NormalBuffer   = nil;
            m_TexCoordBuffer = nil;
            
            return nil;
        } // if
    } // if
    
    return self;
} // initWithDevice

- (void) encode:(id <MTLRenderCommandEncoder>)renderEncoder
{
    [renderEncoder setVertexBuffer:m_VertexBuffer
                            offset:0
                           atIndex:0 ];
    
    [renderEncoder setVertexBuffer:m_NormalBuffer
                            offset:0
                           atIndex:1 ];
    
    [renderEncoder setVertexBuffer:m_TexCoordBuffer
                            offset:0
                           atIndex:2 ];
} // encode

@end
