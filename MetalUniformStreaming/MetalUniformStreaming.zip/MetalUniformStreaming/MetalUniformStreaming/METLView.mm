/*
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 
  Metal view class.
  
 */

#import "METLView.h"

@implementation METLView
{
@private
    __weak CAMetalLayer *_metalLayer;
    
    BOOL _layerSizeDidUpdate;
    
    id <MTLTexture>  _depthTex;
    id <MTLTexture>  _stencilTex;
    id <MTLTexture>  _msaaTex;
}

@synthesize currentDrawable    = _currentDrawable;
@synthesize currentFramebuffer = _currentFramebuffer;

+ (Class) layerClass
{
    return [CAMetalLayer class];
}

- (void) _initCommon
{
    self.opaque          = YES;
    self.backgroundColor = nil;
    
    // setting this to yes will allow Main thread to display framebuffer when
    // view:setNeedDisplay: is called by main thread
    _metalLayer = (CAMetalLayer *)self.layer;
    
    self.contentScaleFactor = [UIScreen mainScreen].scale;
    
    _metalLayer.presentsWithTransaction = NO;
    _metalLayer.drawsAsynchronously     = YES;
    
    _device = MTLCreateSystemDefaultDevice();
    
    _metalLayer.device          = _device;
    _metalLayer.pixelFormat     = MTLPixelFormatBGRA8Unorm;
    _metalLayer.framebufferOnly = YES;
    
    _drawableSize = self.bounds.size;
}

- (id) initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    
	if(self)
    {
        [self _initCommon];
    }
    
    return self;
}

- (instancetype) initWithCoder:(NSCoder *)coder
{
    self = [super initWithCoder:coder];
    
    if(self)
    {
        [self _initCommon];
    }
    return self;
}

- (void) releaseTextures
{
    _depthTex   = nil;
    _stencilTex = nil;
    _msaaTex    = nil;
}

- (id <MTLFramebuffer>) createFramebufferForTexture: (id <MTLTexture>) texture;
{
    MTLAttachmentDescriptor *colorAttachment = [MTLAttachmentDescriptor attachmentDescriptorWithTexture: texture];
    
    [colorAttachment setLoadAction:MTLLoadActionClear];
    [colorAttachment setClearValue:MTLClearValueMakeColor(0.65f, 0.65f, 0.65f, 1.0f)];
    
    if(_sampleCount > 1)
    {
        BOOL doUpdate =     ( _msaaTex.width       != texture.width  )
                        ||  ( _msaaTex.height      != texture.height )
                        ||  ( _msaaTex.sampleCount != _sampleCount   );
        
        if(!_msaaTex || (_msaaTex && doUpdate))
        {
            MTLTextureDescriptor* desc = [MTLTextureDescriptor texture2DDescriptorWithPixelFormat: MTLPixelFormatBGRA8Unorm
                                                                                            width: texture.width
                                                                                           height: texture.height
                                                                                        mipmapped: NO];
            desc.textureType = MTLTextureType2DMultisample;
            desc.sampleCount = _sampleCount;
            
            _msaaTex = [_device newTextureWithDescriptor: desc];
        }
        
        // When multisampling, perform rendering to _msaaTex, then resolve
        // to 'texture' at the end of the scene
        [colorAttachment setTexture: _msaaTex];
        [colorAttachment setResolveTexture: texture];
        [colorAttachment setStoreAction: MTLStoreActionMultisampleResolve];
    }
    else
    {
        [colorAttachment setStoreAction: MTLStoreActionStore];
    }
        
    
    MTLFramebufferDescriptor *framebufferDescriptor = [MTLFramebufferDescriptor framebufferDescriptorWithColorAttachment: colorAttachment];
    
    if(_depthPixelFormat != MTLPixelFormatInvalid)
    {
        BOOL doUpdate =     ( _depthTex.width       != texture.width  )
                        ||  ( _depthTex.height      != texture.height )
                        ||  ( _depthTex.sampleCount != _sampleCount   );
        
        if(!_depthTex || doUpdate)
        {
            //  If we need a depth texture and don't have one, or if the depth texture we have is the wrong size
            //  Then allocate one of the proper size
            
            MTLTextureDescriptor* desc = [MTLTextureDescriptor texture2DDescriptorWithPixelFormat: _depthPixelFormat
                                                                                            width: texture.width
                                                                                           height: texture.height
                                                                                        mipmapped: NO];
            
            desc.textureType = (_sampleCount > 1) ? MTLTextureType2DMultisample : MTLTextureType2D;
            desc.sampleCount = _sampleCount;
            
            _depthTex = [_device newTextureWithDescriptor: desc];
        }
        
        MTLAttachmentDescriptor* depthAttachment = [MTLAttachmentDescriptor attachmentDescriptorWithTexture: _depthTex];
        
        [depthAttachment setLoadAction:MTLLoadActionClear];
        [depthAttachment setClearValue:MTLClearValueMakeDepth(1.0)];
        [depthAttachment setStoreAction: MTLStoreActionDontCare];
        
        [framebufferDescriptor setAttachment: depthAttachment
                                     atIndex: MTLFramebufferAttachmentIndexDepth];
    }
    
    if(_stencilPixelFormat != MTLPixelFormatInvalid)
    {
        BOOL doUpdate  =    ( _stencilTex.width       != texture.width  )
                        ||  ( _stencilTex.height      != texture.height )
                        ||  ( _stencilTex.sampleCount != _sampleCount   );
        
        if(!_stencilTex || doUpdate)
        {
            //  If we need a stencil texture and don't have one, or if the depth texture we have is the wrong size
            //  Then allocate one of the proper size
            
            MTLTextureDescriptor* desc = [MTLTextureDescriptor texture2DDescriptorWithPixelFormat: _stencilPixelFormat
                                                                                            width: texture.width
                                                                                           height: texture.height
                                                                                        mipmapped: NO];
            
            desc.textureType = (_sampleCount > 1) ? MTLTextureType2DMultisample : MTLTextureType2D;
            desc.sampleCount = _sampleCount;
            
            _stencilTex = [_device newTextureWithDescriptor: desc];
        }
        
        MTLAttachmentDescriptor* stencilAttachment = [MTLAttachmentDescriptor attachmentDescriptorWithTexture: _stencilTex];
        
        [stencilAttachment setLoadAction:MTLLoadActionClear];
        [stencilAttachment setClearValue:MTLClearValueMakeStencil(0)];
        [stencilAttachment setStoreAction: MTLStoreActionDontCare];
        
        [framebufferDescriptor setAttachment: stencilAttachment
                                     atIndex: MTLFramebufferAttachmentIndexStencil];
    }
    
    return [_device newFramebufferWithDescriptor:framebufferDescriptor];
}

- (id <MTLFramebuffer>) currentFramebuffer
{
    if(!_currentFramebuffer)
    {
        id <CAMetalDrawable> drawable = self.currentDrawable;
        
        if(drawable)
        {
            _currentFramebuffer = [self createFramebufferForTexture: drawable.texture];
        }
    }
    
    return _currentFramebuffer;
}


- (id <CAMetalDrawable>) currentDrawable
{
    while (_currentDrawable == nil)
    {
        _currentDrawable = [_metalLayer newDrawable];
        
        if(!_currentDrawable)
        {
            NSLog(@"CurrentDrawable is nil");
        }
    }
    
    return _currentDrawable;
}

- (void) display
{
    // Create autorelease pool per frame to avoid possible deadlock situations
    // because there are 3 CAMetalDrawables sitting in an autorelease pool.
    
    @autoreleasepool
    {
        if(_layerSizeDidUpdate)
        {
            _drawableSize = self.bounds.size;
            
            _drawableSize.width  *= self.contentScaleFactor;
            _drawableSize.height *= self.contentScaleFactor;
            
            _metalLayer.drawableSize = _drawableSize;
            
            [_delegate reshape:self];
            
            _layerSizeDidUpdate = NO;
        }
        
        // draw
        [self.delegate render:self];
        
        _currentFramebuffer = nil;
        _currentDrawable    = nil;
    }
}

- (void) setContentScaleFactor:(CGFloat)contentScaleFactor
{
    [super setContentScaleFactor:contentScaleFactor];
    
    _layerSizeDidUpdate = YES;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    _layerSizeDidUpdate = YES;
}

@end
