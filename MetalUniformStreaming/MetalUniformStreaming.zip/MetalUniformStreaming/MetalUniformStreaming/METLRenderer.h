/*
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 
  A renderer class for visualizing 2 rotating 3d cubes bounded to
  a plasma shader.
  
 */

#import "METLView.h"
#import "METLViewController.h"

@interface METLRenderer : NSObject <METLViewControllerDelegate, METLViewDelegate>

// renderer will create a default device at init time.
@property (nonatomic, readonly) id <MTLDevice> device;

// These queries exist so the View can initialize a framebuffer that
// matches the expectations of the renderer
@property (nonatomic, readonly) MTLPixelFormat depthPixelFormat;
@property (nonatomic, readonly) MTLPixelFormat stencilPixelFormat;
@property (nonatomic, readonly) NSUInteger     sampleCount;

// load all assets before triggering rendering
- (void) loadAssets;

@end
