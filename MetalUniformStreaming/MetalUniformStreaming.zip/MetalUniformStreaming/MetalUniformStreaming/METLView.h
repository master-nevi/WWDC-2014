/*
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 
  Metal view class.
  
 */

#import <UIKit/UIKit.h>
#import <QuartzCore/CAMetalLayer.h>
#import <Metal/Metal.h>

@protocol METLViewDelegate;

@interface METLView : UIView
@property (nonatomic, weak) IBOutlet id <METLViewDelegate> delegate;

// view has a handle to the metal device when created
@property (nonatomic, readonly) id <MTLDevice> device;

// the current drawable created within the view's CAMetalLayer
@property (nonatomic, readonly) id <CAMetalDrawable> currentDrawable;

// the current drawable view size
@property (nonatomic, readonly) CGSize drawableSize;

// The current framebuffer can be read by delegate during -[MetalViewDelegate render:]
// This call may block until the framebuffer is available.
@property (nonatomic, readonly) id <MTLFramebuffer> currentFramebuffer;

// set these pixel formats to have the main drawable framebuffer get created with depth and/or stencil attachments
@property (nonatomic) MTLPixelFormat depthPixelFormat;
@property (nonatomic) MTLPixelFormat stencilPixelFormat;
@property (nonatomic) NSUInteger     sampleCount;

//  This returns a framebuffer with the named texture at Color Attachment 0, and depth, stencil, and multisample attachments configured according to the 'depthPixelFormat', 'stencilPixelFormat', and 'sampleCount' properties.
- (id <MTLFramebuffer>) createFramebufferForTexture: (id <MTLTexture>) texture;

// view controller will be call off the main thread
- (void)display;

// release any color/depth/stencil resources. view controller will call when paused.
- (void)releaseTextures;

@end

// rendering delegate (App must implement a rendering delegate that responds to these messages
@protocol METLViewDelegate <NSObject>

@required
// called if the view changes orientation or size, renderer can precompute its view and projection matricies here for example
- (void)reshape:(METLView *)view;

// delegate should perform all rendering here
- (void)render:(METLView *)view;

@end
