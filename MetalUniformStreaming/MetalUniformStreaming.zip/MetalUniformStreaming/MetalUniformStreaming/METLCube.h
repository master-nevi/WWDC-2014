/*
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 
  3d cube vertices, normals, texture coordinates, and indices.
  
 */

#import <Metal/Metal.h>

#import "METLTypes.h"

@interface METLCube : NSObject

@property (nonatomic, readonly) id <MTLBuffer>  indexBuffer;
@property (nonatomic, readonly) NSUInteger      indexCount;

- (instancetype) initWithSize:(METL::Vector3)size
                       device:(id <MTLDevice>)device;

- (void) encode:(id <MTLRenderCommandEncoder>)renderEncoder;

@end
