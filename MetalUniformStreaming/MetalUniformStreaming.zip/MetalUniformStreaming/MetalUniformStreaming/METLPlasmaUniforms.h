/*
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 
  Plasma shader uniforms encapsulated utility class.
  
 */

#import <UIKit/UIKit.h>
#import <Metal/Metal.h>

@interface METLPlasmaUniforms : NSObject

@property (nonatomic, readwrite) CGRect bounds;

- (instancetype) initWithCapacity:(NSUInteger)capacity
                           device:(id <MTLDevice>)device;

- (void) encode:(id <MTLRenderCommandEncoder>)renderEncoder;

- (BOOL) upload;

- (void) update;

@end
