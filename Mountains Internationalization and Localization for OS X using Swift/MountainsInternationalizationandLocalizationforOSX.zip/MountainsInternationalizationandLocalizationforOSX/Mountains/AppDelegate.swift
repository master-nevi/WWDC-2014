
/*
Copyright (C) 2014 Apple Inc. All Rights Reserved.
See LICENSE.txt for this sample’s licensing information

Abstract:

Application delegate.

*/


import Cocoa

class AppDelegate : NSObject, NSApplicationDelegate, NSTableViewDataSource, NSTableViewDelegate {

    @IBOutlet var window: NSWindow

    @IBOutlet var mountainsTableView: NSTableView
    @IBOutlet var sentenceTextField: NSTextField


    /// Configure the UI after the nib is loaded.
    override func awakeFromNib() {
        resetSentence()
    }

    /*
    Responding to locale changes.
    */

    /*
    It is generally unusual for a user to change their locale settings while an application is running. If they do, there may be limits to what you can do to respond. In this application, you can change the way some of the mountain data is displayed at runtime, but the mountain names and so on remain the same, as do titles on user interface items like the window and menus.
    */

    func applicationDidFinishLaunching(aNotification: NSNotification) {

        // Register for notifications of locale changes (so we can update everything).
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "localeChanged:", name: NSCurrentLocaleDidChangeNotification, object: nil)
    }


    func localeChanged(notification: NSNotification) {

        climbedDateFormatter.locale = NSLocale.currentLocale()
        heightFormatter.locale = NSLocale.currentLocale()
        resetAll()
    }


    /*
    Table view data source.
    */

    /**
    Number of rows is the number of mountains in the array.
    */
    func numberOfRowsInTableView(tableView: NSTableView) -> Int {
        return mountains.count
    }

    /**
    Return the appropriate value for the row and column.
    */
    func tableView(tableView: NSTableView, objectValueForTableColumn column: NSTableColumn, row: Int) -> AnyObject {

        var returnValue = "Couldn't get a value"

        let mountain = sortedMountains[row]

        /*
        If the table column has an identifier (it should have!) then try to convert it into a MountainDictionaryKey enum. If this succeeds (again, it should), then set the return value of the method accordingly in a switch statement. Because the identifier is turned into an enum, the compiler can check that all the possible values have been accounted for (there's no need for a default case).
        */
        let columnIdentifier = column.identifier

        if let columnID = MountainDictionaryKey.fromRaw(columnIdentifier) {

            switch (columnID) {

            case .Name :
                var name = mountain.name
                returnValue = name.capitalizedString

            case .Height :
                returnValue = stringFromHeight(mountain.height)

            case .ClimbedDate :
                if mountain.climbedDate {
                    returnValue = climbedDateFormatter.stringFromDate(mountain.climbedDate!)
                }
                else {
                    returnValue = ""
                }
            }
        } else {
            fatalError("Unexpected column identifier")
        }

        return returnValue
    }

    /*
    Responding to changes in the table view.
    */

    /**
    Update the sentence in response to selection change.
    */
    func tableViewSelectionDidChange(notification: AnyObject) {
        resetSentence()
    }

    /**
    Force update to the sorted mountains array if the sort descriptors change.
    */
    func tableView(tableView: NSTableView, sortDescriptorsDidChange oldDescriptors: NSArray) {
        _sortedMountains = nil
        tableView.reloadData()
    }


    /**
    When the table view sorting changes, the selected row doesn't, so reset the sentence display to match the new data on that row.
    */
    func tableView(tableView: NSTableView, didClickTableColumn column: NSTableColumn) {
        resetSentence()
    }


    /// Update all the UI elements.
    func resetAll() {
        resetSentence()
        mountainsTableView!.reloadData()
    }


    /**
    Reset the text field with a sentence for the currently selected mountain. This is localized, and two versions are used because not all mountains have a climbed date available.
    */
    func resetSentence() {

        var sentence = ""
        let selectedRow = mountainsTableView!.selectedRow

        if selectedRow != -1 {

            let mountain = sortedMountains[selectedRow]

            if mountain.climbedDate {
                // "A sentence with the mountain's name (first parameter), height (second parameter), and climbed date (third parameter)"
                let format = NSLocalizedString("sentenceFormat", tableName: "Mountains", value: "Didn't find sentenceFormat", comment: "")
                let heightString = stringFromHeight(mountain.height)
                let climbedString = climbedDateFormatter.stringFromDate(mountain.climbedDate!)
                sentence = String(format: format, mountain.name, heightString, climbedString)
            } else {
                // "A sentence with the mountain's name (first parameter), and height (second parameter), but no climbed date"
                let format = NSLocalizedString("undatedSentenceFormat", tableName: "Mountains", value: "Didn't find undatedSentenceFormat", comment: "")
                let heightString = stringFromHeight(mountain.height)
                sentence = String(format:format, mountain.name, heightString)
            }
            sentenceTextField.stringValue = sentence
        }
    }


    /*
    String representations of data.
    */

    /**
    Returns a single string expressing a mountain's height. Allow for the possibility that the user is using non-metric units. If the units are non-metric, convert the value to feet.
    */
    func stringFromHeight(var height: Float) -> String {

        var returnValue: String

        var format = "%@"

        var usesMetricSystem = false
        if let usesMetricSystemPreference = NSLocale.currentLocale().objectForKey(NSLocaleUsesMetricSystem) as? NSNumber {
            if usesMetricSystemPreference.boolValue {
                usesMetricSystem = true
            }
        }

        if (usesMetricSystem) {
            // Use to express a height in meters.
            format = NSLocalizedString("meterFormat", tableName: "Mountains", value: "Didn't find meterFormat %@", comment: "format string to express height in meters")
        } else {
            // Convert the height to feet.
            height = height * 3.280839895
            // Use to express a height in feet.
            format = NSLocalizedString("footFormat", tableName: "Mountains", value: "Didn't find footFormat %@", comment: "format string to express height in feet")
        }

        let heightNumber = NSNumber(float: height)
        let heightString = heightFormatter.stringFromNumber(heightNumber)

        return String(format:format, heightString)
    }


    /*
    A date formatter to format height.
    */
    @lazy var heightFormatter: NSNumberFormatter = {

        let numberFormatter = NSNumberFormatter()
        numberFormatter.numberStyle = .DecimalStyle
        numberFormatter.maximumFractionDigits = 2
        return numberFormatter
    }()


    /*
    A date formatter to format climbedDate.
    */
    @lazy var climbedDateFormatter: NSDateFormatter = {

        let dateFormatter = NSDateFormatter()
        dateFormatter.dateStyle = .LongStyle
        dateFormatter.timeStyle = .NoStyle
        return dateFormatter
    }()


    /*
    Mountain data
    */

    /**
    The mountain data.
    */
    @lazy var mountains: Mountain[] = {

        // Get the localized version of the data file.
        let mountainsPlistURL = NSBundle.mainBundle().URLForResource("Mountains", withExtension: "plist")

        if mountainsPlistURL == nil {
            fatalError("Didn't find the mountains")
            return Mountain[]()
        }
        let mountainDictionaries = NSArray(contentsOfURL:mountainsPlistURL)
        var mountainsArray = Mountain[]()

        for mountainDictionary: NSDictionary! in mountainDictionaries {
            let newMountain = Mountain(dictionary: mountainDictionary)
            mountainsArray.append(newMountain)
        }

        return mountainsArray
    }()


    /**
    Mountains sorted per the table view's descriptors. Note that the sort method for the name column is localizedStandardCompare:.
    */
    var sortedMountains: Mountain[] {

        if !_sortedMountains {
            let sortDescriptors = mountainsTableView.sortDescriptors
            // Cast to NSArray to be able to use sortedArrayUsingDescriptors
            let mountainsArray = mountains as NSArray
            let sortedMountains = mountainsArray.sortedArrayUsingDescriptors(sortDescriptors)
            _sortedMountains = sortedMountains as? Mountain[]
        }
        return _sortedMountains!
    }
    var _sortedMountains: Mountain[]?
    
    
    /**
    Unregister from the notification center.
    */
    deinit {
        NSNotificationCenter.defaultCenter().removeObserver(self, name:NSCurrentLocaleDidChangeNotification, object: nil)
    }
}
