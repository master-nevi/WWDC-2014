
/*
Copyright (C) 2014 Apple Inc. All Rights Reserved.
See LICENSE.txt for this sample’s licensing information

Abstract:

Model class to represent information about a mountain.

*/


import Foundation

enum MountainDictionaryKey : String {

    case Name = "name"
    case Height = "height"
    case ClimbedDate = "climbedDate"
}

/*
Subclass NSObject to support valueForKeyPath when sorting the mountains.
*/
class Mountain : NSObject {

    let name: String
    let height: Float
    let climbedDate: NSDate?

    init (name: String, height: Float, climbedDate: NSDate?) {
        self.name = name
        self.height = height
        self.climbedDate = climbedDate
    }


    convenience init(dictionary: NSDictionary) {

        var name: String?
        var height: Float?
        var climbedDate: NSDate?

        var key: NSString

        key = MountainDictionaryKey.Name.toRaw()
        if let theName = dictionary[key] as? NSString {
            name = theName
        }
        key = MountainDictionaryKey.Height.toRaw()
        if let theHeight = dictionary[key] as? NSNumber {
            height = theHeight.floatValue
        }
        key = MountainDictionaryKey.ClimbedDate.toRaw()
        if let theDate = dictionary[key] as? NSDate {
            climbedDate = theDate
        }

        self.init(name:name!, height:height!, climbedDate:climbedDate)
    }
    
}
