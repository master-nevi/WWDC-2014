/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 View controller demonstrating an accessible search field
 
 */

#import "AAPLSearchFieldController.h"

@interface AAPLSearchFieldController ()

@property (nonatomic) BOOL completing;

@end

@implementation AAPLSearchFieldController

#pragma mark - Accessibility

- (NSArray *)accessibilitySharedFocusElementsForSearchFieldCell
{
    NSArray *sharedFocusElements = nil;
    
    // Return the NSTableView element that has the list of search results
    NSWindow *completionsWindow = [[NSApp windows] lastObject];
    if ( [completionsWindow isVisible] )
    {
        id child = completionsWindow;
        while ( child != nil && ![child isKindOfClass:[NSTableView class]] )
        {
            child = [[child accessibilityChildren] firstObject];
        }
        
        if ( child != nil && [child isKindOfClass:[NSTableView class]] )
        {
            sharedFocusElements = [NSArray arrayWithObject:child];
        }
    }
    
    return sharedFocusElements;
}

#pragma mark - Life Cycle

- (void)awakeFromNib
{
    // Add the search field's accessibility delegate to access the search results
    [_searchField setSharedFocusDelegate:self];

    if ([_searchField respondsToSelector: @selector(setRecentSearches:)])
    {
        NSMenu *searchMenu = [[NSMenu alloc] initWithTitle:NSLocalizedString(@"Search Menu", @"title of the search menu")];
        [searchMenu setAutoenablesItems:YES];
        
        NSMenuItem *recentsTitleItem = [[NSMenuItem alloc] initWithTitle:NSLocalizedString(@"Recent Searches", @"title of the recent searches") action:nil keyEquivalent:@""];

        [recentsTitleItem setTag:NSSearchFieldRecentsTitleMenuItemTag];
        [searchMenu insertItem:recentsTitleItem atIndex:0];
        
        NSMenuItem *norecentsTitleItem = [[NSMenuItem alloc] initWithTitle:NSLocalizedString(@"No Recent Searches", @"title of the recent searches") action:nil keyEquivalent:@""];
        [norecentsTitleItem setTag:NSSearchFieldNoRecentsMenuItemTag];
        [searchMenu insertItem:norecentsTitleItem atIndex:1];
        
        NSMenuItem *recentsItem = [[NSMenuItem alloc] initWithTitle:NSLocalizedString(@"Recents", @"title of the recent searches menu button") action:nil keyEquivalent:@""];
        [recentsItem setTag:NSSearchFieldRecentsMenuItemTag];
        [searchMenu insertItem:recentsItem atIndex:2];
        
        NSMenuItem *separatorItem = (NSMenuItem*)[NSMenuItem separatorItem];
        [separatorItem setTag:NSSearchFieldRecentsTitleMenuItemTag];
        [searchMenu insertItem:separatorItem atIndex:3];
        
        NSMenuItem *clearItem = [[NSMenuItem alloc] initWithTitle:NSLocalizedString(@"Clear", @"title of the clear menu button") action:nil keyEquivalent:@""];
        [clearItem setTag:NSSearchFieldClearRecentsMenuItemTag];
        [searchMenu insertItem:clearItem atIndex:4];
        
        [[_searchField cell] setMaximumRecents:20];
        [[_searchField cell] setSearchMenuTemplate:searchMenu];
    }
}

#pragma mark - Keyword Search

- (void)controlTextDidChange:(NSNotification *)obj
{
    NSTextView* textView = [[obj userInfo] objectForKey:@"NSFieldEditor"];

    // prevent calling "complete" too often
    if ( !_completing )
    {
        _completing = YES;
        [textView complete:nil];
        _completing = NO;
    }
}

- (BOOL)control:(NSControl *)control textView:(NSTextView *)textView doCommandBySelector:(SEL)commandSelector
{
    BOOL result = NO;

    if ([textView respondsToSelector:commandSelector])
    {
        _completing = YES;

        NSString *selectorName = NSStringFromSelector(commandSelector);
        if ( [selectorName isEqualToString:@"moveLeft:"] )
        {
            [textView moveLeft:nil];
        }
        else if ( [selectorName isEqualToString:@"moveRight:"] )
        {
            [textView moveRight:nil];
        }
        else if ( [selectorName isEqualToString:@"moveToLeftEndOfLine:"] )
        {
            [textView moveToLeftEndOfLine:nil];
        }
        else if ( [selectorName isEqualToString:@"moveToRightEndOfLine:"] )
        {
            [textView moveToRightEndOfLine:nil];
        }
        else if ( [selectorName isEqualToString:@"moveLeftAndModifySelection:"] )
        {
            [textView moveLeftAndModifySelection:nil];
        }
        else if ( [selectorName isEqualToString:@"moveRightAndModifySelection:"] )
        {
            [textView moveRightAndModifySelection:nil];
        }
        else if ( [selectorName isEqualToString:@"moveToLeftEndOfLineAndModifySelection:"] )
        {
            [textView moveToLeftEndOfLineAndModifySelection:nil];
        }
        else if ( [selectorName isEqualToString:@"moveToRightEndOfLineAndModifySelection:"] )
        {
            [textView moveToRightEndOfLineAndModifySelection:nil];
        }
        else if ( [selectorName isEqualToString:@"deleteBackward:"] )
        {
            [textView deleteBackward:nil];
        }
        else if ( [selectorName isEqualToString:@"deleteForward:"] )
        {
            [textView deleteForward:nil];
        }
        else if ( [selectorName isEqualToString:@"insertNewline:"] )
        {
            [textView insertNewline:nil];
        }

        _completing = NO;
        
        result = YES;
    }

    return result;
}

@end
