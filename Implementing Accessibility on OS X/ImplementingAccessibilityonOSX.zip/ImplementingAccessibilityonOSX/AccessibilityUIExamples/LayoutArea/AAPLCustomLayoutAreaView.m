/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
  An example demonstrating adding accessibility to a view that serves to layout UIs by implementing the NSAccessibilityLayoutArea protocol. 
 
 */

#import "AAPLCustomLayoutAreaView.h"

// IMPORTANT: This is not a template for developing adjustable items in a custom view. This sample is
// intended to demonstrate how to add accessibility to an adjust UI used for layout purpose.
// For information on how to create layout area please visit http://developer.apple.com

static const CGFloat AAPLLayoutItemHandleSize = 8.0f;
static const CGFloat AAPLLayoutItemMinSize = (AAPLLayoutItemHandleSize * 3.0f);
static const CGFloat AAPLLayoutItemMoveDelta = 10.0f;

typedef NS_ENUM(NSInteger, AAPLHandlePosition)
{
    AAPLHandlePositionUnknown,
    AAPLHandlePositionNorth,
    AAPLHandlePositionNorthEast,
    AAPLHandlePositionEast,
    AAPLHandlePositionSouthEast,
    AAPLHandlePositionSouth,
    AAPLHandlePositionSouthWest,
    AAPLHandlePositionWest,
    AAPLHandlePositionNorthWest,
};


@interface AAPLLayoutItem : NSAccessibilityElement <NSAccessibilityLayoutItem>
@property (nonatomic) NSRect bounds;
@property (nonatomic) NSUInteger zOrder;
@end

@interface AAPLCustomLayoutAreaView ()
@property (nonatomic, strong) NSMutableArray *layoutItems;
@property (nonatomic) NSInteger selectedLayoutItemIndex;
@property (nonatomic) BOOL layoutItemsNeedOrdering;
@end


@implementation AAPLCustomLayoutAreaView

- (instancetype)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];
    if ( self != nil )
    {
        self.layoutItems = [[NSMutableArray alloc] init];

        AAPLLayoutItem *rectangleA = [AAPLLayoutItem new];
        rectangleA.bounds = NSMakeRect(0,0,50,50);
        rectangleA.accessibilityParent = self;
        rectangleA.accessibilityLabel = NSLocalizedString(@"Rectangle A", @"accessibility layout for the first layout item");
        [self.layoutItems addObject:rectangleA];

        AAPLLayoutItem *rectangleB = [AAPLLayoutItem new];
        rectangleB.bounds = NSMakeRect(75,75,50,50);
        rectangleB.accessibilityParent = self;
        rectangleB.accessibilityLabel = NSLocalizedString(@"Rectangle B", @"accessibility label for the second layout item");
        [self.layoutItems addObject:rectangleB];
    }
    
    return self;
}

- (void)bringItemToTop:(NSInteger)itemIndex
{
    NSMutableArray *layoutItems = self.layoutItems;

    if ( itemIndex >= 0 && itemIndex < (NSInteger)layoutItems.count )
    {
        NSUInteger zOrder = 0;

        for ( AAPLLayoutItem *layoutItem in [self layoutItemsInZOrder] )
        {
            [layoutItem setZOrder:zOrder++];
        }

        [(AAPLLayoutItem *)layoutItems[itemIndex] setZOrder:layoutItems.count];
    }
}

- (NSArray *)layoutItemsInZOrder
{
    NSMutableArray *sortedLayoutItems = [self.layoutItems mutableCopy];

    [sortedLayoutItems sortUsingComparator:^NSComparisonResult(AAPLLayoutItem *obj1, AAPLLayoutItem *obj2) {
        NSUInteger zOrder1 = [obj1 zOrder];
        NSUInteger zOrder2 = [obj2 zOrder];

        if ( zOrder1 == zOrder2 )
        {
            return NSOrderedSame;
        }
        else if ( zOrder1 > zOrder2 )
        {
            return NSOrderedAscending;
        }
        else
        {
            return NSOrderedDescending;
        }
    }];

    return sortedLayoutItems;
}

- (BOOL)acceptsFirstResponder
{
    return YES;
}

- (BOOL)becomeFirstResponder
{
    BOOL didBecomeFirstResponder = [super becomeFirstResponder];

    if ( didBecomeFirstResponder )
    {
        [self setKeyboardFocusRingNeedsDisplayInRect:self.bounds];

        NSInteger selectedLayoutItemIndex = 0;

        // If user is tabbing through the key loop and that's how this element became first responder,
        // select the first or last layout item depending on the direction of motion through the key loop.
        NSEvent *event = [NSApp currentEvent];
        if ( [event type] == NSKeyDown )
        {
            NSString *eventCharacters = [event characters];
            if ( [eventCharacters length] == 1 )
            {
                unichar c = [eventCharacters characterAtIndex:0];
                if ( c == NSBackTabCharacter )
                {
                    selectedLayoutItemIndex = self.layoutItems.count - 1;
                }
            }
        }
        
        self.selectedLayoutItemIndex = selectedLayoutItemIndex;
    }

    return didBecomeFirstResponder;
}

- (BOOL)resignFirstResponder
{
    BOOL didResignFirstResponder = [super resignFirstResponder];

    if ( didResignFirstResponder )
    {
        [self setKeyboardFocusRingNeedsDisplayInRect:self.bounds];
        self.selectedLayoutItemIndex = -1;
    }

    return didResignFirstResponder;
}

- (void)setSelectedLayoutItemIndex:(NSInteger)selectedLayoutItemIndex
{
    if ( selectedLayoutItemIndex >= (NSInteger)self.layoutItems.count || selectedLayoutItemIndex < 0 )
    {
        _selectedLayoutItemIndex = -1;
    }
    else
    {
        _selectedLayoutItemIndex = selectedLayoutItemIndex;
        [self bringItemToTop:self.selectedLayoutItemIndex];
    }
    
    NSAccessibilityPostNotification(self, NSAccessibilityFocusedUIElementChangedNotification);
   
    [self setNeedsDisplay:YES];
}

- (AAPLLayoutItem *)selectedLayoutItem
{
    AAPLLayoutItem *selectedLayoutItem = nil;
    NSInteger selectedIndex = self.selectedLayoutItemIndex;
    if ( selectedIndex >= 0 && selectedIndex < (NSInteger)self.layoutItems.count )
    {
        selectedLayoutItem = self.layoutItems[selectedIndex];
    }
    
    return selectedLayoutItem;
}

- (void)setSelectedLayoutItem:(AAPLLayoutItem *)layoutItem
{
    NSInteger itemIndex = [self.layoutItems indexOfObject:layoutItem];
    itemIndex = (itemIndex != NSNotFound) ? itemIndex : -1;
    self.selectedLayoutItemIndex = itemIndex;
}

- (void)keyDown:(NSEvent *)keyEvent
{
    if ( keyEvent.type == NSKeyDown )
    {
        NSString *eventCharacters = [keyEvent charactersIgnoringModifiers];
        if ( [eventCharacters length] != 1 )
        {
            return;
        }
        
        unichar c = [eventCharacters characterAtIndex:0];
        NSInteger existingSelectionIndex = self.selectedLayoutItemIndex;
        if ( c == NSTabCharacter )
        {
            if ( existingSelectionIndex < (NSInteger)(self.layoutItems.count - 1) )
            {
                self.selectedLayoutItemIndex++;
                return;
            }
        }
        else if ( c == NSBackTabCharacter )
        {
            if ( existingSelectionIndex > 0 )
            {
                self.selectedLayoutItemIndex--;
                return;
            }
        }
        else if ( ([keyEvent modifierFlags] & NSNumericPadKeyMask) && existingSelectionIndex >= 0 )
        {
            AAPLLayoutItem *layoutItem = self.layoutItems[existingSelectionIndex];
            NSRect bounds = layoutItem.bounds;
            if ( c == NSDownArrowFunctionKey )
            {
                bounds.origin.y -= AAPLLayoutItemMoveDelta;
            }
            if ( c == NSUpArrowFunctionKey )
            {
                bounds.origin.y += AAPLLayoutItemMoveDelta;
            }
            if ( c == NSLeftArrowFunctionKey )
            {
                bounds.origin.x -= AAPLLayoutItemMoveDelta;
            }
            if ( c == NSRightArrowFunctionKey )
            {
                bounds.origin.x += AAPLLayoutItemMoveDelta;
            }

            if ( !NSEqualRects(bounds, layoutItem.bounds) )
            {
                layoutItem.bounds = bounds;
                self.needsDisplay = YES;
                return;
            }
        }
    }

    [super keyDown:keyEvent];
}

- (AAPLHandlePosition)hitTestForHandleAtPoint:(NSPoint)point
{
    AAPLHandlePosition hitTestHandle = AAPLHandlePositionUnknown;

    if ( self.selectedLayoutItemIndex >= 0 )
    {
        for ( AAPLHandlePosition position = AAPLHandlePositionNorth; position <= AAPLHandlePositionNorthWest; position ++ )
        {
            NSRect handleRect = [self handleRectForItemIndex:self.selectedLayoutItemIndex position:position];

            if ( NSPointInRect(point, handleRect) )
            {
                hitTestHandle = position;
                break;
            }
        }
    }

    return hitTestHandle;
}

- (AAPLLayoutItem *)hitTestForLayoutItemAtPoint:(NSPoint)point
{
    AAPLLayoutItem *hitTestLayoutItem = nil;

    for ( AAPLLayoutItem *layoutItem in [self layoutItemsInZOrder] )
    {
        if ( NSPointInRect(point, layoutItem.bounds) )
        {
            hitTestLayoutItem = layoutItem;
            break;
        }
    }
    
    return hitTestLayoutItem;
}

- (void)mouseDown:(NSEvent *)mouseEvent
{
    NSPoint mouseDownPoint = [self convertPoint:mouseEvent.locationInWindow fromView:nil];
    AAPLLayoutItem *selectedLayoutItem = self.selectedLayoutItem;
    AAPLHandlePosition selectedHandlePosition = [self hitTestForHandleAtPoint:mouseDownPoint];

    if ( selectedHandlePosition == AAPLHandlePositionUnknown )
    {
        selectedLayoutItem = [self hitTestForLayoutItemAtPoint:mouseDownPoint];
        [self setSelectedLayoutItem:selectedLayoutItem];
    }

    NSPoint mousePoint;
    CGFloat deltaX;
    CGFloat deltaY;
    CGRect bounds = selectedLayoutItem.bounds;

    NSEvent *nextEvent = [[self window] nextEventMatchingMask: NSLeftMouseUpMask | NSLeftMouseDraggedMask];
    while ( selectedLayoutItem != nil && nextEvent.type != NSLeftMouseUp )
    {
        mousePoint = [self convertPoint:nextEvent.locationInWindow fromView:nil];
        deltaX = mousePoint.x - mouseDownPoint.x;
        deltaY = mousePoint.y - mouseDownPoint.y;

        selectedLayoutItem.bounds = [self rectForRect:bounds movedByHandle:selectedHandlePosition deltaX:deltaX deltaY:deltaY];
                 
        [self setNeedsDisplay:YES];
        nextEvent = [[self window] nextEventMatchingMask: NSLeftMouseUpMask | NSLeftMouseDraggedMask];
    };
}

- (NSRect)rectForRect:(NSRect)rect movedByHandle:(AAPLHandlePosition)handle deltaX:(CGFloat)deltaX deltaY:(CGFloat)deltaY
{
    CGFloat originX = rect.origin.x;
    CGFloat originY = rect.origin.y;
    CGFloat width = rect.size.width;
    CGFloat height = rect.size.height;

    CGFloat eastDeltaX = MAX(MIN(deltaX, self.bounds.size.width - width - originX), -(width - AAPLLayoutItemMinSize));
    CGFloat westDeltaX = MAX(MIN(deltaX, width - AAPLLayoutItemMinSize), -originX);
    CGFloat northDeltaY = MAX(MIN(deltaY, self.bounds.size.height - height - originY), -(height - AAPLLayoutItemMinSize));
    CGFloat southDeltaY = MAX(MIN(deltaY, height - AAPLLayoutItemMinSize), -originY);

    switch ( handle )
    {
        case AAPLHandlePositionNorth:
            height += northDeltaY;
            break;
        case AAPLHandlePositionNorthEast:
            width += eastDeltaX;
            height += northDeltaY;
            break;
        case AAPLHandlePositionEast:
            width += eastDeltaX;
            break;
        case AAPLHandlePositionSouthEast:
            originY += southDeltaY;
            width += eastDeltaX;
            height -= southDeltaY;
            break;
        case AAPLHandlePositionSouth:
            originY += southDeltaY;
            height -= southDeltaY;
            break;
        case AAPLHandlePositionSouthWest:
            originX += westDeltaX;
            originY += southDeltaY;
            width -= westDeltaX;
            height -= southDeltaY;
            break;
        case AAPLHandlePositionWest:
            originX += westDeltaX;
            width -= westDeltaX;
            break;
        case AAPLHandlePositionNorthWest:
            originX += westDeltaX;
            width -= westDeltaX;
            height += northDeltaY;
            break;
        case AAPLHandlePositionUnknown:
            originX += MAX(MIN(deltaX, self.bounds.size.width - width - originX), -originX);
            originY += MAX(MIN(deltaY, self.bounds.size.height - height - originY), -originY);
            break;
        default:
            break;
    }

    return NSMakeRect(originX, originY, width, height);
}


- (NSRect)rectForItemIndex:(NSInteger)itemIndex
{
    AAPLLayoutItem *layoutItem = self.layoutItems[itemIndex];
    return layoutItem.bounds;
}

- (AAPLHandlePosition)handleForPoint:(NSPoint)point
{
    AAPLHandlePosition handlePosition = AAPLHandlePositionUnknown;
    for ( AAPLHandlePosition position = AAPLHandlePositionNorth; position <= AAPLHandlePositionNorthWest; position++ )
    {
        if ( NSPointInRect(point, [self handleRectForItemIndex:self.selectedLayoutItemIndex position:position]) )
        {
            handlePosition = position;
            break;
        }
    }
    return handlePosition;
}

- (NSRect)handleRectForItemIndex:(NSInteger)itemIndex position:(AAPLHandlePosition)position
{
    NSRect itemRect = [self rectForItemIndex:itemIndex];
    NSRect handleRect = NSZeroRect;
    CGFloat size = AAPLLayoutItemHandleSize;
    CGFloat halfSize = size / 2.0f;
    switch ( position )
    {
        case AAPLHandlePositionNorth:
            handleRect = NSMakeRect(NSMidX(itemRect), NSMaxY(itemRect), size, size);
            break;
        case AAPLHandlePositionNorthEast:
            handleRect = NSMakeRect(NSMaxX(itemRect), NSMaxY(itemRect), size, size);
            break;
        case AAPLHandlePositionEast:
            handleRect = NSMakeRect(NSMaxX(itemRect), NSMidY(itemRect), size, size);
            break;
        case AAPLHandlePositionSouthEast:
            handleRect = NSMakeRect(NSMaxX(itemRect), NSMinY(itemRect), size, size);
            break;
        case AAPLHandlePositionSouth:
            handleRect = NSMakeRect(NSMidX(itemRect), NSMinY(itemRect), size, size);
            break;
        case AAPLHandlePositionSouthWest:
            handleRect = NSMakeRect(NSMinX(itemRect), NSMinY(itemRect), size, size);
            break;
        case AAPLHandlePositionWest:
            handleRect = NSMakeRect(NSMinX(itemRect), NSMidY(itemRect), size, size);
            break;
        case AAPLHandlePositionNorthWest:
            handleRect = NSMakeRect(NSMinX(itemRect), NSMaxY(itemRect), size, size);
            break;
        default:
            break;
    }
    handleRect.origin.x -= halfSize;
    handleRect.origin.y -= halfSize;
    return handleRect;
}

- (void)drawRect:(NSRect)dirtyRect
{
    NSRect bounds = self.bounds;

    BOOL isFirstResponder = [[NSApp mainWindow].firstResponder isEqual:self];
    
    if ( !isFirstResponder )
    {
        self.selectedLayoutItemIndex = -1;
    }

    NSBezierPath *outline = [NSBezierPath bezierPathWithRect:bounds];
    [outline setLineWidth:2.0];
    [[NSColor whiteColor] set];
    [outline fill];
    [[NSColor blackColor] set];
    [outline stroke];
    
    NSEnumerator *enumerator = [[self layoutItemsInZOrder] reverseObjectEnumerator];
    AAPLLayoutItem *layoutItem;
    while (layoutItem = [enumerator nextObject])
    {
        NSBezierPath *itemPath = [NSBezierPath bezierPathWithRect:layoutItem.bounds];
        [[NSColor blueColor] set];
        [itemPath fill];
        [[NSColor blackColor] set];
        [itemPath stroke];
    }
    
    // draw handles
    NSInteger selectedLayoutItemIndex = self.selectedLayoutItemIndex;
    if ( selectedLayoutItemIndex >= 0 )
    {
        for ( AAPLHandlePosition position = AAPLHandlePositionNorth; position <= AAPLHandlePositionNorthWest; position ++ )
        {
            NSRect handleRect = [self handleRectForItemIndex:selectedLayoutItemIndex position:position];
            NSBezierPath *handlePath = [NSBezierPath bezierPathWithRect:handleRect];
            [[NSColor grayColor] set];
            [handlePath fill];
            [[NSColor blackColor] set];
            [handlePath stroke];
        }
    }
}

#pragma mark Accessibility

- (id)accessibilityFocusedUIElement
{
    id accessibilityFocusedUIElement = [self selectedLayoutItem];
    return accessibilityFocusedUIElement != nil ? accessibilityFocusedUIElement : [super accessibilityFocusedUIElement];
}

- (NSString *)accessibilityLabel
{
    return NSLocalizedString(@"Rectangles", @"accessibility label for the layout area");
}

- (NSArray *)accessibilityChildren
{
    return self.layoutItems;
}

- (NSArray *)accessibilitySelectedChildren
{
    NSArray *accessibilitySelectedChildren = @[[self selectedLayoutItem]];
    return [accessibilitySelectedChildren count] > 0 ? accessibilitySelectedChildren : [super accessibilitySelectedChildren];
}

@end


#pragma mark - AAPLLayoutItem
@implementation AAPLLayoutItem

- (id)accessibilityParent
{
    return [super accessibilityParent];
}

- (void)setAccessibilityFrame:(NSRect)frame
{
    // Frame is in screen cordinates, we need it in view coordinates
    NSView *parentView = self.accessibilityParent;
    NSWindow *window = [parentView window];
    frame = [window convertRectFromScreen:frame];
    frame = [parentView convertRect:frame fromView:nil];
    [self setBounds:frame];
    [parentView setNeedsDisplay:YES];
}

- (NSRect)accessibilityFrame
{
    return NSAccessibilityFrameInView(self.accessibilityParent, self.bounds);
}

- (BOOL)isAccessibilityFocused
{
    return [self.accessibilityParent accessibilityFocusedUIElement] == self;
}

- (void)setAccessibilityFocused:(BOOL)accessibilityFocused
{
    id accessibilityParent = self.accessibilityParent;
    if ( accessibilityFocused )
    {
        [accessibilityParent setSelectedLayoutItem:self];
    }
    else
    {
        if ( [accessibilityParent accessibilityFocusedUIElement] == self )
        {
            [accessibilityParent setSelectedLayoutItem:nil];
        }
    }
}

- (void)setBounds:(NSRect)bounds
{
    CGFloat minSize = (AAPLLayoutItemHandleSize * 3.0f);
    id accessibilityParent = [self accessibilityParent];
    
    if ( bounds.size.height < minSize )
    {
        bounds.size.height = minSize;
    }
    if ( bounds.size.width < minSize )
    {
        bounds.size.width = minSize;
    }
    
    if ( !NSEqualPoints(_bounds.origin, bounds.origin) && [[accessibilityParent selectedLayoutItem] isEqual:self] )
    {
        NSAccessibilityPostNotification(accessibilityParent, NSAccessibilitySelectedChildrenMovedNotification);
    }
    
    _bounds = bounds;
}

@end
