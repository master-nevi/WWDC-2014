/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 An accessible, custom cell class for the two-position switch.
 
 */

#import "AAPLTwoPositionSwitchCell.h"
#import "AAPLTwoPositionSwitchView.h"

@implementation AAPLTwoPositionSwitchCell


- (NSRect)knobRectFlipped:(BOOL)inFlipped
{
    double minValue = [self minValue];
    double maxValue = [self maxValue];
    double value = [self doubleValue];
    double percent = (maxValue <= minValue) ? 0.0 : (value - minValue) / (maxValue - minValue);

    NSImage* knobImage = [NSImage imageNamed:@"SwitchHandle"];
    NSRect knobRect = NSMakeRect(0, 0, [knobImage size].width, [knobImage size].height);

    NSRect trackRect = [self trackRect];
    double offset = floor((NSWidth(trackRect) - NSWidth(knobRect) + 4.0) * percent ) - 4.0;

    knobRect.origin = NSMakePoint(trackRect.origin.x + offset, 2.0);

    return NSIntegralRect( knobRect );
}

- (void)drawKnob:(NSRect)rect
{
    BOOL isClickedOrMoved = self.trackingState == AAPLSwitchKnobClickedState || self.trackingState == AAPLSwitchKnobMovedState;
    NSImage *knobImage = [NSImage imageNamed:isClickedOrMoved ? @"SwitchHandleDown" : @"SwitchHandle"];
    [knobImage drawAtPoint:rect.origin fromRect:NSZeroRect operation:NSCompositeSourceOver fraction:(self.enabled ? 1.0 : 0.5)];
}

- (void)drawBarInside:(NSRect)rect flipped:(BOOL)flipped
{
    // avoid drawing the track
}

- (void)drawInteriorWithFrame:(NSRect)cellFrame inView:(NSView *)controlView
{
    NSImage* wellImage = [NSImage imageNamed:@"SwitchWell"];
    NSPoint trackPoint = cellFrame.origin;
    trackPoint.y += 1.0;

    if( [(NSSlider*)controlView isEnabled] )
    {
        [wellImage drawAtPoint:trackPoint fromRect:NSZeroRect operation:NSCompositeCopy fraction:1.0];
    }
    else
    {
        [wellImage drawAtPoint:trackPoint fromRect:NSZeroRect operation:NSCompositePlusLighter fraction:1.0];
        [wellImage drawAtPoint:trackPoint fromRect:NSZeroRect operation:NSCompositeSourceOver fraction:0.3];
    }

    NSImage *maskImage = [NSImage imageNamed: @"SwitchOverlayMask"];
    trackPoint.y -= 1.0;

    BOOL focused = [self showsFirstResponder] && ([self focusRingType] != NSFocusRingTypeNone);
    if ( focused )
    {
        [maskImage drawAtPoint:trackPoint fromRect:NSZeroRect operation:NSCompositeSourceOver fraction:1.0];
    }

    [super drawInteriorWithFrame:cellFrame inView:controlView];

    if( !focused )
    {
        [maskImage drawAtPoint:trackPoint fromRect:NSZeroRect operation:NSCompositeSourceOver fraction:1.0];
    }
}

- (BOOL)startTrackingAt:(NSPoint)startPoint inView:(NSView *)controlView
{
    if ([(AAPLTwoPositionSwitchView *)controlView isAnimating])
    {
        return NO;
    }

    // Don't track if mouseDown is not on the knob
    NSRect knobRect = [self knobRectFlipped:controlView.flipped];
    if (NSPointInRect(startPoint, knobRect))
    {
        self.trackingState = AAPLSwitchKnobClickedState;
        return [super startTrackingAt:startPoint inView:controlView];
    }

    self.trackingState = AAPLSwitchTrackClickedState;
    return YES;
}

- (BOOL)continueTracking:(NSPoint)lastPoint at:(NSPoint)currentPoint inView:(NSView *)controlView
{
    if ( (self.trackingState == AAPLSwitchKnobClickedState) && !NSEqualPoints(lastPoint, currentPoint) && !NSEqualPoints(lastPoint, NSZeroPoint) )
    {
        self.trackingState = AAPLSwitchKnobMovedState;
    }

    return [super continueTracking:lastPoint at:currentPoint inView:controlView];
}


- (void)stopTracking:(NSPoint)lastPoint at:(NSPoint)stopPoint inView:(NSView *)controlView mouseIsUp:(BOOL)flag
{
    [super stopTracking:lastPoint at:stopPoint inView:controlView mouseIsUp:flag];

    AAPLTwoPositionSwitchView *switchView = (AAPLTwoPositionSwitchView *)self.controlView;
    double startValue = [switchView targetValue];
    double value = [self doubleValue];

    switch( self.trackingState )
    {
        case AAPLSwitchKnobClickedState:
        case AAPLSwitchTrackClickedState:
            [switchView setDoubleValue:(startValue == 0.0) ? 1.0 : 0.0 animate:YES];
            break;
        case AAPLSwitchKnobMovedState:
            if ( ABS(startValue - value) < 0.2 )
            {
                [switchView setDoubleValue:startValue animate:YES];
            }
            else
            {
                [switchView setDoubleValue:(startValue == 0.0) ? 1.0 : 0.0 animate:YES];
            }
            break;
    }

    self.trackingState = AAPLSwitchKnobNoState;
}

#pragma mark Accessibility

- (NSString *)accessibilityLabel
{
    return NSLocalizedString(@"Switch", @"accessibility label of the three position switch");
}

- (id)accessibilityValue
{
    NSString *value;
    AAPLTwoPositionSwitchView *controlView = (AAPLTwoPositionSwitchView *)self.controlView;
    if ( controlView.state == NSOffState )
    {
        value =  NSLocalizedString(@"off", @"accessibility value for the state of OFF for the switch");
    }
    else
    {
        value = NSLocalizedString(@"on", @"accessibility value for the state of ON for the switch");
    }

    return value;
}

- (BOOL)accessibilityPerformPress
{
    AAPLTwoPositionSwitchView *controlView = (AAPLTwoPositionSwitchView *)self.controlView;
    [controlView setState:controlView.state == NSOffState ? NSOnState : NSOffState];
    return YES;
}

@end
