/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 An example demonstrating making an accessible, custom two-position switch.
  
  
 
 */

#import "AAPLTwoPositionSwitchView.h"
#import "AAPLTwoPositionSwitchCell.h"

static NSTimeInterval kAAPLSwitchAnimationDuration = 0.15;

@implementation AAPLTwoPositionSwitchView

+ (Class)cellClass
{
    return [AAPLTwoPositionSwitchCell class];
}

+ (id)defaultAnimationForKey:(NSString *)key
{
    if ( [key isEqualToString:@"doubleValue"] )
    {
        return [self defaultAnimationForKey:@"frameOrigin"];
    }
	else
    {
        return [super defaultAnimationForKey:key];
    }
}

+ (NSSet *)keyPathsForValuesAffectingAnimating
{
    return [NSSet setWithObjects:@"doubleValue", @"targetValue", nil];
}

- (id)initWithFrame:(NSRect)frame
{
    NSImage *maskImage = [NSImage imageNamed:@"SwitchOverlayMask"];
    NSRect rect = NSMakeRect(frame.origin.x, frame.origin.y, [maskImage size].width, [maskImage size].height);

    self = [super initWithFrame:rect];

    if ( self != nil )
    {
        self.doubleValue = 0.0;
        self.minValue = 0.0;
        self.maxValue = 1.0;
        self.continuous = NO;
    }

    return self;
}

- (BOOL)isAnimating
{
    return self.targetValue != self.doubleValue;
}

- (BOOL)isFlipped
{
    return NO;
}

- (void)setDoubleValue:(double)value animate:(BOOL)animate
{
    self.targetValue = value;

    if ( self.doubleValue != value )
    {
        if ( animate )
        {
            [[NSAnimationContext currentContext] setDuration:kAAPLSwitchAnimationDuration*ABS(value - self.doubleValue)];
            [[self animator] setDoubleValue:value];
        }
        else
        {
            self.doubleValue = value;
        }
    }
}

- (void)setState:(NSInteger)inValue
{
    [self setState:inValue animate:YES];
}

- (void)setState:(NSInteger)inValue animate:(BOOL)animate
{
    double value = (inValue == NSOnState) ? 1.0 : 0.0;

    if ( value != self.targetValue )
    {
        [self setDoubleValue:value animate:animate];
    }
}

- (NSInteger)state
{
    double targetValue = self.targetValue;

    if ( targetValue == 0.0 )
    {
        return NSOffState;
    }
    else if ( targetValue == 1.0 )
    {
        return NSOnState;
    }
    else
    {
        return NSMixedState;
    }
}

#pragma mark Keyboard Input

- (void)moveRight:(id)sender
{
    if ( self.enabled )
    {
        [self setDoubleValue:1.0 animate:YES];
        [self sendAction:self.action to:self.target];
    }
}

- (void)moveLeft:(id)sender
{
    if ( [self isEnabled] )
    {
        [self setDoubleValue:0.0 animate:YES];
        [self sendAction:self.action to:self.target];
    }
}

- (void)moveUp:(id)sender
{
    [self moveRight:sender];
}

- (void)moveDown:(id)sender
{
    [self moveLeft:sender];
}

- (void)pageUp:(id)sender
{
    [self moveRight:sender];
}

- (void)pageDown:(id)sender
{
    [self moveLeft:sender];
}

@end
