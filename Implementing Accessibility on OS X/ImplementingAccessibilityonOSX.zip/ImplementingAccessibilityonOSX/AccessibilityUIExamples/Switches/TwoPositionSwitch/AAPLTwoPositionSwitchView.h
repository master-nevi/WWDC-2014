/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 An example demonstrating making an accessible, custom two-position switch.
  
  
 
 */

#import <Cocoa/Cocoa.h>

@interface AAPLTwoPositionSwitchView : NSSlider

@property (nonatomic) double targetValue;

- (BOOL)isAnimating;
- (void)setDoubleValue:(double)value animate:(BOOL)animate;
- (NSInteger)state;
- (void)setState:(NSInteger)inValue;

@end
