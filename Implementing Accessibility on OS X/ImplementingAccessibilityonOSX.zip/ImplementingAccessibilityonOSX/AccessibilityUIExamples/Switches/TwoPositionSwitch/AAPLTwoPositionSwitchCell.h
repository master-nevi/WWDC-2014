/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 An accessible, custom cell class for the two-position switch.
 
 */

#import <Cocoa/Cocoa.h>

NS_ENUM(NSInteger, AAPLSwitchKnobState) {
    AAPLSwitchKnobClickedState,
    AAPLSwitchTrackClickedState,
    AAPLSwitchKnobMovedState,
    AAPLSwitchKnobNoState,
};

@interface AAPLTwoPositionSwitchCell : NSSliderCell <NSAccessibilitySwitch>

@property (nonatomic) NSInteger trackingState;

@end
