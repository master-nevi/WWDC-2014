/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 An example demonstrating making an accessible, custom three-position switch.
 
 */

#import <Cocoa/Cocoa.h>

// IMPORTANT: This is not a template for developing a custom switch. This sample is
// intended to demonstrate how to add accessibility to UI that may not have been
// ideally designed. For information on how to create custom controls please visit
// http://developer.apple.com

typedef NS_ENUM(NSInteger, AAPLThreePositionSwitchPosition)
{
    AAPLThreePositionSwitchPositionLeft,
    AAPLThreePositionSwitchPositionCenter,
    AAPLThreePositionSwitchPositionRight,
};

@interface AAPLThreePositionSwitchView : NSControl

@property (nonatomic, readonly) AAPLThreePositionSwitchPosition position;
@property (nonatomic, strong) NSColor *backgroundColor;
@property (nonatomic, strong) NSColor *handleColor;

- (void)moveHandleToPreviousPositionWrapAround:(BOOL)shouldWrap;
- (void)moveHandleToNextPositionWrapAround:(BOOL)shouldWrap;
- (NSRect)handleRect;

@end
