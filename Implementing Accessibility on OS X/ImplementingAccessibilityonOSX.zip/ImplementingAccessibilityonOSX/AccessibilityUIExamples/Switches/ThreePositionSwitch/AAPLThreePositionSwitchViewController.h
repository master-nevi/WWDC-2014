/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 View controller demonstrating an accessible, custom three-position switch./abstract>
  
  
 
 */

#import <Cocoa/Cocoa.h>
#import "AAPLAccessibilityExamplesBaseViewController.h"

@class AAPLThreePositionSwitchView;

@interface AAPLThreePositionSwitchViewController : AAPLAccessibilityExamplesBaseViewController

@property (nonatomic, weak) IBOutlet NSTextField *currentValueLabel;
@property (nonatomic, weak) IBOutlet AAPLThreePositionSwitchView *threePositionSwitch;

- (IBAction)changeSwitchValue:(id)sender;

@end
