/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 An accessible, custom cell class for the three-position switch.
 
 */

#import "AAPLThreePositionSwitchCell.h"
#import "AAPLThreePositionSwitchView.h"

@implementation AAPLThreePositionSwitchCell

- (NSRect)valueIndicatorScreenRect
{
    AAPLThreePositionSwitchView *switchControl = (AAPLThreePositionSwitchView *)self.controlView;
    NSRect handleFrame = [switchControl handleRect];
    handleFrame.origin = [switchControl convertPoint:handleFrame.origin toView:nil];
    handleFrame = [switchControl.window convertRectToScreen:handleFrame];
    return handleFrame;
}

#pragma mark Accessibility

- (NSString *)accessibilityValue
{
    AAPLThreePositionSwitchView *controlView = (AAPLThreePositionSwitchView *)self.controlView;

    NSString *value = nil;
    switch ( controlView.position )
    {
        case AAPLThreePositionSwitchPositionCenter:
            value = NSLocalizedString(@"on", @"accessibility value for the state of ON for the switch");
            break;
        case AAPLThreePositionSwitchPositionRight:
            value = NSLocalizedString(@"auto", @"accessibility value for the state of AUTO for the switch");
            break;
        default:
            value = NSLocalizedString(@"off", @"accessibility value for the state of OFF for the switch");
            break;
    }
    
    return value;
}

- (NSString *)accessibilityLabel
{
    return NSLocalizedString(@"Switch", @"accessibility label of the three position switch");
}

- (NSString *)accessibilityHelp
{
    return NSLocalizedString(@"A three position switch with off, on, and auto options.", @"accessibility help for the three position switch");
}

- (BOOL)accessibilityPerformPress
{
    [(AAPLThreePositionSwitchView *)self.controlView moveHandleToNextPositionWrapAround:YES];
    return YES;
}

- (BOOL)accessibilityPerformIncrement
{
    [(AAPLThreePositionSwitchView *)self.controlView moveHandleToNextPositionWrapAround:NO];
    return YES;
}

- (BOOL)accessibilityPerformDecrement
{
    [(AAPLThreePositionSwitchView *)self.controlView moveHandleToPreviousPositionWrapAround:NO];
    return YES;
}

@end
