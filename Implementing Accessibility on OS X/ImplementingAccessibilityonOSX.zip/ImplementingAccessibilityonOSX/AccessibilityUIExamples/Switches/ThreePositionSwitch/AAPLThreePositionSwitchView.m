/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 An example demonstrating making an accessible, custom three-position switch.
 
 */

#import "AAPLThreePositionSwitchView.h"
#import "AAPLThreePositionSwitchCell.h"


static const CGFloat AAPLThreePositionSwitchHandleWidth = 52.0f;

// IMPORTANT: This is not a template for developing a custom switch. This sample is
// intended to demonstrate how to add accessibility to UI that may not have been
// ideally designed. For information on how to create custom controls please visit
// http://developer.apple.com

@interface AAPLThreePositionSwitchView ()

@property (nonatomic) NSPoint dragTrackingStartLocation;
@property (nonatomic) NSPoint dragTrackingCurrentLocation;
@property (nonatomic) AAPLThreePositionSwitchPosition position;

@end

@implementation AAPLThreePositionSwitchView

+ (Class)cellClass
{
    return [AAPLThreePositionSwitchCell class];
}

- (id)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];

    if ( self != nil )
    {
        self.dragTrackingStartLocation = NSMakePoint(-1, -1);
        self.backgroundColor = [NSColor redColor];
        self.handleColor = [NSColor blueColor];
    }
    
    return self;
}

- (NSRect)handleRect
{
    NSRect bounds = self.bounds;
    CGFloat originX;
    switch ( self.position )
    {
        case AAPLThreePositionSwitchPositionCenter:
            originX = (bounds.size.width / 2.0f) - (AAPLThreePositionSwitchHandleWidth / 2.0f);
            break;
        case AAPLThreePositionSwitchPositionRight:
            originX = bounds.size.width - AAPLThreePositionSwitchHandleWidth;
            break;
        default:
            originX = 0;
            break;
    }

    // Offset by current drag distance.
    originX -= (self.dragTrackingStartLocation.x - self.dragTrackingCurrentLocation.x);

    // Clamp to view bounds.
    originX = MIN(MAX(0, originX), self.bounds.size.width - AAPLThreePositionSwitchHandleWidth);

    return NSMakeRect(originX,
                      0,
                      AAPLThreePositionSwitchHandleWidth,
                      bounds.size.height);
}

- (void)drawFocusRingMask
{
    NSRectFill([self focusRingMaskBounds]);
}

- (NSRect)focusRingMaskBounds
{
    return [self handleRect];
}

- (void)drawRect:(NSRect)dirtyRect
{
    NSRect drawRect = NSZeroRect;
    NSRect background = self.bounds;
    
    [self.backgroundColor setFill];
    drawRect = NSIntersectionRect(dirtyRect, background);
    NSRectFill(drawRect);
    
    NSRect imageRect = NSZeroRect;
    NSImage *wellImage = [NSImage imageNamed:@"SwitchWell"];
    imageRect.size = [wellImage size];
    NSPoint trackPoint = background.origin;
    trackPoint.y += 1.0;
    [wellImage drawAtPoint:trackPoint fromRect:imageRect operation:NSCompositeCopy fraction:1.0f];
    
    NSImage *maskImage = [NSImage imageNamed:@"SwitchOverlayMask"];
    trackPoint.y -= 1.0;
    imageRect.size = maskImage.size;
    [maskImage drawAtPoint:trackPoint fromRect:imageRect operation:NSCompositeSourceOver fraction:1.0f];
    
    NSRect handleRect = [self handleRect];
    if ( self.dragTrackingStartLocation.x < 0 && self.dragTrackingStartLocation.y < 0 )
    {
        maskImage = [NSImage imageNamed:@"SwitchHandle"];
    }
    else
    {
        maskImage = [NSImage imageNamed:@"SwitchHandleDown"];
    }
    
    imageRect.size = maskImage.size;
    CGPoint origin = handleRect.origin;
    origin.x -= 3.5f;
    origin.y = (background.size.height - imageRect.size.height) / 2.0f;
    [maskImage drawAtPoint:origin fromRect:imageRect operation:NSCompositeSourceOver fraction:1.0f];
}

- (void)snapHandleToClosestPosition
{
    NSRect handleRect = [self handleRect];
    NSRect bounds = self.bounds;
    CGFloat oneThirdWidth = bounds.size.width / 3.0f;
    
    AAPLThreePositionSwitchPosition desiredPosition;

    CGFloat xPos = NSMidX(handleRect);
    if ( xPos < (bounds.origin.x + oneThirdWidth) )
    {
        desiredPosition = AAPLThreePositionSwitchPositionLeft;
    }
    else if ( xPos > (bounds.origin.x + (oneThirdWidth * 2.0f)) )
    {
        desiredPosition = AAPLThreePositionSwitchPositionRight;
    }
    else
    {
        desiredPosition = AAPLThreePositionSwitchPositionCenter;
    }
    
    if ( desiredPosition != self.position )
    {
        self.position = desiredPosition;
        NSActionCell *cell = [self cell];
        [NSApp sendAction:cell.action to:cell.target from:self];
    }
}

- (void)moveHandleToPreviousPositionWrapAround:(BOOL)shouldWrap
{
    [self moveHandleToNextPositionRight:NO wrapAround:shouldWrap];

}
- (void)moveHandleToNextPositionWrapAround:(BOOL)shouldWrap
{
    [self moveHandleToNextPositionRight:YES wrapAround:shouldWrap];
}

- (void)moveHandleToNextPositionRight:(BOOL)rightDirection wrapAround:(BOOL)shouldWrap
{
    AAPLThreePositionSwitchPosition nextPosition;
    
    switch ( self.position )
    {
        case AAPLThreePositionSwitchPositionLeft:
            if ( rightDirection )
                nextPosition = AAPLThreePositionSwitchPositionCenter;
            else
                nextPosition = shouldWrap ? AAPLThreePositionSwitchPositionRight : AAPLThreePositionSwitchPositionLeft;
            break;
        case AAPLThreePositionSwitchPositionCenter:
            nextPosition = rightDirection ? AAPLThreePositionSwitchPositionRight : AAPLThreePositionSwitchPositionLeft;
            break;
        case AAPLThreePositionSwitchPositionRight:
            if ( rightDirection )
                nextPosition = shouldWrap ? AAPLThreePositionSwitchPositionLeft : AAPLThreePositionSwitchPositionRight;
            else
                nextPosition = AAPLThreePositionSwitchPositionCenter;
            break;
    }
    
    if ( nextPosition != self.position )
    {
        self.position = nextPosition;
        NSActionCell *cell = [self cell];
        [NSApp sendAction:cell.action to:cell.target from:self];
        [self display];
    }
}

#pragma mark Mouse events

- (void)handleMouseDrag:(NSEvent *)mouseEvent
{
    NSEvent *currentEvent = mouseEvent;
    NSWindow *window = self.window;
    NSUInteger eventMask = ( NSLeftMouseDraggedMask | NSLeftMouseUpMask);
    NSDate *untilDate = [NSDate distantFuture];

    do
    {
        NSPoint mousePoint = [self convertPoint:currentEvent.locationInWindow fromView:nil];
        switch ( currentEvent.type )
        {
            case NSLeftMouseDown:
            case NSLeftMouseDragged:
                self.dragTrackingCurrentLocation = mousePoint;
                currentEvent = [window nextEventMatchingMask:eventMask
                                                   untilDate:untilDate
                                                      inMode:NSEventTrackingRunLoopMode
                                                     dequeue:YES];
                break;
            default:
                currentEvent = nil;
                break;
        }
        [self display];
        
    }
    while ( currentEvent != nil );
    
    [self snapHandleToClosestPosition];
    self.dragTrackingCurrentLocation = self.dragTrackingStartLocation = NSMakePoint(-1,-1);
    [self display];

}

- (void)mouseDown:(NSEvent *)mouseEvent
{
    // If we are not enabled or can't become the first responder, don't do anything.
    if ( !self.enabled || ![self.window makeFirstResponder:self] )
    {
        return;
    }
    
    // Determine the location, in our local coordinate system, where the user clicked.
    NSPoint location = [self convertPoint:mouseEvent.locationInWindow fromView:nil];

    BOOL pointInKnob = CGRectContainsPoint([self handleRect], location);
    if ( pointInKnob )
    {
        // When we receive a mouse down event, we reset the dragTrackingLocation.
        self.dragTrackingStartLocation = location;
        [self handleMouseDrag:mouseEvent];
    }
    else
    {
        // Treat clicks outside handle bounds as increment/decrement actions.
        BOOL moveRight = location.x > [self handleRect].origin.x;
        [self moveHandleToNextPositionRight:moveRight wrapAround:NO];
    }
}

#pragma mark Keyboard events

- (void)keyDown:(NSEvent *)keyEvent
{
    // Step through values on spacebar.
    if ( [[keyEvent characters] isEqualToString:@" "] )
    {
        [self moveHandleToNextPositionWrapAround:YES];
    }
    
    // Arrow keys are associated with the numeric keypad.
    if ( [keyEvent modifierFlags] & NSNumericPadKeyMask )
    {
        [self interpretKeyEvents:@[keyEvent]];
    }
    else
    {
        [super keyDown:keyEvent];
    }
}

- (IBAction)moveLeft:(id)sender
{
    [self moveHandleToPreviousPositionWrapAround:NO];
}

- (IBAction)moveRight:(id)sender
{
    [self moveHandleToNextPositionWrapAround:NO];
}

@end
