/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 An accessible, custom cell class for the three-position switch.
 
 */

#import <Cocoa/Cocoa.h>
#import "AAPLThreePositionSwitchView.h"

@interface AAPLThreePositionSwitchCell : NSActionCell <NSAccessibilitySwitch>

// the frame of the handle in screen coordinate
- (NSRect)valueIndicatorScreenRect;

@end

