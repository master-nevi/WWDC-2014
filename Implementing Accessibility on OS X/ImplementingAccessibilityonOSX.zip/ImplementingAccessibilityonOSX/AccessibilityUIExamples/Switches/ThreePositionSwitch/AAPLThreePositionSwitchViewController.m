/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 View controller demonstrating an accessible, custom three-position switch./abstract>
  
  
 
 */

#import "AAPLThreePositionSwitchViewController.h"
#import "AAPLThreePositionSwitchView.h"

@implementation AAPLThreePositionSwitchViewController

- (IBAction)changeSwitchValue:(id)sender
{
    NSCell *cell = [self.threePositionSwitch cell];
    NSString *description = cell.accessibilityValue;
    self.currentValueLabel.stringValue = description.uppercaseString;
}
          
@end
