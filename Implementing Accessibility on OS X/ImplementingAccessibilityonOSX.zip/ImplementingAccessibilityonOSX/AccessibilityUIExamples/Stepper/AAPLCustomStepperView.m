/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 An example demonstrating adding accessibility to an NSOpenGLView subclass that behaves like a stepper by implementing the NSAccessibilityStepper protocol.
 
 */

#import "AAPLCustomStepperView.h"
#import <OpenGL/gl.h>
#import <OpenGL/OpenGL.h>


static const CGFloat AAPLStepperMinValue = 0.0f;
static const CGFloat AAPLStepperMaxValue = 100.0f;
static const CGFloat AAPLStepperStepSize = 5.0f;
static const CGFloat AAPLAnimationRefreshRate = 1.0f/60.f; // in frames per second

// IMPORTANT: This is not a template for developing a custom stepper. This sample is
// intended to demonstrate how to add accessibility to UI that may not have been
// ideally designed. For information on how to create custom controls please visit
// http://developer.apple.com

@interface AAPLCustomStepperView ()

@property (nonatomic, strong) NSTimer *timer;

@property (nonatomic) BOOL upButtonMouseDown;
@property (nonatomic) BOOL upButtonShowDepressed;

@property (nonatomic) BOOL downButtonMouseDown;
@property (nonatomic) BOOL downButtonShowDepressed;

@property (nonatomic) GLuint *textures;
@property (nonatomic) CGSize *textureSizes;

@property (nonatomic) CGFloat minValue;
@property (nonatomic) CGFloat maxValue;
@property (nonatomic) CGFloat stepSize;

- (NSRect)upButtonRect;
- (NSRect)downButtonRect;

- (void)performIncrementButtonPress;
- (void)performDecrementButtonPress;

@end

@implementation AAPLCustomStepperView

+ (NSOpenGLPixelFormat *)defaultPixelFormat
{
    NSOpenGLPixelFormatAttribute attributes[] =
    {
        NSOpenGLPFADoubleBuffer,
        NSOpenGLPFAStencilSize, 8,
        NSOpenGLPFADepthSize, (NSOpenGLPixelFormatAttribute)32,
        NSOpenGLPFAMultisample,
        NSOpenGLPFASampleBuffers, (NSOpenGLPixelFormatAttribute)1,
        NSOpenGLPFASamples, (NSOpenGLPixelFormatAttribute)9, 0
    };
    
    return [[NSOpenGLPixelFormat alloc] initWithAttributes:attributes];
}

- (id)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];
    if ( self != nil )
    {
        GLint swapInterval = 1;
        [self.openGLContext setValues:&swapInterval forParameter:NSOpenGLCPSwapInterval];

        self.minValue = AAPLStepperMinValue;
        self.maxValue = AAPLStepperMaxValue;
        self.stepSize = AAPLStepperStepSize;

        self.timer = [NSTimer scheduledTimerWithTimeInterval:AAPLAnimationRefreshRate target:self selector:@selector(animate:) userInfo:nil repeats:YES];

        // Register for mouse events that affect drawing.
        NSTrackingArea *trackingArea = [[NSTrackingArea alloc] initWithRect:self.bounds
                                                                    options:NSTrackingMouseEnteredAndExited | NSTrackingActiveWhenFirstResponder |  NSTrackingEnabledDuringMouseDrag
                                                                      owner:self
                                                                   userInfo:nil];
        [self addTrackingArea:trackingArea];
        
        [self initOpenGLStates];
    }
    
    return self;
}

- (void)animate:(NSTimer *)timer
{
    [self setNeedsDisplay:YES];
}

- (BOOL)acceptsFirstResponder
{
    return YES;
}

- (void)drawFocusRingMask
{
    NSRectFill(self.bounds);
}

- (NSRect)focusRingMaskBounds
{
    return self.bounds;
}

- (void)sendAction
{
    [self.target performSelectorOnMainThread:self.action withObject:self waitUntilDone:YES];
}

- (NSRect)upButtonRect
{
    NSRect bounds = self.bounds;
    return NSMakeRect(bounds.origin.x,
                      NSMidY(bounds),
                      bounds.size.width,
                      bounds.size.height / 2.0f);
}

- (NSRect)downButtonRect
{
    NSRect bounds = self.bounds;
    return NSMakeRect(bounds.origin.x,
                      bounds.origin.y,
                      bounds.size.width,
                      bounds.size.height / 2.0f);
}

- (void)performIncrementButtonPress
{
    self.upButtonShowDepressed = YES;
    self.downButtonShowDepressed = NO;
    [self setNeedsDisplay:YES];
    
    double delayInSeconds = 0.01;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        self.upButtonShowDepressed = NO;
        self.downButtonShowDepressed = NO;
        [self setNeedsDisplay:YES];
        [self increment];
    });
}

- (void)performDecrementButtonPress
{
    self.upButtonShowDepressed = NO;
    self.downButtonShowDepressed = YES;
    [self setNeedsDisplay:YES];
    
    double delayInSeconds = 0.01;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        self.upButtonShowDepressed = NO;
        self.downButtonShowDepressed = NO;
        [self setNeedsDisplay:YES];
        [self decrement];
    });
}

- (void)setValue:(CGFloat)value
{
    if ( value < self.minValue )
    {
        value = self.minValue;
    }
    if ( value > self.maxValue )
    {
        value = self.maxValue;
    }
    _value = value;

    [self setNeedsDisplay:YES];
}

- (void)increment
{
    self.value += self.stepSize;
    [self sendAction];
}

- (void)decrement
{
    self.value -= self.stepSize;
    [self sendAction];
}

#pragma mark Mouse events
- (void)mouseDown:(NSEvent *)mouseEvent
{
    [super mouseDown:mouseEvent];
    
    NSPoint mouseDownPoint = [self convertPoint:mouseEvent.locationInWindow fromView:nil];
    if ( NSPointInRect(mouseDownPoint, [self upButtonRect]) )
    {
        self.upButtonMouseDown = YES;
        self.upButtonShowDepressed = YES;
        self.downButtonMouseDown = NO;
        self.downButtonShowDepressed = NO;
    }
    else if ( NSPointInRect(mouseDownPoint, [self downButtonRect]) )
    {
        self.upButtonMouseDown = NO;
        self.upButtonShowDepressed = NO;
        self.downButtonMouseDown = YES;
        self.downButtonShowDepressed = YES;
    }

    [self setNeedsDisplay:YES];
}

- (void)mouseUp:(NSEvent *)mouseEvent
{
    [super mouseUp:mouseEvent];
    
    NSPoint mouseUpPoint = [self convertPoint:mouseEvent.locationInWindow fromView:nil];
    if ( self.upButtonMouseDown &&
         self.upButtonShowDepressed &&
         NSPointInRect(mouseUpPoint, [self upButtonRect]) )
    {
        [self increment];
    }
    else if ( self.downButtonMouseDown &&
              self.downButtonShowDepressed &&
              NSPointInRect(mouseUpPoint, [self downButtonRect]) )
    {
        [self decrement];
    }
    
    self.upButtonMouseDown = NO;
    self.upButtonShowDepressed = NO;
    self.downButtonMouseDown = NO;
    self.downButtonShowDepressed = NO;

    [self setNeedsDisplay:YES];
}

- (void)mouseEntered:(NSEvent *)mouseEvent
{
    [super mouseEntered:mouseEvent];
    
    NSPoint mousePoint = [self convertPoint:mouseEvent.locationInWindow fromView:nil];

    if ( NSPointInRect(mousePoint, [self upButtonRect]))
    {
        self.upButtonShowDepressed = self.upButtonMouseDown;
    }
    else if ( NSPointInRect(mousePoint, [self downButtonRect]) )
    {
        self.downButtonShowDepressed = self.downButtonMouseDown;
    }
    
    [self setNeedsDisplay:YES];
}

- (void)mouseExited:(NSEvent *)mouseEvent
{
    [super mouseExited:mouseEvent];

    self.upButtonShowDepressed = NO;
    self.downButtonShowDepressed = NO;
    
    [self setNeedsDisplay:YES];
}


#pragma mark Keyboard events

- (void)keyDown:(NSEvent *)theEvent
{
    // Increment value on spacebar.
    if ( [[theEvent characters] isEqualToString:@" "] )
    {
        [self performIncrementButtonPress];
    }
    
    // Arrow keys are associated with the numeric keypad
    if ( [theEvent modifierFlags] & NSNumericPadKeyMask )
    {
        [self interpretKeyEvents:@[theEvent]];
    }
    else
    {
        [super keyDown:theEvent];
    }
}

- (IBAction)moveUp:(id)sender
{
    [self performIncrementButtonPress];
}

- (IBAction)moveDown:(id)sender
{
    [self performDecrementButtonPress];
}

- (NSArray *)imageNames
{
    return @[@"StepperBackground"];
}

- (void)loadTextures
{   
    if ( self.textures != nil )
    {
        return;
    }
    
    NSArray *imageNames = [self imageNames];
    
    GLsizei imageCount = (GLsizei)imageNames.count;
    self.textures = calloc(imageCount, sizeof(GLuint));
    self.textureSizes = calloc(imageCount, sizeof(CGSize));
    
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    glGenTextures(imageCount, self.textures);
    glEnable(GL_TEXTURE_RECTANGLE_EXT);

    GLsizei i = 0;
    for ( i = 0; i < imageCount; i++ )
    {
        NSString *imageName = imageNames[i];
        glBindTexture(GL_TEXTURE_RECTANGLE_EXT, self.textures[i]);
        glTexParameteri(GL_TEXTURE_RECTANGLE_EXT, GL_TEXTURE_MIN_FILTER, GL_LINEAR); 
        glTexParameteri(GL_TEXTURE_RECTANGLE_EXT, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        
        NSString *imagePath = [[NSBundle mainBundle] pathForImageResource:imageName];
        if ( [imagePath length] > 0 )
        {
            CGDataProviderRef dataProvider = CGDataProviderCreateWithFilename([imagePath fileSystemRepresentation]);
            if ( dataProvider != nil )
            {
                CGImageRef image = CGImageCreateWithPNGDataProvider(dataProvider, NULL, NO, kCGRenderingIntentDefault);
                if ( image != nil )
                {
                    GLuint width = (GLuint)CGImageGetWidth(image);
                    GLuint height = (GLuint)CGImageGetHeight(image);    
                    
                    self.textureSizes[i] = CGSizeMake(width, height);
                    size_t bytesPerRow = width * 4;
                    void *imageData = malloc( height * bytesPerRow );
                    
                    CGContextRef context = CGBitmapContextCreate( imageData, width, height, 8, bytesPerRow, colorSpace, kCGImageAlphaPremultipliedLast | kCGBitmapByteOrder32Big );
                    
                    if ( context != nil )
                    {
                        CGContextClearRect(context, CGRectMake( 0, 0, width, height ));
                        CGContextTranslateCTM( context, 0, height - height);
                        CGContextDrawImage(context, CGRectMake( 0, 0, width, height ), image);
                        
                        glTexImage2D(GL_TEXTURE_RECTANGLE_EXT, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, imageData);
                        
                        CGContextRelease(context);
                    }
                    free(imageData);
                    CFRelease(image);
                }
                CFRelease(dataProvider);
            }
        }
    }
    
    CGColorSpaceRelease(colorSpace);
}


#pragma mark OpenGL drawing

- (void)drawRect:(NSRect) bounds
{
    // Clear everything
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
    glClearColor(0.0, 0.0, 0.0, 0.0);
    
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    
    // Generate some colors
    CGFloat r, g, b;
    static float hue = 0.0;

    if ( hue >= 1.0 )
    {
        hue = 0.0;
    }

    hue += 0.003;

    NSColor *colorObject = [NSColor colorWithCalibratedHue:hue saturation:0.7 brightness:0.5 alpha:1.0];
    [colorObject getRed:&r green:&g blue:&b alpha:NULL];
    GLfloat diffusedColor[] = {r, g, b};
    
    colorObject = [NSColor colorWithCalibratedHue:hue saturation:0.5 brightness:0.3 alpha:1.0];
    [colorObject getRed:&r green:&g blue:&b alpha:NULL];
    GLfloat ambientColor[] = {r, g, b};

    [NSColor colorWithCalibratedHue:hue saturation:0.5 brightness:0.3 alpha:1.0];
    [colorObject getRed:&r green:&g blue:&b alpha:NULL];
    
    GLfloat whiteColor[] = {1.0, 1.0, 1.0, 1.0};
    GLfloat pinkDiffusedColor[] = {1.0, 0.0, 1.0, 1.0};
    GLfloat pinkAmbientColor[] = {0.713, 0.294, 0.713, 1.0};
    
    // Add a light source
    glEnable(GL_LIGHT0);
    glLightModelfv(GL_LIGHT_MODEL_AMBIENT, whiteColor);
    GLfloat lightPosition[] = {1.0, 0.5, 1.0, 1.0};
    glLightfv(GL_LIGHT0, GL_POSITION, lightPosition);

    // Position to draw
    glTranslatef(0.0, 0.0, -1.0);
    
    glMaterialfv(GL_FRONT, GL_SPECULAR, whiteColor);
    GLfloat shininess[] = {50};
    glMaterialfv(GL_FRONT, GL_SHININESS, shininess);

    // Iterate over all 4 sides
    int i = 0;
    for ( i = 0; i < 4; i++ )
    {
        glColor3f(0.873f, 0.873f, 0.873f);
        glRotatef(90.0, 0.0f, 1.0f, 0.0);

        GLuint texture = self.textures[0];
        CGSize textureSize = self.textureSizes[0];

        glBindTexture(GL_TEXTURE_RECTANGLE_EXT, texture);
        glBegin(GL_QUADS);
        {
            glTexCoord2f (0.0, textureSize.height);
            glVertex3f(-1.0, -1.0, 1.0);
            glTexCoord2f(0.0, 0.0);
            glVertex3f(-1.0, 1.0, 1.0);
            glTexCoord2f (textureSize.width, 0.0);
            glVertex3f( 1.0, 1.0, 1.0);
            glTexCoord2f (textureSize.width, textureSize.height);
            glVertex3f( 1.0, -1.0, 1.0);
        }
        glEnd();
        glBindTexture(GL_TEXTURE_RECTANGLE_EXT, 0);
        
        if ( self.upButtonShowDepressed )
        {
            glMaterialfv(GL_FRONT, GL_DIFFUSE, pinkDiffusedColor);
            glMaterialfv(GL_FRONT, GL_AMBIENT, pinkAmbientColor);
        }
        else
        {
            glMaterialfv(GL_FRONT, GL_DIFFUSE, diffusedColor);
            glMaterialfv(GL_FRONT, GL_AMBIENT, ambientColor);
        }
        
        glBegin(GL_TRIANGLES);
        {
            glVertex3f(  0.0,  0.9, 1.002);
            glVertex3f( -0.75,  0.1, 1.002);
            glVertex3f(  0.75,  0.1 ,1.002);
        }
        glEnd();
        
        if ( self.downButtonShowDepressed )
        {
            glMaterialfv(GL_FRONT, GL_DIFFUSE, pinkDiffusedColor);
            glMaterialfv(GL_FRONT, GL_AMBIENT, pinkAmbientColor);
        }
        else
        {
            glMaterialfv(GL_FRONT, GL_DIFFUSE, diffusedColor);
            glMaterialfv(GL_FRONT, GL_AMBIENT, ambientColor);
        }
        
        glBegin(GL_TRIANGLES);
        {
            glVertex3f(  0.0,  -0.9, 1.002);
            glVertex3f( -0.75,  -0.1, 1.002);
            glVertex3f(  0.75,  -0.1 ,1.002);
        }
        glEnd();
        
        glMaterialfv(GL_FRONT, GL_DIFFUSE, whiteColor);
        glMaterialfv(GL_FRONT, GL_AMBIENT, whiteColor);
        glBegin(GL_TRIANGLES);
        {
            glVertex3f(  0.0,  0.95, 1.001);
            glVertex3f( -0.85,  0.075, 1.001);
            glVertex3f(  0.85,  0.075,1.001);
            
            glVertex3f(  0.0,  -0.95, 1.001);
            glVertex3f( -0.85,  -0.075, 1.001);
            glVertex3f(  0.85,  -0.075,1.001);
        }
        glEnd();
    }

    glPopMatrix();

    [self.openGLContext flushBuffer];
}

- (void) initOpenGLStates
{
    [[self openGLContext] makeCurrentContext];

    glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
    glHint(GL_POLYGON_SMOOTH_HINT, GL_NICEST);
    glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glFrustum(-0.5, 0.5, -0.5, 0.5, 1.0, 8.0);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glTranslatef(0.0, 0.0, -2.0);

    glEnable(GL_DEPTH_TEST);
    glDisable(GL_CULL_FACE);
    glEnable(GL_LIGHTING);

    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

    glEnable(GL_MULTISAMPLE);   
    glEnable(GL_TEXTURE_RECTANGLE_EXT);

    [self loadTextures];
}

#pragma mark Accessibility
- (NSString *)accessibilityLabel
{
    return NSLocalizedString(@"Volume", @"accessibility label for the volume stepper");
}

- (NSString *)accessibilityHelp
{
    return NSLocalizedString(@"Adjusts the volume", @"accessibility help for the volume stepper");
}

- (BOOL)accessibilityPerformIncrement
{
    [self performIncrementButtonPress];
    return YES;
}

- (BOOL)accessibilityPerformDecrement
{
    [self performDecrementButtonPress];
    return YES;
}

@end
