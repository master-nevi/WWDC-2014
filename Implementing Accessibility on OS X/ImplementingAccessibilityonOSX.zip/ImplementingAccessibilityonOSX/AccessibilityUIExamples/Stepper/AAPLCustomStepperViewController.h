/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 View controller demonstrating an accessible, custom NSOpenGLView subclass that behaves like a stepper.
 
 */


#import "AAPLAccessibilityExamplesBaseViewController.h"

@class AAPLCustomStepperView;

@interface AAPLCustomStepperViewController : AAPLAccessibilityExamplesBaseViewController

@property (nonatomic) IBOutlet AAPLCustomStepperView *customStepper;
@property (nonatomic, weak) IBOutlet NSTextField *volumeLabel;

@end
