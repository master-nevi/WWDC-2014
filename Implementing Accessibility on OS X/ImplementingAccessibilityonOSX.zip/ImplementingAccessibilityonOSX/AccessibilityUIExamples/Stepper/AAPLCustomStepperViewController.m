/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 View controller demonstrating an accessible, custom NSOpenGLView subclass that behaves like a stepper.
 
 */

#import "AAPLCustomStepperViewController.h"
#import "AAPLCustomStepperView.h"

@implementation AAPLCustomStepperViewController

- (void)awakeFromNib
{
    [super awakeFromNib];
    
    self.customStepper.target = self;
    self.customStepper.action = @selector(pressStepper:);
    [self pressStepper:nil];
}

- (void)updateVolumeLabel:(CGFloat)volume
{
    NSNumber *number = @(volume/100.0f);
    NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
    [numberFormatter setNumberStyle:NSNumberFormatterPercentStyle];
    [numberFormatter setMaximumFractionDigits:0];

    NSString *stringFormatter = NSLocalizedString(@"VolumeFormatter", @"Formatter for volume");
    NSString *label = [numberFormatter stringFromNumber:number];
    label = [NSString stringWithFormat:stringFormatter, label];
    
    self.volumeLabel.stringValue = label;
}

- (void)pressStepper:(id)sender
{
    CGFloat stepperValue = self.customStepper.value;
    [self updateVolumeLabel:stepperValue];

    NSString *volumeSoundPath = [[NSBundle mainBundle] pathForResource:@"volume" ofType:@"aiff"];
    if ( volumeSoundPath != nil )
    {
        NSSound *volumeSound = [[NSSound alloc] initWithContentsOfFile:volumeSoundPath byReference:YES];
        [volumeSound setVolume:stepperValue/100.0f];
        [volumeSound play];
    }
}

@end
