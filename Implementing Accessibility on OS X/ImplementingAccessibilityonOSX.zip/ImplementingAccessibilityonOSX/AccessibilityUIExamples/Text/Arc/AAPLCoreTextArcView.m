/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 >An example demonstrating adding accessibility to an NSView subclass that draws text using CoreText by implementing the NSAccessibilityStaticText protocol.
 
 */

#import "AAPLCoreTextArcView.h"
#import <AssertMacros.h>

static NSString * const AAPLArcviewDefaultFontName = @"Didot";
static const CGFloat AAPLArcviewDefaultFontSize = 53.0f;
static const CGFloat AAPLArcviewDefaultRadius = 75.0f;

typedef struct GlyphArcInfo {
    CGFloat width;
    CGFloat angle; // in radians
} GlyphArcInfo;

// IMPORTANT: This is not a template for developing a custom control.
// This sample is intended to demonstrate how to add accessibility to
// existing custom controls that are not implemented using the preferred methods.
// For information on how to create custom controls please visit http://developer.apple.com

@interface AAPLCoreTextArcView ()

@property (nonatomic) NSFont *font;
@property (nonatomic) NSString *string;

@end

@implementation AAPLCoreTextArcView
@dynamic attributedString;

- (instancetype)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];

    if ( self != nil )
    {
        _font = [NSFont fontWithName:(NSString *)AAPLArcviewDefaultFontName size:AAPLArcviewDefaultFontSize];
        _string = NSLocalizedString(@"Hello World", "Hello world");
    }

    return self;
}

static void PrepareGlyphArcInfo(CTLineRef line, CFIndex glyphCount, GlyphArcInfo *glyphArcInfo)
{
    NSArray *runArray = (__bridge NSArray *)CTLineGetGlyphRuns(line);

    // Examine each run in the line, updating glyphOffset to track how far along the run is in terms of glyphCount.
    CFIndex glyphOffset = 0;
    for ( id run in runArray )
    {
        CFIndex runGlyphCount = CTRunGetGlyphCount((__bridge CTRunRef)run);

        // Ask for the width of each glyph in turn.
        for ( CFIndex runGlyphIndex = 0; runGlyphIndex < runGlyphCount; runGlyphIndex++ )
        {
            glyphArcInfo[runGlyphIndex + glyphOffset].width = CTRunGetTypographicBounds((__bridge CTRunRef)run, CFRangeMake(runGlyphIndex, 1), NULL, NULL, NULL);
        }

        glyphOffset += runGlyphCount;
    }

    double lineLength = CTLineGetTypographicBounds(line, NULL, NULL, NULL);

    CGFloat prevHalfWidth = glyphArcInfo[0].width / 2.0;
    glyphArcInfo[0].angle = (prevHalfWidth / lineLength) * M_PI;

    // Divide the arc into slices such that each one covers the distance from one glyph's center to the next.
    for ( CFIndex lineGlyphIndex = 1; lineGlyphIndex < glyphCount; lineGlyphIndex++ )
    {
        CGFloat halfWidth = glyphArcInfo[lineGlyphIndex].width / 2.0;
        CGFloat prevCenterToCenter = prevHalfWidth + halfWidth;

        glyphArcInfo[lineGlyphIndex].angle = (prevCenterToCenter / lineLength) * M_PI;

        prevHalfWidth = halfWidth;
    }
}

- (void)drawRect:(NSRect)rect
{
    // Don't draw if we don't have a font or string
    if ( self.font == nil || self.string == nil )
    {
        return;
    }

    // Initialize the text matrix to a known value
    CGContextRef context = (CGContextRef)[[NSGraphicsContext currentContext] graphicsPort];
    CGContextSetTextMatrix(context, CGAffineTransformIdentity);

    CTLineRef line = CTLineCreateWithAttributedString((__bridge CFAttributedStringRef)[self attributedString]);
    assert(line != NULL);

    CFIndex glyphCount = CTLineGetGlyphCount(line);
    if ( glyphCount == 0 )
    {
        CFRelease(line);
        return;
    }

    GlyphArcInfo *glyphArcInfo = (GlyphArcInfo*)calloc(glyphCount, sizeof(GlyphArcInfo));
    PrepareGlyphArcInfo(line, glyphCount, glyphArcInfo);

    // Move the origin from the lower left of the view nearer to its center.
    CGContextSaveGState(context);
    CGContextTranslateCTM(context, CGRectGetMidX(NSRectToCGRect(rect)), CGRectGetMidY(NSRectToCGRect(rect)) - AAPLArcviewDefaultRadius / 2.0);

    // Rotate the context 90 degrees counterclockwise.
    CGContextRotateCTM(context, M_PI_2);

    // Now for the actual drawing.
    // The angle offset for each glyph relative to the previous glyph has already been calculated;
    // with that information in hand, draw those glyphs overstruck and centered over one another,
    // making sure to rotate the context after each glyph so the glyphs are spread along a semicircular path.
    CGPoint textPosition = CGPointMake(0.0, AAPLArcviewDefaultRadius);
    CGContextSetTextPosition(context, textPosition.x, textPosition.y);

    CFArrayRef runArray = CTLineGetGlyphRuns(line);
    CFIndex runCount = CFArrayGetCount(runArray);

    CFIndex glyphOffset = 0;
    CFIndex runIndex;
    for (runIndex = 0; runIndex < runCount; runIndex++)
    {
        CTRunRef run = (CTRunRef)CFArrayGetValueAtIndex(runArray, runIndex);
        CFIndex runGlyphCount = CTRunGetGlyphCount(run);

        for ( CFIndex runGlyphIndex = 0; runGlyphIndex < runGlyphCount; runGlyphIndex++)
        {
            CFRange glyphRange = CFRangeMake(runGlyphIndex, 1);
            CGContextRotateCTM(context, -glyphArcInfo[runGlyphIndex + glyphOffset].angle);

            // Center this glyph by moving left by half its width.
            CGFloat glyphWidth = glyphArcInfo[runGlyphIndex + glyphOffset].width;
            CGFloat halfGlyphWidth = glyphWidth / 2.0;
            CGPoint positionForThisGlyph = CGPointMake(textPosition.x - halfGlyphWidth, textPosition.y);

            // Glyphs are positioned relative to the text position for the line, so offset text position leftwards by this glyph's width in preparation for the next glyph.
            textPosition.x -= glyphWidth;

            CGAffineTransform textMatrix = CTRunGetTextMatrix(run);
            textMatrix.tx = positionForThisGlyph.x;
            textMatrix.ty = positionForThisGlyph.y;
            CGContextSetTextMatrix(context, textMatrix);

            CTRunDraw(run, context, glyphRange);
        }

        glyphOffset += runGlyphCount;
    }

    CGContextRestoreGState(context);

    free(glyphArcInfo);
    CFRelease(line);
}

- (NSAttributedString *)attributedString
{
    NSDictionary *attributes = @{ NSFontAttributeName : self.font,
                                  NSLigatureAttributeName : @(0)};

    NSAttributedString *attrString = [[NSAttributedString alloc] initWithString:self.string attributes:attributes];
    return attrString;
}

#pragma mark Accessibility

- (NSRange)accessibilityVisibleCharacterRange
{
    return NSMakeRange(0, self.string.length);
}

- (NSString *)accessibilityValue
{
    return self.string;
}


@end
