/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 An example demonstrating adding accessibility to an NSView subclass that draws columns of text using CoreText by implementing the NSAccessibilityNavigableStaticText protocol.
 
 */

#import "AAPLCoreTextColumnView.h"

const int AAPLColumnCountMin = 1;
const int AAPLColumnCountMax = 2;

// IMPORTANT: This is not a template for developing a custom control.
// This sample is intended to demonstrate how to add accessibility to
// existing custom controls that are not implemented using the preferred methods.
// For information on how to create custom controls please visit http://developer.apple.com

@interface AAPLCoreTextColumnView ()
{
@private
    CTFramesetterRef _framesetter;
    CFArrayRef _frames;
    CGRect *_columnRects;
}

@property (nonatomic) int columnCount;

@end

@implementation AAPLCoreTextColumnView

- (instancetype)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];

    if ( self != nil )
    {
        _columnCount = AAPLColumnCountMax;
        
        NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:NSLocalizedString(@"LongSampleText", "Long sample text")];
        [attributedString setAlignment:NSJustifiedTextAlignment range:NSMakeRange(0, attributedString.length)];
        
        _attributedString = attributedString;
    }

    return self;
}

- (void)dealloc
{
    free(_columnRects);
    if ( _frames != nil )
    {
        CFRelease(_frames);
    }
    if ( _framesetter != nil )
    {
        CFRelease(_framesetter);
    }
}

#pragma mark - Accessors

- (CGRect *)columnRects
{
    if ( _columnRects == nil )
    {
        CGRect bounds = CGRectMake(0, 0, NSWidth(self.bounds), NSHeight(self.bounds));
        
        int columnCount = self.columnCount;
        
        int column;
        CGRect *columnRects = (CGRect *)calloc(columnCount, sizeof(*columnRects));
        
        // Start by setting the first column to cover the entire view.
        columnRects[0] = bounds;
        
        // Divide the columns equally across the frame's width.
        CGFloat columnWidth = CGRectGetWidth(bounds) / columnCount;
        for ( column = 0; column < columnCount - 1; column++ )
        {
            CGRectDivide(columnRects[column], &columnRects[column], &columnRects[column + 1], columnWidth, CGRectMinXEdge);
        }
        
        // Inset all columns by a few pixels of margin.
        for ( column = 0; column < columnCount; column++ )
        {
            columnRects[column] = CGRectInset(columnRects[column], 10.0, 10.0);
        }
        _columnRects = columnRects;
    }
    return _columnRects;
}

- (void)setColumnRects:(CGRect *)columnRects
{
    free(_columnRects);
    _columnRects = columnRects;
}

- (CFArrayRef)frames
{
    if ( _frames == nil )
    {
        CGRect *columnRects = self.columnRects;
        int columnCount = self.columnCount;
        
        // Create text frames given string and column rectangles.
        CTFramesetterRef framesetter = self.framesetter;
        CFIndex startIndex = 0;
        
        CFMutableArrayRef frames = CFArrayCreateMutable(kCFAllocatorDefault, columnCount, &kCFTypeArrayCallBacks);
        int column;
        for ( column = 0; column < columnCount; column++ )
        {
            // Create frame with rect path.
            CGMutablePathRef path = CGPathCreateMutable();
            CGPathAddRect(path, NULL, columnRects[column]);
            CTFrameRef frame = CTFramesetterCreateFrame(framesetter, CFRangeMake(startIndex, 0), path, NULL);
            
            CFArrayInsertValueAtIndex(frames, column, frame);
            
            // Start the next frame at the first character not visible in this frame.
            CFRange frameRange = CTFrameGetVisibleStringRange(frame);
            startIndex += frameRange.length;
            
            CFRelease(frame);
            CFRelease(path);
        }
        _frames = frames;
    }
    return _frames;
}

- (void)setFrames:(CFArrayRef)frames
{
    if ( frames )
    {
        CFRetain(frames);
    }
    if ( _frames )
    {
        CFRelease(_frames);
    }
    _frames = frames;
}

- (void)setAttributedString:(NSAttributedString *)attributedString
{
    _attributedString = [attributedString copy];
    self.framesetter = nil;
    // Re-draw the view if the input string changes.
    [self setNeedsDisplay:YES];
}

- (CTFramesetterRef)framesetter
{
    if ( _framesetter == nil )
    {
        _framesetter = CTFramesetterCreateWithAttributedString((__bridge CFAttributedStringRef)self.attributedString);
    }
    return _framesetter;
}

- (void)setFramesetter:(CTFramesetterRef)framesetter
{
    if ( framesetter )
    {
        CFRetain(framesetter);
    }
    if ( _framesetter )
    {
        CFRelease(_framesetter);
    }
    _framesetter = framesetter;
}

- (void)setColumnCount:(int)columnCount
{
    if ( columnCount != _columnCount )
    {
        _columnCount = columnCount;
        self.columnRects = nil;
        self.frames = nil;
        [self setNeedsDisplay:YES];
    }
}

#pragma mark -

- (void)drawRect:(NSRect)rect
{
    // Initialize the text matrix to a known value
    CGContextRef context = (CGContextRef)[[NSGraphicsContext currentContext] graphicsPort];
    CGContextSetTextMatrix(context, CGAffineTransformIdentity);
    
    CFArrayRef frames = self.frames;
    CFIndex frameCount = CFArrayGetCount(frames);
    for (int column = 0; column < frameCount; column++ )
    {
        CTFrameRef frame = (CTFrameRef)CFArrayGetValueAtIndex(frames, column);
        CTFrameDraw(frame, context);
    }
}

- (void)changeLayout
{
    if ( self.columnCount == AAPLColumnCountMax )
    {
        self.columnCount = AAPLColumnCountMin;
    }
    else
    {
        self.columnCount++;
    }
}

- (void)mouseDown:(NSEvent *)theEvent
{
    [self changeLayout];
}

- (NSAttributedString *)attributedStringForRange:(NSRange)range
{
    NSAttributedString *value = nil;
    NSAttributedString *attributedString = self.attributedString;
    
    if ( NSMaxRange(range) <= attributedString.length )
    {
        value = [attributedString attributedSubstringFromRange:range];
    }
    return value;
}

- (NSString *)stringForRange:(NSRange)range
{
    return [[self attributedStringForRange:range] string];
}

- (NSUInteger)lineForIndex:(NSUInteger)index
{
    NSUInteger lineForIndex = NSNotFound;
    NSUInteger absoluteLineNumber = 0; // Current line, across columns.
    
    CFArrayRef frames = self.frames;
    NSUInteger columnCount = CFArrayGetCount(frames);
    
    for ( NSUInteger columnIdx = 0; columnIdx < columnCount; columnIdx++ )
    {
        CTFrameRef currentFrame = CFArrayGetValueAtIndex(frames, columnIdx);
        CFArrayRef lines = CTFrameGetLines(currentFrame);
        NSUInteger lineCount = CFArrayGetCount(lines); // Lines in just this column.
        
        for ( NSUInteger lineIdx = 0; lineIdx < lineCount; lineIdx++ )
        {
            CTLineRef currentLine = CFArrayGetValueAtIndex(lines, lineIdx);
            CFRange lineRange = CTLineGetStringRange(currentLine);
            BOOL characterInLineRange = (CFIndex)index - lineRange.location < lineRange.length;
            if ( characterInLineRange )
            {
                lineForIndex = absoluteLineNumber;
                break;
            }
            
            absoluteLineNumber++;
        }
        
        if ( lineForIndex != NSNotFound )
        {
            break;
        }
    }
    
    return ( lineForIndex != NSNotFound ) ? absoluteLineNumber : NSNotFound;
}

- (NSRange)rangeForLine:(NSUInteger)index
{
    NSRange rangeForLine = NSMakeRange(NSNotFound, 0);
    NSUInteger absoluteLineNumber = 0;
    
    CFArrayRef frames = self.frames;
    NSUInteger columnCount = CFArrayGetCount(frames);
    
    for ( NSUInteger columnIdx = 0; columnIdx < columnCount; columnIdx++ )
    {
        CTFrameRef currentFrame = CFArrayGetValueAtIndex(frames, columnIdx);
        CFArrayRef lines = CTFrameGetLines(currentFrame);
        NSUInteger lineCount = CFArrayGetCount(lines);
        
        // Skip to next frame.
        if ( absoluteLineNumber + lineCount <= index )
        {
            absoluteLineNumber += lineCount;
            continue;
        }
        // Line lives within this frame if the text is long enough.
        else
        {
            NSUInteger relativeIndex = index - absoluteLineNumber;
            if (relativeIndex < lineCount)
            {
                CTLineRef currentLine = CFArrayGetValueAtIndex(lines, relativeIndex);
                CFRange lineRange = CTLineGetStringRange(currentLine);
                rangeForLine = NSMakeRange(lineRange.location, lineRange.length);
            }
            break;
        }
    }
    return rangeForLine;
}

- (NSRect)boundsForRange:(NSRange)range inColumn:(NSUInteger)columnIdx line:(NSUInteger)lineIdx
{    
    CTFrameRef frame = CFArrayGetValueAtIndex(self.frames, columnIdx);
    CFArrayRef lines = CTFrameGetLines(frame);
    CTLineRef line = CFArrayGetValueAtIndex(lines, lineIdx);
    
    // Looking for bounds of range that fall within this line.
    CFRange lineRange = CTLineGetStringRange(line);
    NSRange rangeWithinLine = NSIntersectionRange(range, NSMakeRange(lineRange.location, lineRange.length));
    
    // Find origin of line relative to frame.
    CGPoint lineOrigins[1];
    
    CTFrameRef lineFrame = CFArrayGetValueAtIndex(self.frames, columnIdx);
    CTFrameGetLineOrigins(lineFrame, CFRangeMake(lineIdx, 1), lineOrigins);
    CGPoint lineOrigin = lineOrigins[0];
    
    // Find horizontal pixel offsets of range within line.
    CGFloat rangeXOffset = CTLineGetOffsetForStringIndex(line, rangeWithinLine.location, NULL);
    
    // Calculate line height.
    CGFloat ascent;
    CGFloat descent;
    CGFloat leading;
    CTLineGetTypographicBounds(line, &ascent, &descent, &leading);
    CGFloat lineHeight = ascent + descent + leading;
    
    // Calculate range width.
    CGFloat leftMargin = CTLineGetOffsetForStringIndex(line, rangeWithinLine.location, NULL);
    CGFloat rightMargin = CTLineGetOffsetForStringIndex(line, NSMaxRange(rangeWithinLine), NULL);
    CGFloat rangeWidth = rightMargin - leftMargin;
    
    // Put it all together.
    CGRect *columnRects = self.columnRects;
    CGPoint frameOrigin = columnRects[columnIdx].origin;
    CGFloat xPos = frameOrigin.x + lineOrigin.x + rangeXOffset;
    CGFloat yPos = frameOrigin.y + lineOrigin.y;
    NSRect rangeRect = NSMakeRect(xPos, yPos, rangeWidth, lineHeight);
    NSRect windowRect = [self convertRect:rangeRect toView:nil];
    NSRect screenRect = [[self window] convertRectToScreen:windowRect];
    
    return screenRect;
}

- (NSRect)boundsForRange:(NSRange)range
{
    NSRect returnValue = NSZeroRect;

    NSUInteger characterIndexSought = range.location;
    
    // Find lines at start and end of range.
    NSUInteger startLineColumnIdx = NSNotFound;
    NSUInteger endLineColumnIdx = NSNotFound;
    NSUInteger startLineIdx = NSNotFound;
    NSUInteger endLineIdx = NSNotFound;
    
    CFArrayRef frames = self.frames;
    NSUInteger columnCount = CFArrayGetCount(frames);

    for ( NSUInteger columnIdx = 0; columnIdx < columnCount; columnIdx++ )
    {
        CTFrameRef currentFrame = CFArrayGetValueAtIndex(frames, columnIdx);
        CFArrayRef lines = CTFrameGetLines(currentFrame);
        NSUInteger lineCount = CFArrayGetCount(lines);

        for ( NSUInteger lineIdx = 0; lineIdx < lineCount; lineIdx++ )
        {
            CTLineRef currentLine = CFArrayGetValueAtIndex(lines, lineIdx);
            CFRange lineRange = CTLineGetStringRange(currentLine);
            BOOL characterInLineRange = (CFIndex)characterIndexSought - lineRange.location < lineRange.length;
            if ( characterInLineRange )
            {
                if ( startLineIdx == NSNotFound )
                {
                    // Found the first line.
                    startLineColumnIdx = columnIdx;
                    startLineIdx = lineIdx;
                    
                    NSUInteger lastCharInLine = lineRange.location + lineRange.length;
                    if ( lastCharInLine >= NSMaxRange(range) )
                    {
                        // The entire range is contained in this line. We're done.
                        endLineColumnIdx = columnIdx;
                        endLineIdx = lineIdx;
                        break;
                    }
                    else
                    {
                        // Continue search for end line since range extends beyond this one.
                        characterIndexSought = NSMaxRange(range);
                    }
                }
                else
                {
                    endLineColumnIdx = columnIdx;
                    endLineIdx = lineIdx;
                    break;
                }
            }
        }
        
        if ( startLineIdx != NSNotFound && endLineIdx != NSNotFound )
        {
            break;
        }
    }
    
    // Sanity check.
    if ( startLineIdx != NSNotFound )
    {
        // Combine bounds rects for each line.
        NSUInteger currentColumn;
        NSUInteger currentLine;
        
        for ( currentColumn = startLineColumnIdx; currentColumn <= endLineColumnIdx; currentColumn++ )
        {
            NSUInteger startLine = currentColumn == startLineColumnIdx ? startLineIdx : 0;
            
            NSUInteger endLine;
            if ( currentColumn == endLineColumnIdx )
            {
                endLine = endLineIdx;
            }
            else
            {
                CTFrameRef frame = CFArrayGetValueAtIndex(frames, currentColumn);
                CFArrayRef lines = CTFrameGetLines(frame);
                NSUInteger lineCount = CFArrayGetCount(lines);
                endLine = lineCount - 1;
            }
            
            for ( currentLine = startLine; currentLine <= endLine; currentLine++ )
            {
                NSRect lineBoundsForRange = [self boundsForRange:range inColumn:currentColumn line:currentLine];
                returnValue = NSUnionRect(returnValue, lineBoundsForRange);
            }
        }
    }
    return returnValue;
}

#pragma mark Accessibility

- (NSString *)accessibilityStringForRange:(NSRange)range
{
    return [self stringForRange:range];
}

- (NSInteger)accessibilityLineForIndex:(NSInteger)index
{
    return [self lineForIndex:index];
}

- (NSRange)accessibilityRangeForLine:(NSInteger)lineNumber
{
    return [self rangeForLine:lineNumber];
}

- (NSRect)accessibilityFrameForRange:(NSRange)range
{
    return [self boundsForRange:range];
}

- (NSAttributedString *)accessibilityAttributedStringForRange:(NSRange)range
{
    return [self attributedStringForRange:range];
}

- (id)accessibilityValue
{
    return self.attributedString.string;
}

- (NSRange)accessibilityVisibleCharacterRange
{
    CFArrayRef frames = [self frames];
    NSUInteger columnCount = CFArrayGetCount(frames);
    // Range known to begin at zero. Cannot union with NSNotFound.
    NSRange visibleRange = NSMakeRange(0, 0);
    for (NSUInteger columnIdx = 0; columnIdx < columnCount; columnIdx++)
    {
        CTFrameRef frame = CFArrayGetValueAtIndex(frames, columnIdx);
        CFRange frameRange = CTFrameGetVisibleStringRange(frame);
        visibleRange = NSUnionRange(visibleRange, NSMakeRange(frameRange.location, frameRange.length));
    }
    return visibleRange;
}

- (BOOL)accessibilityPerformPress
{
    [self changeLayout];
    return YES;
}

@end
