/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 View controller demonstrating a text cell that protects its content from being read by accessibility clients by using the accessibilityProtectedContent attribute.
 
 */

#import "AAPLProtectedTextViewController.h"

@implementation AAPLProtectedTextViewController

// NSAccessibilitySetMayContainProtectedContent(BOOL flag) is a per app setting that
// tells accessibility to obey an element's accessibilityProtectedContent attribute.
// In this sample app, AAPLAccessibilityExamplesAppDelegate.m applicationDidFinishLaunching
// makes the NSAccessibilitySetMayContainProtectedContent(YES) call.
- (IBAction)toggleProtection:(id)sender
{
    NSTextFieldCell *textCell = self.contentView.cell;
    BOOL shouldProtect = (BOOL)([sender state] != NSOffState);
    textCell.accessibilityProtectedContent = shouldProtect;
    NSAccessibilitySetMayContainProtectedContent(shouldProtect);
}

@end

