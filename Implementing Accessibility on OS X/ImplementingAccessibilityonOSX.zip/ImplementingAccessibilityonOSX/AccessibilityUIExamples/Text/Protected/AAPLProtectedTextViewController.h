/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 View controller demonstrating a text cell that protects its content from being read by accessibility clients by using the accessibilityProtectedContent attribute.
 
 */

#import "AAPLAccessibilityExamplesBaseViewController.h"


@interface AAPLProtectedTextViewController : AAPLAccessibilityExamplesBaseViewController

@property (nonatomic, weak) IBOutlet NSButton *protectContentCheckbox;
@property (nonatomic, weak) IBOutlet NSTextField *contentView;

@end
