/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 View controller demonstrating accessibility provided by AppKit for an NSButton with an image.
 
 */

#import "AAPLImageButtonViewController.h"
#import "AAPLButtonBaseViewController_Internal.h"

@implementation AAPLImageButtonViewController

- (void)awakeFromNib
{
    [super awakeFromNib];

    NSView *buttonView = self.button;
    if ( [buttonView isKindOfClass:[NSButton class]] )
    {
        NSButton *button = (NSButton *)buttonView;
        [button.cell setHighlightsBy:NSContentsCellMask];
    }
}

@end
