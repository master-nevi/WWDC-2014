/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 Base view controller for views with a single button and a "Press Count" text field.
 
 */

#import "AAPLButtonBaseViewController.h"
#import "AAPLButtonBaseViewController_Internal.h"

@implementation AAPLButtonBaseViewController

- (void)awakeFromNib
{
    [super awakeFromNib];
    [self updatePressCountTextField];
}

- (void)updatePressCountTextField
{
    NSString *formatter = NSLocalizedString(@"PressCountFormatter", @"Press count formatter");
    NSString *numberString = [NSNumberFormatter localizedStringFromNumber:@(self.pressCount)
                                                           numberStyle:NSNumberFormatterDecimalStyle];
    self.pressCountTextField.stringValue = [NSString stringWithFormat:formatter, numberString];
}

- (IBAction)pressButton:(id)button
{
    self.pressCount++;
    [self updatePressCountTextField];
}

@end
