/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 Base view controller for views with a single button and a "Press Count" text field.

 */

#import "AAPLAccessibilityExamplesBaseViewController.h"

@interface AAPLButtonBaseViewController : AAPLAccessibilityExamplesBaseViewController

@end
