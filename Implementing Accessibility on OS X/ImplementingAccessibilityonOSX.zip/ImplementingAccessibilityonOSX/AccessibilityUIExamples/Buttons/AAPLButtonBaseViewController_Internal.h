/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 Base view controller for views with a single button and a "Press Count" text field.
 
 */

#import "AAPLButtonBaseViewController.h"

@interface AAPLButtonBaseViewController ()

@property (nonatomic) NSUInteger pressCount;

// Outlets
@property (nonatomic, weak) IBOutlet NSTextField *pressCountTextField;
@property (nonatomic, weak) IBOutlet NSView *button;

// Actions
- (IBAction)pressButton:(id)button;

@end
