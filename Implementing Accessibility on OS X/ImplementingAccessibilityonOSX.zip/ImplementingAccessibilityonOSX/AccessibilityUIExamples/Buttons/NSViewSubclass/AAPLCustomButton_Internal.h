/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 An example demonstrating adding accessibility to an NSView subclass that behaves like a button by implementing the NSAccessibilityButton protocol.
 
 */

#import "AAPLCustomButton.h"

@interface AAPLCustomButton ()

@property (nonatomic) BOOL pressed;
@property (nonatomic) BOOL highlighted;
@property (nonatomic) BOOL depressed;

@property (nonatomic, weak) IBOutlet NSObject <AAPLCustomButtonActionHandler> *actionHandler;

@end
