/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 An example demonstrating adding accessibility to an NSView subclass that behaves like a button by implementing the NSAccessibilityButton protocol.
 
 */

#import "AAPLCustomButton.h"
#import "AAPLCustomButton_Internal.h"

static NSString * const AAPLButtonUp = @"CustomButtonUp";
static NSString * const AAPLButtonDown = @"CustomButtonDown";
static NSString * const AAPLButtonHighlight = @"CustomButtonHighlight";

// IMPORTANT: This is not a template for developing a custom control.
// This sample is intended to demonstrate how to add accessibility to
// existing custom controls that are not implemented using the preferred methods.
// For information on how to create custom controls please visit http://developer.apple.com

@implementation AAPLCustomButton

- (id)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];

    if ( self != nil )
    {
        // Register for mouse events that affect drawing.
        NSTrackingArea *trackingArea = [[NSTrackingArea alloc] initWithRect:self.bounds
                                                                    options:NSTrackingMouseEnteredAndExited |
                                                                            NSTrackingActiveInKeyWindow |
                                                                            NSTrackingEnabledDuringMouseDrag
                                                                      owner:self
                                                                   userInfo:nil];
        [self addTrackingArea:trackingArea];
    }
    
    return self;
}

- (BOOL)acceptsFirstResponder
{
    return YES;
}

- (void)drawFocusRingMask
{
    NSRectFill(self.bounds);
}

- (NSRect)focusRingMaskBounds
{
    return self.bounds;
}

- (void)drawRect:(NSRect)dirtyRect
{
    NSBundle *bundle = [NSBundle mainBundle];
    NSImage *upImage = [bundle imageForResource:AAPLButtonUp];
    NSImage *downImage = [bundle imageForResource:AAPLButtonDown];
    NSImage *highlightedImage = [bundle imageForResource:AAPLButtonHighlight];

    NSImage *imageToDraw = upImage;

    if ( self.depressed )
    {
        imageToDraw = downImage;
    }
    else if ( self.highlighted )
    {
        imageToDraw = highlightedImage;
    }

    [imageToDraw drawInRect:self.bounds fromRect:NSZeroRect operation:NSCompositeSourceOver fraction:1.0];
}

- (void)performPress
{
    // Set down and release after momentary delay so the button flickers.
    [self pressDown];

    double delayInSeconds = 0.1;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        [self pressUpInside:YES andHighlight:NO];
    });
}

- (void)pressDown
{
    self.pressed = YES;
    self.depressed = YES;
    [self setNeedsDisplay:YES];
}

- (void)pressUpInside:(BOOL)inside andHighlight:(BOOL)shouldHighlight
{
    self.pressed = NO;
    self.depressed = NO;
    self.highlighted = shouldHighlight ? inside : NO;
    [self setNeedsDisplay:YES];
    
    if ( inside )
    {
        [self.actionHandler pressButton:self];
    }
}

#pragma mark Mouse events

- (void)mouseDown:(NSEvent *)mouseEvent
{
    [super mouseDown:mouseEvent];

    [self pressDown];
}

- (void)mouseUp:(NSEvent *)mouseEvent
{
    [super mouseUp:mouseEvent];

    NSPoint localPoint = [self convertPoint:mouseEvent.locationInWindow fromView:nil];
    BOOL isInside = NSPointInRect(localPoint, self.bounds);
    [self pressUpInside:isInside andHighlight:YES];
}

- (void)mouseEntered:(NSEvent *)mouseEvent
{
    [super mouseEntered:mouseEvent];

    self.highlighted = YES;
    self.depressed = self.pressed; // Restore pressed state, possibly set before mouseExited.
    [self setNeedsDisplay:YES];
}

- (void)mouseExited:(NSEvent *)mouseEvent
{
    [super mouseExited:mouseEvent];

    self.highlighted = self.pressed;
    self.depressed = NO;
    [self setNeedsDisplay:YES];
}

#pragma mark Keyboard events

- (void)keyDown:(NSEvent *)keyEvent
{
    NSString *characters = [keyEvent characters];

    if ([characters isEqualToString:@" "])
    {
        [self performPress];
    }
    else
    {
        [super keyDown:keyEvent];
    }
}

#pragma mark Accessibility

- (NSString *)accessibilityLabel
{
    return NSLocalizedString(@"Play", @"accessibility label of the Play button");
}

- (NSString *)accessibilityHelp
{
    return NSLocalizedString(@"Increase press count.", @"accessibility help of the Play button");
}

- (BOOL)accessibilityPerformPress
{
    [self performPress];
    return YES;
}

@end
