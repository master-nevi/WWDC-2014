/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 View controller demonstrating an accessible, custom NSView subclass that behaves like a button.
 
 */

#import "AAPLButtonBaseViewController.h"

@interface AAPLCustomButtonViewController : AAPLButtonBaseViewController

@end
