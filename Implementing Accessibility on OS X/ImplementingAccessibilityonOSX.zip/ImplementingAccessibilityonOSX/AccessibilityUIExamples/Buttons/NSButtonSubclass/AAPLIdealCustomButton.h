/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 An example demonstrating the preferred method of making an accessible, custom button by subclassing NSButton and implementing the NSAccessibilityButton protocol.
 
 */

#import <Cocoa/Cocoa.h>

@interface AAPLIdealCustomButton : NSButton

@end
