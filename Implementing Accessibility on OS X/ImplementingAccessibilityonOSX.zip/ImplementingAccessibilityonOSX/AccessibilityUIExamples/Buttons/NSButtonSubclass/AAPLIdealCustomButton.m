/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 An example demonstrating the preferred method of making an accessible, custom button by subclassing NSButton and implementing the NSAccessibilityButton protocol.
 
 */

#import "AAPLIdealCustomButton.h"

static NSString * const AAPLButtonUp = @"CustomButtonUp";
static NSString * const AAPLButtonDown = @"CustomButtonDown";
static NSString * const AAPLButtonHighlight = @"CustomButtonHighlight";


#pragma mark - Button cell

@interface AAPLIdealCustomButtonCell : NSButtonCell <NSAccessibilityButton>

@end

@implementation AAPLIdealCustomButtonCell

// NSCell subclasses must implement all designated initializers.

- (id)init
{
    self = [super init];

    if ( self != nil )
    {
        [self configureCell];
    }

    return self;
}

- (id)initImageCell:(NSImage *)image
{
    return [super initImageCell:image];
}

- (id)initTextCell:(NSString *)aString
{
    return [super initTextCell:aString];
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
    return [super initWithCoder:aDecoder];
}

- (void)configureCell
{
    [self setBordered:NO];
    [self setImagePosition:NSImageOnly];
    [self setButtonType:NSMomentaryChangeButton];
    [self setFocusRingType:NSFocusRingAbove];

    NSBundle *bundle = [NSBundle mainBundle];
    NSImage *upImage = [bundle imageForResource:AAPLButtonUp];
    NSImage *downImage = [bundle imageForResource:AAPLButtonDown];

    [self setImage:upImage];
    [self setAlternateImage:downImage];
}

- (BOOL)showsBorderOnlyWhileMouseInside
{
    // Required to receive mouse tracking events.
    return YES;
}

- (void)mouseEntered:(NSEvent *)mouseEvent
{
    [super mouseEntered:mouseEvent];

    NSImage *highlightImage = [[NSBundle mainBundle] imageForResource:AAPLButtonHighlight];
    [self setImage:highlightImage];
}

- (void)mouseExited:(NSEvent *)mouseEvent
{
    [super mouseExited:mouseEvent];

    NSImage *upImage = [[NSBundle mainBundle] imageForResource:AAPLButtonUp];
    [self setImage:upImage];
}

#pragma mark Accessibility

- (NSString *)accessibilityLabel
{
    return NSLocalizedString(@"Play", @"accessibility label of the Play button");
}

- (NSString *)accessibilityHelp
{
    return NSLocalizedString(@"Increase press count.", @"accessibility help of the Play button");
}

- (BOOL)accessibilityPerformPress
{
    [self performClick:nil];
    return YES;
}

@end


#pragma mark - Button

@implementation AAPLIdealCustomButton

+ (Class)cellClass
{
    return [AAPLIdealCustomButtonCell class];
}

- (BOOL)acceptsFirstResponder
{
    return YES;
}

@end
