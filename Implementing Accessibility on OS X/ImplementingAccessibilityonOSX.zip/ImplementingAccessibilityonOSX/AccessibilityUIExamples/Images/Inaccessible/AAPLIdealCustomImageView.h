/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 An example demonstrating the preferred method of making an accessible, custom image by subclassing NSImageView.
 
 */

#import <Cocoa/Cocoa.h>

@interface AAPLIdealCustomImageView : NSImageView

@end
