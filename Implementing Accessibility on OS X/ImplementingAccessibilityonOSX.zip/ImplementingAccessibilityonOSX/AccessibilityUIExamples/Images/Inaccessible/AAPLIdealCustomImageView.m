/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 An example demonstrating the preferred method of making an accessible, custom image by subclassing NSImageView.
 
 */

#import "AAPLIdealCustomImageView.h"

// IMPORTANT: This is not a template for developing a custom image. This sample is
// intended to demonstrate how to add accessibility to UI that may not have been
// ideally designed. For information on how to create custom controls please visit
// http://developer.apple.com

@implementation AAPLIdealCustomImageView

- (void)drawRect:(NSRect)dirtyRect
{
    NSBundle *bundle = [NSBundle mainBundle];
    NSImage *image = [bundle imageForResource:@"Recycle"];
    [image drawInRect:self.bounds fromRect:NSZeroRect operation:NSCompositeSourceOver fraction:1.0];
}

#pragma mark - Accessibility
- (NSString *)accessibilityLabel
{
    return NSLocalizedString(@"recycle", @"accessibility label of the recycle image");
}

@end
