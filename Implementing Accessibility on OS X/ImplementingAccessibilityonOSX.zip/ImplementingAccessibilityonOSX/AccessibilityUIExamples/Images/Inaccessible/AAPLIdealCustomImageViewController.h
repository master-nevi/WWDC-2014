/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 View controller demonstrating an accessible, custom image.
 
 */

#import "AAPLAccessibilityExamplesBaseViewController.h"

@interface AAPLIdealCustomImageViewController : AAPLAccessibilityExamplesBaseViewController

@end
