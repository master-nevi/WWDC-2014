/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 An example demonstrating adding accessibility to a CALayer subclass that behaves like an image by implementing the NSAccessibilityImage protocol.
 
 */

#import <Cocoa/Cocoa.h>
#import <QuartzCore/QuartzCore.h>

@interface AAPLCustomImageLayer : CALayer <NSAccessibilityImage>

@property (weak) id parent;
@property (weak) id titleElement;

@end
