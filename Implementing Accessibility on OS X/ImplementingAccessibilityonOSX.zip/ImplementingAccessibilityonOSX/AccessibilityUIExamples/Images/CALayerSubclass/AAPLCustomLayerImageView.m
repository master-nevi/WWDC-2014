/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 An example demonstrating adding accessibility to an NSView subclass that draws itself using two layers.
 
 */
#import "AAPLCustomLayerImageView.h"

static const CGFloat AAPLImageWidth = 75.0f;
static const CGFloat AAPLImageHeight = AAPLImageWidth;
static const CGFloat AAPLFontSize = 18.0f;
static const CGFloat AAPLTextFrameHeight = 25.0f;

@interface AAPLCustomLayerImageView ()

@property (nonatomic, strong) AAPLCustomImageLayer *imageLayer;
@property (nonatomic, strong) AAPLCustomTextLayer *textLayer;

@end

@implementation AAPLCustomLayerImageView

- (instancetype)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];

    if ( self != nil )
    {
        CALayer *rootLayer = [CALayer new];
        CGFloat backgroundColorcomponents[4] = {0.9f, 1.0f, 0.60f, 1.0f};
        CGColorSpaceRef colorSpace = CGColorSpaceCreateWithName(kCGColorSpaceGenericRGB);
        CGColorRef color = CGColorCreate(colorSpace, backgroundColorcomponents);
        rootLayer.backgroundColor = color;
        CGColorRelease(color);
        [self setLayer:rootLayer];
        
        AAPLCustomImageLayer *imageLayer = [AAPLCustomImageLayer new];

        [imageLayer setContents:[NSImage imageNamed:@"Recycle.png"]];
        [imageLayer setParent:self];

        NSRect imageFrame = NSMakeRect((frame.size.width / 2) - AAPLImageWidth,
                                       (frame.size.height / 2) - AAPLImageHeight,
                                       AAPLImageWidth,
                                       AAPLImageHeight);
        imageLayer.frame = imageFrame;
        imageLayer.anchorPoint = CGPointZero;
        [rootLayer addSublayer:imageLayer];

        AAPLCustomTextLayer *textLayer = [AAPLCustomTextLayer new];
        textLayer.string = NSLocalizedString(@"recycle", @"displayed text for the recycle image");
        textLayer.parent = self;
        textLayer.frame = CGRectMake(imageFrame.origin.x,
                                     imageFrame.origin.y,
                                     AAPLImageWidth,
                                     AAPLTextFrameHeight);
        textLayer.anchorPoint = CGPointZero;
        textLayer.fontSize = AAPLFontSize;
        textLayer.alignmentMode = @"center";
        CGFloat textColorComponents[4] = {0.0f, 0.0f, 0.0f, 1.0f};
        color = CGColorCreate(colorSpace, textColorComponents);
        textLayer.foregroundColor = color;
        CGColorRelease(color);
        [rootLayer addSublayer:textLayer];
        
        [self setWantsLayer:YES];
        CGColorSpaceRelease(colorSpace);
        
        imageLayer.titleElement = textLayer;

        self.imageLayer = imageLayer;
        self.textLayer = textLayer;
    }

    return self;
}

- (BOOL)wantsUpdateLayer
{
    return YES;
}

- (NSArray *)accessibilityChildren
{
    return @[self.imageLayer, self.textLayer];
}

- (id)accessibilityHitTest:(NSPoint)point
{
    id hitTestElement = nil;

    id accessibilityContainer = NSAccessibilityUnignoredAncestor(self);
    NSRect imageFrame = NSAccessibilityFrameInView(accessibilityContainer, self.imageLayer.frame);
    NSRect textFrame = NSAccessibilityFrameInView(accessibilityContainer, self.textLayer.frame);

    if ( NSPointInRect(point, imageFrame) )
    {
        hitTestElement = self.imageLayer;
    }
    else if ( NSPointInRect(point, textFrame) )
    {
        hitTestElement = self.textLayer;
    }
    else
    {
        hitTestElement = accessibilityContainer;
    }

    return hitTestElement;
}

@end
