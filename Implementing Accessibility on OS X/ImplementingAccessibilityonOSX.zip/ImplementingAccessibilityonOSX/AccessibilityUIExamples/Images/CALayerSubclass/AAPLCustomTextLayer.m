/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 An example demonstrating adding accessibility to an NSView subclass that behaves like a label by implementing the NSAccessibilityStaticText protocol.
 
 */
#import "AAPLCustomTextLayer.h"

@implementation AAPLCustomTextLayer

- (BOOL)accessibilityIsIgnored
{
    return NO;
}

- (id)accessibilityParent
{
    return NSAccessibilityUnignoredAncestor(self.parent);
}

- (NSRect)accessibilityFrame
{
    return NSAccessibilityFrameInView(self.accessibilityParent, self.frame);
}

- (NSString *)accessibilityValue;
{
    return self.string;
}

@end
