/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 An example demonstrating adding accessibility to a CALayer subclass that behaves like an image by implementing the NSAccessibilityImage protocol.
 
 */

#import "AAPLCustomImageLayer.h"

@implementation AAPLCustomImageLayer

- (BOOL)accessibilityIsIgnored
{
    return NO;
}

- (id)accessibilityParent
{
    return NSAccessibilityUnignoredAncestor(self.parent);
}

- (NSRect)accessibilityFrame
{
    return NSAccessibilityFrameInView(self.accessibilityParent, self.frame);
}

- (NSString *)accessibilityLabel
{
    return [self.titleElement string];
}

- (id)accessibilityTitleUIElement
{
    return self.titleElement;
}

@end
