/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 An example demonstrating adding accessibility to an NSView subclass that behaves like a checkbox by implementing the NSAccessibilityCheckBox protocol.
 
 */

#import <Cocoa/Cocoa.h>

@interface AAPLCustomCheckboxView : NSView <NSAccessibilityCheckBox>

@end
