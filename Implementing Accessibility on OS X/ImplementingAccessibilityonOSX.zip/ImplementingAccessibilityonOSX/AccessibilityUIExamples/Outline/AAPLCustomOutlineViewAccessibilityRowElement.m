/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 An accessibility element for a node representing an entry in an outline view.
 
 */


#import "AAPLCustomOutlineViewAccessibilityRowElement.h"
#import "AAPLCustomOutlineView.h"

@implementation AAPLCustomOutlineViewAccessibilityRowElement

// Override activation point to calculate it's position in screen coordinates relative to it's parent
// This is necessary to support the window moving
- (NSPoint)accessibilityActivationPoint
{
    return NSAccessibilityPointInView(self.accessibilityParent, self.disclosureTriangleCenterPoint);
}

// Override accessibilityDisclosed setter to update the the node this element represents
// This allows an accessibility client to expand or collapse a row in an outline
// (rather than just being able to read that state)
// VoiceOver, for example, exposes this via the Control+Command+\ command
- (void)setAccessibilityDisclosed:(BOOL)accessibilityDisclosed
{
    [super setAccessibilityDisclosed:accessibilityDisclosed];
    [self.accessibilityParent setExpandedStatus:accessibilityDisclosed forRowAtIndex:self.accessibilityIndex];
}

// Disallow calling accessibilityDisclosed setter on elements that can't disclose (leaf nodes)
- (BOOL)isAccessibilitySelectorAllowed:(SEL)selector
{
    if ( selector == @selector(setAccessibilityDisclosed:) )
    {
        return self.canDisclose;
    }
    return [super isAccessibilitySelectorAllowed:selector];
}

@end
