/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 An example demonstrating adding accessibility to an NSView subclass that behaves like an outline by implementing the NSAccessibilityOutline protocol and using NSAccessibilityElement.
 
 */

#import <Cocoa/Cocoa.h>
#import "AAPLOutlineViewNode.h"

// IMPORTANT: This is not a template for developing a custom control.
// This sample is intended to demonstrate how to add accessibility to
// existing custom controls that are not implemented using the preferred methods.
// For information on how to create custom controls please visit http://developer.apple.com

@interface AAPLCustomOutlineView : NSView <NSAccessibilityOutline>

- (void)setExpandedStatus:(BOOL)expanded forRowAtIndex:(NSUInteger)index;

@end
