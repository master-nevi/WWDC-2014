/*

 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 A node representing an entry in an outline view.

 */

#import <Foundation/Foundation.h>

@interface AAPLOutlineViewNode : NSObject <NSCopying>

@property(nonatomic, readonly) NSString *name;
@property(nonatomic, readonly) NSMutableArray *children;
@property(nonatomic, readonly) NSUInteger depth;
@property(nonatomic) BOOL expanded;

+ (instancetype)nodeWithName:(NSString *)name;
- (instancetype)addChildNodeWithName:(NSString *)name;

@end