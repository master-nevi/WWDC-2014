/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 A node representing an entry in an outline view.
 
 */

#import "AAPLOutlineViewNode.h"

static NSString * const AAPL_OUTLINE_NODE_DESCRIPTION_FORMATTER = @"OutlineNodeDescriptionFormatter";

@interface AAPLOutlineViewNode ()

@property(nonatomic, strong) NSString *name;
@property(nonatomic, strong) NSMutableArray *children;
@property(nonatomic) NSUInteger depth;

@end

@implementation AAPLOutlineViewNode

+ (AAPLOutlineViewNode *)nodeWithName:(NSString *)name
{
    return [AAPLOutlineViewNode nodeWithName:name andDepth:0];
}

+ (AAPLOutlineViewNode *)nodeWithName:(NSString *)name andDepth:(NSUInteger)depth
{
    AAPLOutlineViewNode *node = [[self alloc] init];
    node.name = name;
    node.expanded = NO;
    node.children = [NSMutableArray new];
    node.depth = depth;

    return node;
}

- (AAPLOutlineViewNode *)addChildNodeWithName:(NSString *)name
{
    AAPLOutlineViewNode *child = [AAPLOutlineViewNode nodeWithName:name andDepth:self.depth + 1];
    [self.children addObject:child];
    return child;
}

- (NSString *)description
{
    NSString *descriptionFormatter = NSLocalizedString(AAPL_OUTLINE_NODE_DESCRIPTION_FORMATTER, nil);
    return [NSString stringWithFormat:descriptionFormatter, super.description, self.depth, self.name];
}

- (NSUInteger)hash
{
    return [self.name hash] ^ [self.children hash] ^ self.depth;
}

- (BOOL)isEqual:(id)object
{
    if ( self == object )
    {
        return YES;
    }

    if ( [object isKindOfClass:[self class]] )
    {
        AAPLOutlineViewNode *other = (AAPLOutlineViewNode *)object;

        return self.depth == other.depth &&
               [self.name isEqualToString:other.name] &&
               [self.children isEqualToArray:other.children];
    }

    return [super isEqual:object];
}

- (instancetype)copyWithZone:(NSZone *)zone
{
    AAPLOutlineViewNode *copy = [AAPLOutlineViewNode nodeWithName:self.name andDepth:self.depth];
    copy.children = [self.children copy];
    return copy;
}
@end
