/*

 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 An accessibility element for a node representing an entry in an outline view.

 */

#import <Cocoa/Cocoa.h>

@interface AAPLCustomOutlineViewAccessibilityRowElement : NSAccessibilityElement

@property (nonatomic) CGPoint disclosureTriangleCenterPoint;
@property (nonatomic) BOOL canDisclose;

@end
