/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 An example demonstrating adding accessibility to an NSView subclass that behaves like an outline by implementing the NSAccessibilityOutline protocol and using NSAccessibilityElement.
 
 */

#import "AAPLCustomOutlineView.h"
#import "AAPLCustomOutlineViewAccessibilityRowElement.h"

// IMPORTANT: This is not a template for developing a custom control.
// This sample is intended to demonstrate how to add accessibility to
// existing custom controls that are not implemented using the preferred methods.
// For information on how to create custom controls please visit http://developer.apple.com

static const CGFloat AAPLOutlineRowHeight = 18.0f;
static const CGFloat AAPLOutlineBorderLineWidth = 2.0f;
static const CGFloat AAPLOutlineIndentationSize = 18.0f;

@interface AAPLCustomOutlineView ()

@property (nonatomic, strong) AAPLOutlineViewNode *rootNode;
@property (nonatomic) NSInteger selectedRow;
@property (nonatomic) NSInteger mouseDownRow;
@property (nonatomic) BOOL mouseDownInDisclosureTriangle;
@property (nonatomic, strong) NSMutableDictionary *accessibilityRowElements;

@end

@implementation AAPLCustomOutlineView
// synthesize protocol property for our custom implementation of the getter
@synthesize accessibilityRows = _accessibilityRows;

- (instancetype)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];

    if ( self != nil )
    {
        [self buildTree];
    }
    
    return self;
}

- (void)buildTree
{
    AAPLOutlineViewNode *rootNode = [AAPLOutlineViewNode nodeWithName:nil];
    rootNode.expanded = YES;
    AAPLOutlineViewNode *nobleGas = [rootNode addChildNodeWithName:NSLocalizedString(@"Noble Gas", nil)];
    nobleGas.expanded = YES;
    AAPLOutlineViewNode *semiMetal = [rootNode addChildNodeWithName:NSLocalizedString(@"Semi Metal", nil)];
    semiMetal.expanded = YES;
    [nobleGas addChildNodeWithName:NSLocalizedString(@"Neon", nil)];
    [nobleGas addChildNodeWithName:NSLocalizedString(@"Helium", nil)];

    AAPLOutlineViewNode *boron = [semiMetal addChildNodeWithName:NSLocalizedString(@"Boron", nil)];
    AAPLOutlineViewNode *silicon = [semiMetal addChildNodeWithName:NSLocalizedString(@"Silicon", nil)];

    [boron addChildNodeWithName:[NSNumberFormatter localizedStringFromNumber:@(10.811f) numberStyle:NSNumberFormatterDecimalStyle]];
    [silicon addChildNodeWithName:[NSNumberFormatter localizedStringFromNumber:@(28.086f) numberStyle:NSNumberFormatterDecimalStyle]];
    self.rootNode = rootNode;

    self.accessibilityRowElements = [[NSMutableDictionary alloc] init];
    self.selectedRow = 1;
}

- (BOOL)acceptsFirstResponder
{
    return YES;
}

- (BOOL)becomeFirstResponder
{
    BOOL didBecomeFirstResponder = [super becomeFirstResponder];

    if ( didBecomeFirstResponder )
    {
        [self setKeyboardFocusRingNeedsDisplayInRect:self.bounds];
    }

    [self setNeedsDisplay:YES];
    return didBecomeFirstResponder;
}

- (BOOL)resignFirstResponder
{
    BOOL didResignFirstResponder = [super resignFirstResponder];

    if ( didResignFirstResponder )
    {
        [self setKeyboardFocusRingNeedsDisplayInRect:self.bounds];
    }

    [self setNeedsDisplay:YES];
    return didResignFirstResponder;
}

- (void)mouseDown:(NSEvent *)mouseEvent
{
    NSPoint point = [self convertPoint:mouseEvent.locationInWindow fromView:nil];
    self.mouseDownRow = [self rowForPoint:point];

    NSRect disclosureTriangleRect = [self disclosureTriangleRectForRow:self.mouseDownRow];
    self.mouseDownInDisclosureTriangle = NSPointInRect(point, disclosureTriangleRect);
}

- (void)mouseUp:(NSEvent *)mouseEvent
{
    NSPoint point = [self convertPoint:mouseEvent.locationInWindow fromView:nil];
    NSInteger mouseUpRow = [self rowForPoint:point];
    if ( self.mouseDownRow == mouseUpRow )
    {
        NSRect disclosureTriangleRect = [self disclosureTriangleRectForRow:mouseUpRow];
        BOOL isMouseUpInDisclosureTriangle = NSPointInRect(point, disclosureTriangleRect);

        if ( self.mouseDownInDisclosureTriangle && isMouseUpInDisclosureTriangle )
        {
            AAPLOutlineViewNode *selectedNode = [self nodeAtRow:mouseUpRow];
            [self toggleExpandedStatusForNode:selectedNode];
        }
        else
        {
            self.selectedRow = mouseUpRow;
        }
    }
}

- (void)keyDown:(NSEvent *)keyEvent
{
    NSUInteger modifiers = [keyEvent modifierFlags];

    NSString *charactersIgnoringModifiers = [keyEvent charactersIgnoringModifiers];
    if ( charactersIgnoringModifiers.length == 1 )
    {
        NSInteger selectedRow = self.selectedRow;

        unichar keyChar = [charactersIgnoringModifiers characterAtIndex:0];
        if ( modifiers & NSNumericPadKeyMask )
        {
            if ( keyChar == NSDownArrowFunctionKey )
            {
                self.selectedRow = selectedRow + 1;
                return;
            }
            if ( keyChar == NSUpArrowFunctionKey )
            {
                self.selectedRow = selectedRow - 1;
                return;
            }
            if ( keyChar == NSLeftArrowFunctionKey )
            {
                AAPLOutlineViewNode *node = [self nodeAtRow:self.selectedRow];
                if ( [node expanded] )
                {
                    [self toggleExpandedStatusForNode:node];
                }
                return;
            }
            if ( keyChar == NSRightArrowFunctionKey )
            {
                AAPLOutlineViewNode *node = [self nodeAtRow:self.selectedRow];
                if ( ![node expanded] )
                {
                    [self toggleExpandedStatusForNode:node];
                }
                return;
            }
        }
        else if ( keyChar == ' ' )
        {
            AAPLOutlineViewNode *node = [self nodeAtRow:selectedRow];
            [self toggleExpandedStatusForNode:node];
            return;
        }
    }
    [super keyDown:keyEvent];
}

- (void)toggleExpandedStatusForNode:(AAPLOutlineViewNode *)node
{
    [self setExpandedStatus:!node.expanded forNode:node];
}

- (void)setExpandedStatus:(BOOL)expanded forRowAtIndex:(NSUInteger)index
{
    AAPLOutlineViewNode *node = [self nodeAtRow:index];
    if ( node.expanded != expanded )
    {
        [self setExpandedStatus:expanded forNode:node];
    }
}

- (void)setExpandedStatus:(BOOL)expanded forNode:(AAPLOutlineViewNode *)node
{
    if ( node != nil && node.children.count > 0 )
    {
        node.expanded = expanded;
        self.selectedRow = [self rowForNode:node];
        
        // Invalidate accessibilityRows so that it can be rebuilt
        self.accessibilityRows = nil;
        
        // Post a notification to let accessibility clients know a row has expanded or collapsed.
        // With a screen reader, for example, this could be announced as "row 1 expanded" or "row 2 collapsed"
        if ( node.expanded )
        {
            NSAccessibilityPostNotification([self accessibilityElementForNode:node], NSAccessibilityRowExpandedNotification);
        }
        else
        {
            NSAccessibilityPostNotification([self accessibilityElementForNode:node], NSAccessibilityRowCollapsedNotification);
        }
        // Post a notification to let accessibility clients know the row count has changed
        // With a screen reader, for example, this could be announced as "2 rows added"
        NSAccessibilityPostNotification(self, NSAccessibilityRowCountChangedNotification);
    }
}

- (void)setSelectedRow:(NSInteger)selectedRow
{
    if ( selectedRow >= [self rowCount] )
    {
        selectedRow = [self rowCount] - 1;
    }
    else if ( selectedRow < 0 )
    {
        selectedRow = 0;
    }

    _selectedRow = selectedRow;

    NSAccessibilityPostNotification(self, NSAccessibilitySelectedRowsChangedNotification);

    [self setNeedsDisplay:YES];
    [self displayIfNeeded];
}

- (NSInteger)rowCount
{
    return [[self visibleNodes] count];
}

- (NSInteger)rowForPoint:(NSPoint)point
{
    return (self.bounds.size.height - point.y - AAPLOutlineBorderLineWidth) / AAPLOutlineRowHeight;
}

- (NSInteger)rowForNode:(AAPLOutlineViewNode *)node
{
    return [[self visibleNodes] indexOfObject:node];
}

- (AAPLOutlineViewNode *)nodeAtRow:(NSInteger)row
{
    AAPLOutlineViewNode *node = nil;
    NSArray *visibleNodes = [self visibleNodes];
    if ( row >= 0 && (NSUInteger)row < visibleNodes.count )
    {
        node = visibleNodes[row];
    }
    return node;
}

- (AAPLOutlineViewNode *)selectedNode
{
    return [self nodeAtRow:self.selectedRow];
}

- (NSArray *)visibleNodes
{
    NSMutableArray *visibleNodes = [NSMutableArray array];
    
    [visibleNodes addObject:self.rootNode];
    
    for ( NSUInteger i = 0; i < [visibleNodes count]; i++ )
    {
        AAPLOutlineViewNode *node = visibleNodes[i];
        NSUInteger insertIndex = i + 1;
        if ( node.expanded )
        {
            NSArray *children = node.children;
            for ( AAPLOutlineViewNode *child in children )
            {
                if ( insertIndex < [visibleNodes count] )
                {
                    [visibleNodes insertObject:child atIndex:insertIndex];
                }
                else
                {
                    [visibleNodes addObject:child];
                }
                insertIndex++;
            }
        }
    }

    [visibleNodes removeObject:self.rootNode];
    return visibleNodes;
}

- (NSRect)rectForRow:(NSUInteger)row
{
    NSRect bounds = self.bounds;
    return NSMakeRect(bounds.origin.x + AAPLOutlineBorderLineWidth,
                      bounds.size.height - AAPLOutlineRowHeight * (row + 1) - (AAPLOutlineBorderLineWidth),
                      bounds.size.width - 2 * AAPLOutlineBorderLineWidth,
                      AAPLOutlineRowHeight);
}

- (NSRect)textRectForRow:(NSUInteger)row
{
    NSRect textRect = NSZeroRect;

    AAPLOutlineViewNode *node = [self nodeAtRow:row];
    if ( node != nil )
    {
        NSRect rowRect = [self rectForRow:row];
        textRect = NSMakeRect(rowRect.origin.x +  node.depth * AAPLOutlineIndentationSize,
                              rowRect.origin.y,
                              rowRect.size.width,
                              rowRect.size.height);
    }

    return textRect;
}

- (NSRect)disclosureTriangleRectForRow:(NSUInteger)row
{
    NSRect textRect = [self textRectForRow:row];
    return NSMakeRect(textRect.origin.x - AAPLOutlineIndentationSize + (AAPLOutlineBorderLineWidth * 1.5),
                      textRect.origin.y - AAPLOutlineBorderLineWidth,
                      AAPLOutlineIndentationSize,
                      textRect.size.height);
}

- (void)drawRect:(NSRect)dirtyRect
{
    // Draw the outline background
    NSRect bounds = self.bounds;
    [[NSColor whiteColor] set];
    NSRectFill(bounds);

    // Draw the outline border
    NSPoint topLeft = NSMakePoint(NSMinX(bounds), NSMaxY(bounds));
    NSPoint topRight = NSMakePoint(NSMaxX(bounds), NSMaxY(bounds));
    NSPoint bottomRight = NSMakePoint(NSMaxX(bounds), NSMinY(bounds));
    NSPoint bottomLeft = NSMakePoint(NSMinX(bounds), NSMinY(bounds));

    NSBezierPath *outlinePath = [NSBezierPath bezierPath];
    [outlinePath moveToPoint:topLeft];
    [outlinePath lineToPoint:topRight];
    [outlinePath lineToPoint:bottomRight];
    [outlinePath lineToPoint:bottomLeft];
    [outlinePath lineToPoint:topLeft];

    NSColor *gridOutlineColor = [NSColor blackColor];
    [gridOutlineColor set];
    [outlinePath setLineWidth:AAPLOutlineBorderLineWidth * 2.0];
    [outlinePath stroke];
    [outlinePath removeAllPoints];

    // Color the selected row
    BOOL isFirstResponder = [[[NSApp mainWindow] firstResponder] isEqual:self];
    NSInteger selectedRow = self.selectedRow;

    if ( selectedRow >= 0 )
    {
        NSColor *fillColor = isFirstResponder ? [NSColor alternateSelectedControlColor] : [NSColor secondarySelectedControlColor];
        [fillColor set];
        NSRect rowRect = [self rectForRow:selectedRow];
        NSRectFill(rowRect);
    }

    // Draw each row
    NSArray *visibleNodes = [self visibleNodes];

    for ( NSInteger row = 0; row < (NSInteger)visibleNodes.count; row++)
    {
        // Draw the row text
        AAPLOutlineViewNode *node = visibleNodes[row];
        NSRect textRect = [self textRectForRow:row];
        NSColor *textColor = (isFirstResponder && selectedRow == row) ? [NSColor whiteColor] : [NSColor blackColor];
        NSDictionary *textAttributes = @{ NSFontAttributeName : [NSFont systemFontOfSize:[NSFont systemFontSize]],
                                          NSForegroundColorAttributeName : textColor };

        [node.name drawInRect:textRect withAttributes:textAttributes];

        // Draw the row disclosure triangle
        if ( node.children.count > 0 )
        {
            NSRect disclosureRect = [self disclosureTriangleRectForRow:row];
            NSString *disclosureText = node.expanded ? @"▼" : @"►";
            [disclosureText drawInRect:disclosureRect withAttributes:nil];
        }
    }
}

#pragma mark Accessibility

- (NSString *)accessibilityLabel
{
    return NSLocalizedString(@"chemical property", @"accessibility label for the outline");
}

- (BOOL)accessibilityPerformPress
{
    [self toggleExpandedStatusForNode:[self selectedNode]];
    return YES;
}

- (void)setAccessibilitySelectedRows:(NSArray *)selectedRows
{
    if ( selectedRows.count == 1 )
    {
        NSArray *accessibilityRows = [self accessibilityRows];
        NSInteger selectedRow = [accessibilityRows indexOfObject:selectedRows.firstObject];
        if ( selectedRow != NSNotFound )
        {
            self.selectedRow = selectedRow;
        }
    }
}

- (NSArray *)accessibilitySelectedRows
{
    NSArray *accessibilityRows = [self accessibilityRows];
    return @[accessibilityRows[self.selectedRow]];
}

- (NSAccessibilityElement *)accessibilityElementForNode:(AAPLOutlineViewNode *)node
{
    AAPLCustomOutlineViewAccessibilityRowElement *rowElement = self.accessibilityRowElements[node];
    
    if ( rowElement == nil )
    {
        rowElement = [[AAPLCustomOutlineViewAccessibilityRowElement alloc] init];
        rowElement.accessibilityParent = self;
        rowElement.accessibilityRole = NSAccessibilityRowRole;
        rowElement.accessibilitySubrole = NSAccessibilityOutlineRowSubrole;
        self.accessibilityRowElements[node] = rowElement;
    }
    
    NSInteger row = [self rowForNode:node];
    NSRect rowRect = [self rectForRow:row];
    NSRect disclosureTriangleRect = [self disclosureTriangleRectForRow:row];
    NSPoint disclosureTriangleCenterPoint = NSMakePoint(NSMidX(disclosureTriangleRect), NSMidY(disclosureTriangleRect));
    
    rowElement.accessibilityLabel = node.name;
    rowElement.accessibilityFrameInParentSpace = rowRect;
    rowElement.accessibilityIndex = row;
    rowElement.accessibilityDisclosed = node.expanded;
    rowElement.accessibilityDisclosureLevel = node.depth;
    rowElement.disclosureTriangleCenterPoint = disclosureTriangleCenterPoint;
    rowElement.canDisclose = (node.children.count > 0);
    
    return rowElement;
}

- (NSArray *)accessibilityRows
{
    if ( _accessibilityRows == nil )
    {
        NSMutableArray *accessibilityRows = [[NSMutableArray alloc] init];
        NSArray * visibleNodes = [self visibleNodes];
        
        for ( AAPLOutlineViewNode *node in visibleNodes )
        {
            NSAccessibilityElement *element = [self accessibilityElementForNode:node];
            [accessibilityRows addObject:element];
        }
        
        _accessibilityRows = accessibilityRows;
    }

    return _accessibilityRows;
}

@end
