/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 An example demonstrating adding accessibility to an NSView subclass that behaves like a slider by implementing the NSAccessibilitySlider protocol.
 
 */

#import <Cocoa/Cocoa.h>

@interface AAPLCustomSliderView : NSView <NSAccessibilitySlider>

@end
