/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 An example demonstrating adding accessibility to an NSView subclass that behaves like a slider by implementing the NSAccessibilitySlider protocol.
 
 */

#import "AAPLCustomSliderView.h"

// IMPORTANT: This is not a template for developing a custom control.
// This sample is intended to demonstrate how to add accessibility to
// existing custom controls that are not implemented using the preferred methods.
// For information on how to create custom controls please visit http://developer.apple.com

static const CGFloat AAPLSliderHandleWidth = 12.0f;
static const CGFloat AAPLSliderHandleHeight = AAPLSliderHandleWidth;
static const CGFloat AAPLSliderMinValue = -50.0f;
static const CGFloat AAPLSliderMaxValue = 50.0f;
static const CGFloat AAPLSliderStepSize = 5.0f;
static const CGFloat AAPLSliderBorderLineWidth = 2.0f;

@interface AAPLCustomSliderView ()

@property (nonatomic) BOOL vertical;
@property (nonatomic) CGFloat minValue;
@property (nonatomic) CGFloat maxValue;
@property (nonatomic) CGFloat value;
@property (nonatomic) CGFloat stepSize;

@end


@implementation AAPLCustomSliderView

- (id)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];

    if ( self != nil )
    {
        self.vertical = frame.size.width < frame.size.height;
        self.minValue = AAPLSliderMinValue;
        self.maxValue = AAPLSliderMaxValue;
        self.stepSize = AAPLSliderStepSize;
        self.value = 0.0f;
    }

    return self;
}

- (BOOL)acceptsFirstResponder
{
    return YES;
}

- (BOOL)becomeFirstResponder
{
    BOOL didBecomeFirstResponder = [super becomeFirstResponder];
    [self setNeedsDisplay:YES];
    return didBecomeFirstResponder;
}

- (BOOL)resignFirstResponder
{
    BOOL didResignFirstResponder = [super resignFirstResponder];
    [self setNeedsDisplay:YES];
    return didResignFirstResponder;
}

- (void)decrement
{
    self.value -= self.stepSize;
    [self setNeedsDisplay:YES];
}

- (void)increment
{
    self.value += self.stepSize;
    [self setNeedsDisplay:YES];
}

- (void)keyDown:(NSEvent *)keyEvent
{
    if ( [keyEvent modifierFlags] & NSNumericPadKeyMask )
    {
        NSString *charactersIgnoringModifiers = [keyEvent charactersIgnoringModifiers];
        if ( [charactersIgnoringModifiers length] == 1 )
        {
            unichar keyChar = [charactersIgnoringModifiers characterAtIndex:0];
            if ( keyChar == NSDownArrowFunctionKey )
            {
                [self decrement];
                return;
            }
            else if ( keyChar == NSLeftArrowFunctionKey )
            {
                [self decrement];
                return;
            }
            else if ( keyChar == NSUpArrowFunctionKey )
            {
                [self increment];
                return;
            }
            else if ( keyChar == NSRightArrowFunctionKey )
            {
                [self increment];
                return;
            }
        }
    }
    [super keyDown:keyEvent];
}

- (NSRect)handleRect
{
    NSRect bounds = self.bounds;
    NSRect handleRect;

    if ( self.vertical )
    {
        handleRect = NSMakeRect(0,
                                [self handleRange] * [self percentValue],
                                bounds.size.width,
                                AAPLSliderHandleHeight);
    }
    else
    {
        handleRect = NSMakeRect([self handleRange] * [self percentValue],
                                0,
                                AAPLSliderHandleWidth,
                                bounds.size.height);
    }

    return handleRect;
}

- (void)setValue:(CGFloat)value
{
    if ( value < self.minValue )
    {
        value = self.minValue;
    }
    if ( value > self.maxValue )
    {
        value = self.maxValue;
    }
    _value = value;
    [self setNeedsDisplay:YES];
}

- (CGFloat)handleRange
{
    CGFloat range;

    if ( self.vertical )
    {
        range = self.bounds.size.height - AAPLSliderHandleHeight;
    }
    else
    {
        range = self.bounds.size.width - AAPLSliderHandleWidth;
    }

    return range;
}

- (CGFloat)valueRange
{
    return self.maxValue - self.minValue;
}

- (CGFloat)percentValue
{
    return (self.value - self.minValue) / [self valueRange];
}

- (void)mouseDown:(NSEvent *)mouseEvent
{
    NSPoint mouseDownPoint = [self convertPoint:mouseEvent.locationInWindow fromView:nil];
    NSRect handleRect = [self handleRect];

    if ( NSPointInRect(mouseDownPoint, handleRect) )
    {
        CGFloat unitsPerPoint = [self valueRange] / [self handleRange];
        CGFloat mouseDownValue = self.value;

        NSEvent *nextEvent = [[self window] nextEventMatchingMask: NSLeftMouseUpMask | NSLeftMouseDraggedMask];
        while ( nextEvent.type != NSLeftMouseUp )
        {
            NSPoint mousePoint = [self convertPoint:nextEvent.locationInWindow fromView:nil];

            CGFloat draggedDistance = 0;
            if ( self.vertical )
            {
                draggedDistance = mousePoint.y - mouseDownPoint.y;
            }
            else
            {
                draggedDistance = mousePoint.x - mouseDownPoint.x;
            }

            self.value = mouseDownValue + unitsPerPoint * draggedDistance;

            nextEvent = [[self window] nextEventMatchingMask: NSLeftMouseUpMask | NSLeftMouseDraggedMask];
        };
    }
}


- (void)drawRect:(NSRect)dirtyRect
{
    NSRect bounds = self.bounds;

    // Draw the slider background
    [[NSColor whiteColor] set];
    NSRectFill(bounds);

    // Draw the slider outline
    NSBezierPath *outline = [NSBezierPath bezierPathWithRect:bounds];
    [[NSColor blackColor] set];
    [outline setLineWidth:AAPLSliderBorderLineWidth];
    [outline stroke];

    // Draw the slider handle
    NSBezierPath *handle = [NSBezierPath bezierPathWithRect:[self handleRect]];
    [handle fill];

    // Draw the focus ring
    BOOL isFirstResponder = [[[NSApp mainWindow] firstResponder] isEqual:self];
    if ( isFirstResponder )
    {
        [NSGraphicsContext saveGraphicsState];
        NSSetFocusRingStyle(NSFocusRingOnly);
        [handle fill];
        [NSGraphicsContext restoreGraphicsState];
    }
}


#pragma mark Accessibility

- (NSString *)accessibilityLabel
{
    NSString *label;

    if ( self.vertical )
    {
        label = NSLocalizedString(@"Y Value", nil);
    }
    else
    {
        label = NSLocalizedString(@"X Value", nil);
    }

    return label;
}

- (id)accessibilityValue
{
    return @(self.value);
}

- (BOOL)accessibilityPerformIncrement
{
    [self increment];
    return YES;
}

- (BOOL)accessibilityPerformDecrement
{
    [self decrement];
    return YES;
}

@end
