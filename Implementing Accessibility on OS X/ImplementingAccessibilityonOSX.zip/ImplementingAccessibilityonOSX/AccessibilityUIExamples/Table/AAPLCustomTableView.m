/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 An example demonstrating adding accessibility to an NSView subclass that behaves like a table by implementing the NSAccessibilityTable protocol and using NSAccessibilityElement.
 
 */

#import "AAPLCustomTableView.h"

// IMPORTANT: This is not a template for developing a custom control.
// This sample is intended to demonstrate how to add accessibility to
// existing custom controls that are not implemented using the preferred methods.
// For information on how to create custom controls please visit http://developer.apple.com

static const int AAPLTableRowCount = 6;
static const int AAPLTableColumnCount = 4;
static const CGFloat AAPLTableOutlineWidth = 4.0;
static const CGFloat AAPLTableGridWidth = 1.0;

@interface AAPLCustomTableView ()

@property (nonatomic) NSInteger selectedRow;
@property (nonatomic) NSInteger mouseDownRow;

@end

@implementation AAPLCustomTableView
// synthesize protocol property for a custom implementation of the getter
@synthesize accessibilityRows = _accessibilityRows;

- (instancetype)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];

    if ( self != nil )
    {
        [self buildTable];
        self.selectedRow = 1;
    }

    return self;
}

- (void)buildTable
{
    if ( self.tableData == nil )
    {
        NSMutableArray *rows = [[NSMutableArray alloc] initWithCapacity:AAPLTableRowCount];
        for ( int row = 0; row < AAPLTableRowCount; row++ )
        {
            NSMutableArray *cols = [[NSMutableArray alloc] initWithCapacity:AAPLTableColumnCount];
            for ( int col = 0; col < AAPLTableColumnCount; col++ )
            {
                if ( row == 0 && col == 0 )
                {
                    [cols addObject:NSLocalizedString(@"Table", "text for the top left corner cell of the table")];
                }
                else if ( row == 0 )
                {
                    [cols addObject:[NSString stringWithFormat:NSLocalizedString(@"ColumnFormatter", "text for the table column cells"), col]];
                }
                else if ( col == 0 )
                {
                    [cols addObject:[NSString stringWithFormat:NSLocalizedString(@"RowFormatter", "text for the table row cells"), row]];
                }
                else
                {
                    [cols addObject:[NSString stringWithFormat:NSLocalizedString(@"CellFormatter", "text for a table cell"), (row * (AAPLTableColumnCount - 1)) + col]];
                }
            }
            [rows addObject:cols];
        }
        self.tableData = rows;
    }
}

- (BOOL)acceptsFirstResponder
{
    return YES;
}

- (BOOL)becomeFirstResponder
{
    BOOL didBecomeFirstResponder = [super becomeFirstResponder];

    if ( didBecomeFirstResponder )
    {
        [self setKeyboardFocusRingNeedsDisplayInRect:self.bounds];
    }

    [self setNeedsDisplay:YES];
    return didBecomeFirstResponder;
}

- (BOOL)resignFirstResponder
{
    BOOL didResignFirstResponder = [super resignFirstResponder];

    if ( didResignFirstResponder )
    {
        [self setKeyboardFocusRingNeedsDisplayInRect:self.bounds];
    }

    [self setNeedsDisplay:YES];
    return didResignFirstResponder;
}

- (NSRect)rectForRow:(NSUInteger)row
{
    NSRect bounds = self.bounds;
    return NSMakeRect(0,
                      (AAPLTableRowCount - row - 1) * (bounds.size.height / AAPLTableRowCount),
                      bounds.size.width,
                      bounds.size.height / AAPLTableRowCount);
}

- (NSRect)rectForRow:(NSUInteger)row column:(NSUInteger)col
{
    NSRect bounds = self.bounds;
    return NSMakeRect(col * (bounds.size.width / AAPLTableColumnCount),
                      (AAPLTableRowCount - row - 1) * (bounds.size.height / AAPLTableRowCount),
                      (bounds.size.width / AAPLTableColumnCount),
                      bounds.size.height / AAPLTableRowCount);
}

- (NSRect)rectForCellInRowCoordsForRow:(NSUInteger)row column:(NSUInteger)col
{
    NSRect rowRect = [self rectForRow:row];
    NSRect cellRect = [self rectForRow:row column:col];

    return NSMakeRect(cellRect.origin.x - rowRect.origin.x,
                      cellRect.origin.y - rowRect.origin.y,
                      cellRect.size.width,
                      cellRect.size.height);
}

- (void)mouseDown:(NSEvent *)mouseEvent
{
    NSPoint point = [self convertPoint:mouseEvent.locationInWindow fromView:nil];
    self.mouseDownRow = [self rowForPoint:point];
}

- (void)mouseUp:(NSEvent *)mouseEvent
{
    NSPoint point = [self convertPoint:mouseEvent.locationInWindow fromView:nil];
    NSInteger mouseUpRow = [self rowForPoint:point];
    if ( self.mouseDownRow == mouseUpRow )
    {
        self.selectedRow = mouseUpRow;
    }
}

- (NSInteger)rowForPoint:(NSPoint)point
{
    NSRect bounds = self.bounds;
    NSInteger row = AAPLTableRowCount - (point.y / (bounds.size.height / AAPLTableRowCount));
    return row;
}

- (void)setSelectedRow:(NSInteger)selectedRow
{
    if ( selectedRow >= AAPLTableRowCount )
    {
        selectedRow = (AAPLTableRowCount - 1);
    }
    else if ( selectedRow < 0 )
    {
        selectedRow = 0;
    }

    _selectedRow = selectedRow;

    NSAccessibilityPostNotification(self, NSAccessibilitySelectedRowsChangedNotification);
    [self setNeedsDisplay:YES];
}

- (void)keyDown:(NSEvent *)keyEvent
{
    if ( [keyEvent modifierFlags] & NSNumericPadKeyMask )
    {
        NSString *charactersIgnoringModifiers = [keyEvent charactersIgnoringModifiers];
        if ( [charactersIgnoringModifiers length] == 1 )
        {
            unichar keyChar = [charactersIgnoringModifiers characterAtIndex:0];
            if ( keyChar == NSDownArrowFunctionKey )
            {
                self.selectedRow++;
                return;
            }
            if ( keyChar == NSUpArrowFunctionKey )
            {
                self.selectedRow--;
                return;
            }
        }
    }
    [super keyDown:keyEvent];
}

- (void)drawRect:(NSRect)dirtyRect
{
    // Draw the table background
    NSRect bounds = self.bounds;
    [[NSColor whiteColor] set];
    NSRectFill(bounds);

    // Draw the selected row highlights
    if ( self.selectedRow >= 0 )
    {
        BOOL isFirstResponder = [[[NSApp mainWindow] firstResponder] isEqual:self];
        for ( int col = 0; col < AAPLTableColumnCount; col++ )
        {
            NSColor *color = isFirstResponder ? [NSColor alternateSelectedControlColor] : [NSColor secondarySelectedControlColor];
            [color set];

            NSRect cellRect = [self rectForRow:self.selectedRow column:col];
            NSRectFill(cellRect);
        }
    }

    // Define the corners of the table
    NSPoint topLeft = NSMakePoint(NSMinX(bounds), NSMaxY(bounds));
    NSPoint topRight = NSMakePoint(NSMaxX(bounds), NSMaxY(bounds));
    NSPoint bottomRight = NSMakePoint(NSMaxX(bounds), NSMinY(bounds));
    NSPoint bottomLeft = NSMakePoint(NSMinX(bounds), NSMinY(bounds));

    // Define the table outline path
    NSBezierPath *tableOutline = [NSBezierPath bezierPath];
    [tableOutline moveToPoint:topLeft];
    [tableOutline lineToPoint:topRight];
    [tableOutline lineToPoint:bottomRight];
    [tableOutline lineToPoint:bottomLeft];
    [tableOutline lineToPoint:topLeft];

    // Draw the table outline
    [[NSColor blackColor] set];
    [tableOutline setLineWidth:AAPLTableOutlineWidth];
    [tableOutline stroke];

    // Define the table grid path
    NSBezierPath *grid = [NSBezierPath bezierPath];
    for ( int row = 0; row < AAPLTableRowCount; row++ )
    {
        NSPoint lineStart = topLeft;
        NSPoint lineEnd = topRight;
        lineStart.y = lineEnd.y = ((float)row * (bounds.size.height / AAPLTableRowCount));
        [grid moveToPoint:lineStart];
        [grid lineToPoint:lineEnd];
    }

    for ( int col = 0; col < AAPLTableColumnCount; col++ )
    {
        NSPoint lineStart = topLeft;
        NSPoint lineEnd = bottomLeft;
        lineStart.x = lineEnd.x = ((float)col * (bounds.size.width / AAPLTableColumnCount));
        [grid moveToPoint:lineStart];
        [grid lineToPoint:lineEnd];
    }

    // Draw the table grid
    [[NSColor blackColor] set];
    [grid setLineWidth:AAPLTableGridWidth];
    [grid stroke];
    
    // Draw the cell text
    NSMutableParagraphStyle *style = [[NSParagraphStyle defaultParagraphStyle] mutableCopy];
    [style setAlignment:NSCenterTextAlignment];
    NSDictionary *textAttributes = [NSDictionary dictionaryWithObjectsAndKeys:style, NSParagraphStyleAttributeName, [NSFont systemFontOfSize:[NSFont systemFontSize]], NSFontAttributeName, nil];
    NSDictionary *boldTextAttributes = [NSDictionary dictionaryWithObjectsAndKeys:style, NSParagraphStyleAttributeName, [NSFont boldSystemFontOfSize:[NSFont systemFontSize]], NSFontAttributeName, nil];

    for ( int row = 0; row < AAPLTableRowCount; row++ )
    {
        NSArray *rowData = self.tableData[row];
        for ( int col = 0; col < AAPLTableColumnCount; col++ )
        {
            NSString *cellText = rowData[col];
            NSRect cellRect = [self rectForRow:row column:col];
            cellRect.origin.y = ceil(cellRect.origin.y - 5);

            // Draw the text of header column and row cells in bold
            if ( row == 0 || col == 0 )
            {
                [cellText drawInRect:cellRect withAttributes:boldTextAttributes];
            }
            else
            {
                [cellText drawInRect:cellRect withAttributes:textAttributes];
            }
        }
    }
}

#pragma mark Accessibility

- (void)setAccessibilitySelectedRows:(NSArray *)selectedRows
{
    if ( [selectedRows count] == 1 )
    {
        NSArray *accessibilityRows = self.accessibilityRows;
        NSInteger index = [accessibilityRows indexOfObject:[selectedRows lastObject]];
        self.selectedRow = index;
    }
}

- (NSArray *)accessibilitySelectedRows
{
    NSArray *accessiblityRows = [self accessibilityRows];
    return @[accessiblityRows[self.selectedRow]];
}

- (NSArray *)accessibilityRows
{
    if ( _accessibilityRows == nil )
    {
        int row, col;
        NSAccessibilityElement *rowElement;
        NSAccessibilityElement *cellElement;
        NSArray *rowData;
        NSString *cellText;
        NSMutableArray *accessibilityRows = [[NSMutableArray alloc] initWithCapacity:AAPLTableRowCount];
        for ( row = 0; row < AAPLTableRowCount; row++ )
        {
            rowData = self.tableData[row];
            rowElement = [NSAccessibilityElement new];
            rowElement.accessibilityParent = self;
            rowElement.accessibilityRole = NSAccessibilityRowRole;
            rowElement.accessibilitySubrole = NSAccessibilityTableRowSubrole;
            rowElement.accessibilityFrameInParentSpace = [self rectForRow:row];
            rowElement.accessibilityIndex = row;

            for ( col = 0; col < AAPLTableColumnCount; col++ )
            {
                cellText = rowData[col];
                cellElement = [NSAccessibilityElement new];
                cellElement.accessibilityRole = NSAccessibilityStaticTextRole;
                cellElement.accessibilityLabel = cellText;
                cellElement.accessibilityFrameInParentSpace = [self rectForCellInRowCoordsForRow:row column:col];
                [rowElement accessibilityAddChildElement:cellElement];
            }

            [accessibilityRows addObject:rowElement];
        }
        _accessibilityRows = accessibilityRows;
    }
    return _accessibilityRows;
}

- (NSString *)accessibilityLabel
{
    return NSLocalizedString(@"basic", @"accessibility label for a basic table");
}

@end
