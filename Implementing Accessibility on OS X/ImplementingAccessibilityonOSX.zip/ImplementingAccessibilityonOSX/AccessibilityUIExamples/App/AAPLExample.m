/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 An object representing a single accessibility example.
 
 */

#import "AAPLExample.h"

@implementation AAPLExample

- (instancetype)initGroupWithName:(NSString *)name
{
    self = [super init];

    if ( self != nil )
    {
        _name = name;
        _children = [NSMutableArray new];
        _group = YES;
    }

    return self;
}

- (instancetype)initExampleWithName:(NSString *)name
                    descriptionText:(NSString *)descriptionText
                viewControllerClass:(Class)viewControllerClass
{
    self = [super init];

    if ( self != nil )
    {
        _name = name;
        _descriptionText = descriptionText;
        _viewControllerClass = viewControllerClass;
        _group = NO;
    }

    return self;
}

@end