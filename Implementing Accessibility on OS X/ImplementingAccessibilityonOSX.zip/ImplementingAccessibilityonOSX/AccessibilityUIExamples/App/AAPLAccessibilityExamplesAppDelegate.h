/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 Class that loads and displays examples from a configuration plist.
 
 */

#import <Cocoa/Cocoa.h>

@class AAPLAccessibilityExamplesBaseViewController;

@interface AAPLAccessibilityExamplesAppDelegate : NSObject <NSApplicationDelegate>

@end
