/*

 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 An object representing a single accessibility example.

 */

#import <Foundation/Foundation.h>

@interface AAPLExample : NSObject

@property (nonatomic, readonly) BOOL group;
@property (nonatomic, readonly) NSString *name;
@property (nonatomic, readonly) NSString *descriptionText;
@property (nonatomic, strong) NSMutableArray *children;
@property (nonatomic, readonly) Class viewControllerClass;

- (instancetype)initGroupWithName:(NSString *)name;

- (instancetype)initExampleWithName:(NSString *)name
                    descriptionText:(NSString *)descriptionText
                viewControllerClass:(Class)viewControllerClass;

@end
