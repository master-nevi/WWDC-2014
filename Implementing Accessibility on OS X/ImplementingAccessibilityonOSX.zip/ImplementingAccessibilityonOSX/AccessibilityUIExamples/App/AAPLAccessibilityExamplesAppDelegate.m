/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 Class that loads and displays examples from a configuration plist.
 
 */

#import "AAPLAccessibilityExamplesAppDelegate.h"
#import "AAPLAccessibilityExamplesBaseViewController.h"
#import "AAPLExample.h"

#import "AAPLButtonViewController.h"
#import "AAPLCoreTextArcViewController.h"
#import "AAPLCoreTextColumnViewController.h"
#import "AAPLCustomButtonViewController.h"
#import "AAPLCustomCheckboxViewController.h"
#import "AAPLCustomImageViewController.h"
#import "AAPLCustomLayerImageViewController.h"
#import "AAPLCustomLayoutAreaViewController.h"
#import "AAPLCustomOutlineViewController.h"
#import "AAPLCustomRadioButtonsViewController.h"
#import "AAPLCustomSliderViewController.h"
#import "AAPLCustomStepperViewController.h"
#import "AAPLCustomTableViewController.h"
#import "AAPLIdealCustomButtonViewController.h"
#import "AAPLIdealCustomImageViewController.h"
#import "AAPLImageButtonViewController.h"
#import "AAPLProtectedTextViewController.h"
#import "AAPLSearchFieldController.h"
#import "AAPLThreePositionSwitchViewController.h"
#import "AAPLTransientUIViewController.h"
#import "AAPLTwoPositionSwitchViewController.h"

#pragma mark - App delegate private interface

@interface AAPLAccessibilityExamplesAppDelegate ()

@property (nonatomic, weak) IBOutlet NSWindow *window;
@property (nonatomic, strong) AAPLAccessibilityExamplesBaseViewController *demoController;
@property (nonatomic, strong) NSArray *sidebarElements;

@property (nonatomic, weak) IBOutlet NSOutlineView *sidebarOutlineView;
@property (nonatomic, weak) IBOutlet NSBox *demoViewArea;
@property (nonatomic, weak) IBOutlet NSTextField *demoDescription;

@end

#pragma mark - App delegate

@implementation AAPLAccessibilityExamplesAppDelegate

- (void)awakeFromNib
{
    [super awakeFromNib];
    NSWindow *window = self.window;
    window.acceptsMouseMovedEvents = YES;
    window.ignoresMouseEvents = NO;
}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    NSOutlineView *outlineView = self.sidebarOutlineView;
    [outlineView reloadData];
    [outlineView setFloatsGroupRows:NO];
    [outlineView expandItem:nil expandChildren:YES];
    [outlineView selectRowIndexes:[NSIndexSet indexSetWithIndex:1] byExtendingSelection:NO];
}

- (void)showExample:(AAPLExample *)example;
{
    AAPLAccessibilityExamplesBaseViewController *controller = [example.viewControllerClass new];

    if ( ![controller isEqual:self.demoController] )
    {
        self.demoController = controller;
        self.demoViewArea.contentView = controller.view;
        self.demoDescription.stringValue = example.descriptionText;

        [self.window recalculateKeyViewLoop];
    }
}

#pragma mark Outline view delegate

- (BOOL)outlineView:(NSOutlineView *)outlineView isGroupItem:(id)item
{
    AAPLExample *example = (AAPLExample *)item;
    return example.group;
}

- (void)outlineViewSelectionDidChange:(NSNotification *)notification
{
    NSOutlineView *outlineView = self.sidebarOutlineView;
    NSInteger selectedRow = outlineView.selectedRow;

    if ( selectedRow != -1 )
    {
        AAPLExample *example = (AAPLExample *)[outlineView itemAtRow:selectedRow];

        if ( !example.group )
        {
            [self showExample:example];
        }
    }
}

- (NSInteger)outlineView:(NSOutlineView *)outlineView numberOfChildrenOfItem:(id)item
{
    NSArray *children = [self childrenForItem:item];
    return children.count;
}

- (id)outlineView:(NSOutlineView *)outlineView child:(NSInteger)index ofItem:(id)item
{
    NSArray *children = [self childrenForItem:item];
    return children[index];
}

- (BOOL)outlineView:(NSOutlineView *)outlineView isItemExpandable:(id)item
{
    AAPLExample *example = (AAPLExample *)item;
    return example.group;
}

- (NSView *)outlineView:(NSOutlineView *)outlineView viewForTableColumn:(NSTableColumn *)tableColumn item:(id)item
{
    NSView *view = nil;
    AAPLExample *example = (AAPLExample *)item;

    if ( example.group )
    {
        NSTextField *headerView = [outlineView makeViewWithIdentifier:@"Header" owner:self];
        headerView.stringValue = example.name;
        view = headerView;
    }
    else
    {
        NSTableCellView *cellView = [outlineView makeViewWithIdentifier:@"MainCell" owner:self];
        cellView.textField.stringValue = example.name;
        view = cellView;
    }

    return view;
}

#pragma mark - Helper methods

- (NSArray *)childrenForItem:(id)item
{
    NSArray *children;

    if ( item != nil && [item isKindOfClass:[AAPLExample class]] )
    {
        AAPLExample *example = (AAPLExample *)item;
        children = example.children;
    }
    else
    {
        children = self.sidebarElements;
    }

    return children;
}

- (NSArray *)sidebarElements
{
    if ( _sidebarElements == nil )
    {
        // Button
        AAPLExample *button = [[AAPLExample alloc] initExampleWithName:NSLocalizedString(@"NSButton", "NSButton example name")
                                                       descriptionText:NSLocalizedString(@"NSButtonDescription", "NSButton example description")
                                                   viewControllerClass:[AAPLButtonViewController class]];

        AAPLExample *imageButton = [[AAPLExample alloc] initExampleWithName:NSLocalizedString(@"NSButton with image", "NSButton with image example name")
                                                            descriptionText:NSLocalizedString(@"NSButtonWithImageDescription", "NSButton with image example description")
                                                        viewControllerClass:[AAPLImageButtonViewController class]];

        AAPLExample *idealCustomButton = [[AAPLExample alloc] initExampleWithName:NSLocalizedString(@"NSButton subclass", "NSButton subclass example name")
                                                                  descriptionText:NSLocalizedString(@"NSButtonSubclassDescription", "NSButton subclass example description")
                                                              viewControllerClass:[AAPLIdealCustomButtonViewController class]];

        AAPLExample *customButton = [[AAPLExample alloc] initExampleWithName:NSLocalizedString(@"NSView subclass", "NSView subclass example name")
                                                             descriptionText:NSLocalizedString(@"NSViewSubclassButtonDescription", "NSView subclass button example description")
                                                         viewControllerClass:[AAPLCustomButtonViewController class]];

        AAPLExample *buttonGroup = [[AAPLExample alloc] initGroupWithName:NSLocalizedString(@"Buttons", "Buttons group name")];
        [buttonGroup.children addObjectsFromArray:@[button, imageButton, idealCustomButton, customButton]];


        // Static Text
        AAPLExample *protectedText = [[AAPLExample alloc] initExampleWithName:NSLocalizedString(@"Protected", "Protected example name")
                                                              descriptionText:NSLocalizedString(@"ProtectedDescription", "Protected example description")
                                                          viewControllerClass:[AAPLProtectedTextViewController class]];

        AAPLExample *arcText = [[AAPLExample alloc] initExampleWithName:NSLocalizedString(@"Arc", "Arc example name")
                                                        descriptionText:NSLocalizedString(@"ArcDescription", "Arc example description")
                                                    viewControllerClass:[AAPLCoreTextArcViewController class]];

        AAPLExample *columnText = [[AAPLExample alloc] initExampleWithName:NSLocalizedString(@"Columns", "Columns example name")
                                                           descriptionText:NSLocalizedString(@"ColumnDescription", "Column example description")
                                                       viewControllerClass:[AAPLCoreTextColumnViewController class]];

        AAPLExample *textGroup = [[AAPLExample alloc] initGroupWithName:NSLocalizedString(@"Text", "Text group name")];
        [textGroup.children addObjectsFromArray:@[protectedText, arcText, columnText]];

        // Switch
        AAPLExample *twoPositionSwitch = [[AAPLExample alloc] initExampleWithName:NSLocalizedString(@"Two Position", "Two position example name")
                                                                  descriptionText:NSLocalizedString(@"TwoPositionDescription", "Two position example description")
                                                              viewControllerClass:[AAPLTwoPositionSwitchViewController class]];

        AAPLExample *threePositionSwitch = [[AAPLExample alloc] initExampleWithName:NSLocalizedString(@"Three Position", "Three position example name")
                                                                    descriptionText:NSLocalizedString(@"ThreePositionDescription", "Three position example description")
                                                                viewControllerClass:[AAPLThreePositionSwitchViewController class]];

        AAPLExample *switchGroup = [[AAPLExample alloc] initGroupWithName:NSLocalizedString(@"Switches", "Switches group description")];
        [switchGroup.children addObjectsFromArray:@[twoPositionSwitch, threePositionSwitch]];

        // Image
        AAPLExample *idealCustomImage = [[AAPLExample alloc] initExampleWithName:NSLocalizedString(@"NSImageView subclass", "NSImageView subclass example name")
                                                                 descriptionText:NSLocalizedString(@"NSImageViewSubclassDescription", "NSImageView subclass example description")
                                                             viewControllerClass:[AAPLIdealCustomImageViewController class]];

        AAPLExample *customImage = [[AAPLExample alloc] initExampleWithName:NSLocalizedString(@"NSView subclass", "NSView subclass example name")
                                                            descriptionText:NSLocalizedString(@"NSViewSubclassImageDescription", "NSView subclass image example description")
                                                        viewControllerClass:[AAPLCustomImageViewController class]];

        AAPLExample *layerImage = [[AAPLExample alloc] initExampleWithName:NSLocalizedString(@"CALayer subclass", "CALayer subclass example name")
                                                           descriptionText:NSLocalizedString(@"CALayerSubclassImageDescription", "CALayer subclass image example description")
                                                       viewControllerClass:[AAPLCustomLayerImageViewController class]];

        AAPLExample *imageGroup = [[AAPLExample alloc] initGroupWithName:NSLocalizedString(@"Images", "Images group name")];
        [imageGroup.children addObjectsFromArray:@[idealCustomImage, customImage, layerImage]];

        // Other Elements
        AAPLExample *radioButton = [[AAPLExample alloc] initExampleWithName:NSLocalizedString(@"Radio Button", "Radio button example name")
                                                            descriptionText:NSLocalizedString(@"RadioButtonDescription", "Radio button example description")
                                                        viewControllerClass:[AAPLCustomRadioButtonsViewController class]];

        AAPLExample *checkbox = [[AAPLExample alloc] initExampleWithName:NSLocalizedString(@"Checkbox", "Checkbox example name")
                                                         descriptionText:NSLocalizedString(@"CheckboxDescription", "Checkbox example description")
                                                     viewControllerClass:[AAPLCustomCheckboxViewController class]];

        AAPLExample *slider = [[AAPLExample alloc] initExampleWithName:NSLocalizedString(@"Slider", "Slider example name")
                                                       descriptionText:NSLocalizedString(@"SliderDescription", "Slider example description")
                                                   viewControllerClass:[AAPLCustomSliderViewController class]];

        AAPLExample *layoutArea = [[AAPLExample alloc] initExampleWithName:NSLocalizedString(@"Layout Area", "Layout area example name")
                                                           descriptionText:NSLocalizedString(@"LayoutAreaDescription", "Layout area example description")
                                                       viewControllerClass:[AAPLCustomLayoutAreaViewController class]];

        AAPLExample *outline = [[AAPLExample alloc] initExampleWithName:NSLocalizedString(@"Outline", "Outline example name")
                                                        descriptionText:NSLocalizedString(@"OutlineDescription", "Outline example description")
                                                    viewControllerClass:[AAPLCustomOutlineViewController class]];

        AAPLExample *table = [[AAPLExample alloc] initExampleWithName:NSLocalizedString(@"Table", "Table example name")
                                                      descriptionText:NSLocalizedString(@"TableDescription", "Table example description")
                                                  viewControllerClass:[AAPLCustomTableViewController class]];

        AAPLExample *stepper = [[AAPLExample alloc] initExampleWithName:NSLocalizedString(@"Stepper", "Stepper example name")
                                                        descriptionText:NSLocalizedString(@"StepperDescription", "Stepper example description")
                                                    viewControllerClass:[AAPLCustomStepperViewController class]];

        AAPLExample *transientUI = [[AAPLExample alloc] initExampleWithName:NSLocalizedString(@"Transient UI", "Transient UI example name")
                                                            descriptionText:NSLocalizedString(@"TransientUIDescription", "Transient UI example description")
                                                        viewControllerClass:[AAPLTransientUIViewController class]];

        AAPLExample *searchField = [[AAPLExample alloc] initExampleWithName:NSLocalizedString(@"Search Field", "Search field example name")
                                                            descriptionText:NSLocalizedString(@"SearchFieldDescription", "Search field example description")
                                                        viewControllerClass:[AAPLSearchFieldController class]];

        AAPLExample *otherGroup = [[AAPLExample alloc] initGroupWithName:NSLocalizedString(@"Other Elements", "Other elements group name")];
        [otherGroup.children addObjectsFromArray:@[radioButton, checkbox, slider, layoutArea, outline, table, stepper, transientUI, searchField]];

        _sidebarElements = [NSArray arrayWithObjects:buttonGroup, textGroup, switchGroup, imageGroup, otherGroup, nil];
    }

    return _sidebarElements;
}


@end
