/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 An example demonstrating adding accessibility to an NSView subclass that shows a hidden view on mouse over by implementing the NSAccessibilityContainsTransientUI protocol.
 
 */

#import "AAPLTransientUITriggerView.h"

const CGFloat AAPLShowHideTransientUIAnimationDuration = 0.2f;

@interface AAPLTransientUITriggerView ()
- (void)sendTransientUIChangedNotification;
@end

@implementation AAPLTransientUITriggerView

- (id)init
{
    self = [super init];

    if ( self != nil )
    {
        [self createTrackingArea];
    }

    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];

    if ( self != nil )
    {
        [self createTrackingArea];
    }

    return self;
}

- (id)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];

    if ( self != nil )
    {
        [self createTrackingArea];
    }

    return self;
}

- (void)awakeFromNib
{
    self.transientView.alphaValue = 0.0;
    self.transientView.hidden = YES;
}

- (void)createTrackingArea
{
    NSTrackingAreaOptions options = NSTrackingActiveInActiveApp;
    options |= NSTrackingMouseEnteredAndExited;
    options |= NSTrackingMouseMoved;
    options |= NSTrackingInVisibleRect;
    options |= NSTrackingActiveAlways;
    
    NSTrackingArea *tracking = [[NSTrackingArea alloc] initWithRect:NSZeroRect
                                                            options:options
                                                              owner:self
                                                           userInfo:nil];
    [self addTrackingArea:tracking];
}

- (void)showTransientView
{
    [self setTransientViewIsHidden:NO];
}

- (void)hideTransientView
{
    [self setTransientViewIsHidden:YES];
}

- (void)setTransientViewIsHidden:(BOOL)transientViewIsHidden
{
    if ( transientViewIsHidden != self.transientView.hidden )
    {
        self.transientView.hidden = transientViewIsHidden;

        NSAnimationContext *animationContext = [NSAnimationContext currentContext];
        [NSAnimationContext beginGrouping];

        [animationContext setDuration:AAPLShowHideTransientUIAnimationDuration];
        [[self.transientView animator] setAlphaValue:self.transientView.hidden ? 0.0 : 1.0];

        [NSAnimationContext endGrouping];
        
        [self sendTransientUIChangedNotification];
    }
}

- (void)mouseMoved:(NSEvent *)mouseEvent
{
    [self showTransientView];
}

- (void)mouseEntered:(NSEvent *)mouseEvent
{
    [self showTransientView];
}

- (void)mouseExited:(NSEvent *)mouseEvent
{
    [self hideTransientView];
}


#pragma mark Accessibility

- (BOOL)isAccessibilityAlternateUIVisible
{
    return !self.transientView.hidden;
}

- (BOOL)accessibilityPerformShowAlternateUI
{
    [self showTransientView];
    return YES;
}

- (BOOL)accessibilityPerformShowDefaultUI
{
    [self hideTransientView];
    return YES;
}

- (void)sendTransientUIChangedNotification
{
    NSArray *changedElements = NSAccessibilityUnignoredChildren([self.transientView subviews]);

    NSAccessibilityPostNotificationWithUserInfo(self, NSAccessibilityLayoutChangedNotification, @{NSAccessibilityUIElementsKey : changedElements});
}
@end
