/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 View controller demonstrating an accessible, custom NSView subclass that shows a hidden view on mouse over.
 
 */

#import "AAPLTransientUIViewController.h"

static const int AAPLPageCount = 10;

@implementation AAPLTransientUIViewController

- (void)awakeFromNib
{
    [self updatePageTextView];
}

- (void)updateButtons
{
    BOOL nextButtonEnabled = self.page < (AAPLPageCount - 1);
    [self.nextPageButton setEnabled:nextButtonEnabled];
    [self.previousPageButton setEnabled:self.page > 0];
    
    if ( !nextButtonEnabled )
    {
        NSWindow *currentWindow = self.previousPageButton.window;
        [currentWindow makeFirstResponder:self.previousPageButton];
    }
}

- (void)updatePageTextView
{
    NSString *pageNumber = [NSNumberFormatter localizedStringFromNumber:@(self.page + 1) numberStyle:NSNumberFormatterDecimalStyle];
    NSString *pageCount = [NSNumberFormatter localizedStringFromNumber:@(AAPLPageCount) numberStyle:NSNumberFormatterDecimalStyle];
    
    [self.pageTextField setStringValue:[NSString stringWithFormat:NSLocalizedString(@"PageCountFormatter", "page count formatter"), pageNumber, pageCount]];
    
    [self updateButtons];
}

- (IBAction)pressNextPageButton:(id)sender
{
    if ( self.page < AAPLPageCount )
    {
        self.page++;
    }

    [self updatePageTextView];
}

- (IBAction)pressPreviousPageButton:(id)sender
{
    if ( self.page > 0 )
    {
        self.page--;
    }

    [self updatePageTextView];
}

@end
