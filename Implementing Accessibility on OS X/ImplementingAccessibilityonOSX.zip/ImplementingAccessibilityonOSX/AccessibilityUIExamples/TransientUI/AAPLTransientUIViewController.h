/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 View controller demonstrating an accessible, custom NSView subclass that shows a hidden view on mouse over.
 
 */

#import <Cocoa/Cocoa.h>
#import "AAPLAccessibilityExamplesBaseViewController.h"

@interface AAPLTransientUIViewController : AAPLAccessibilityExamplesBaseViewController

@property (nonatomic) NSUInteger page;
@property (nonatomic, weak) IBOutlet NSTextField *pageTextField;
@property (nonatomic, weak) IBOutlet NSButton *nextPageButton;
@property (nonatomic, weak) IBOutlet NSButton *previousPageButton;

- (IBAction)pressNextPageButton:(id)sender;
- (IBAction)pressPreviousPageButton:(id)sender;

@end
