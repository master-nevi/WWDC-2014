/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 An example demonstrating adding accessibility to an NSView subclass that behaves like a radio button group by implementing the NSAccessibilityGroup protocol and using NSAccessibilityElement.
 
 */

#import "AAPLCustomRadioButtonsView.h"

// IMPORTANT: This is not a template for developing a custom control.
// This sample is intended to demonstrate how to add accessibility to
// existing custom controls that are not implemented using the preferred methods.
// For information on how to create custom controls please visit http://developer.apple.com

static const CGFloat AAPLRadioButtonHeight = 22.0f;
static const CGFloat AAPLRadioCircleWidth = 10.0f;
static const CGFloat AAPLRadioCircleHeight = AAPLRadioCircleWidth;
static const CGFloat AAPLRadioToTextSpacing = 7.0f;

@interface AAPLRadioButtonAccessibilityElement : NSAccessibilityElement
@property (nonatomic) NSUInteger button;
@end

@interface AAPLCustomRadioButtonsView ()

@property (nonatomic, strong) NSArray *radioButtonText;
@property (nonatomic) NSUInteger mouseDownButton;
@property (nonatomic) NSUInteger selectedButton;

@end

@implementation AAPLCustomRadioButtonsView
// synthesize protocol property for our custom implementation of the getter
@synthesize accessibilityChildren = _accessibilityChildren;

- (instancetype)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];

    if ( self != nil )
    {
        self.radioButtonText = @[NSLocalizedString(@"Choice one", "text of first choice"),
                                 NSLocalizedString(@"Choice two", "text of second choice"),
                                 NSLocalizedString(@"Choice three", "text of thrid choice")];
        self.selectedButton = 0;
    }

    return self;
}

- (BOOL)acceptsFirstResponder
{
    return YES;
}

- (BOOL)becomeFirstResponder
{
    BOOL didBecomeFirstResponder = [super becomeFirstResponder];
    [self setNeedsDisplay:YES];
    return didBecomeFirstResponder;
}

- (BOOL)resignFirstResponder
{
    BOOL didResignFirstResponder = [super resignFirstResponder];
    [self setNeedsDisplay:YES];
    return didResignFirstResponder;
}

- (NSRect)rectForButton:(NSUInteger)button
{
    return NSMakeRect(self.bounds.origin.x,
                      self.bounds.size.height - AAPLRadioButtonHeight * (button + 1),
                      self.bounds.size.width,
                      AAPLRadioButtonHeight);
}

- (NSRect)textHitTestRectForButton:(NSUInteger)button
{
    NSRect textDrawingRect = [self textDrawingRectForButton:button];
    NSString *text = self.radioButtonText[button];
    NSRect textBoundingRect = [text boundingRectWithSize:NSMakeSize(textDrawingRect.size.width,
                                                                    [NSFont systemFontSize])
                                                 options:0
                                              attributes:nil];

    return NSMakeRect(textDrawingRect.origin.x,
                      textDrawingRect.origin.y,
                      textBoundingRect.size.width,
                      textDrawingRect.size.height);
}

- (NSRect)textDrawingRectForButton:(NSUInteger)button
{
    NSRect buttonRect = [self rectForButton:button];
    CGFloat textOriginXOffset = AAPLRadioCircleWidth + AAPLRadioToTextSpacing;
    return NSMakeRect(buttonRect.origin.x + textOriginXOffset,
                      buttonRect.origin.y,
                      buttonRect.size.width - textOriginXOffset,
                      buttonRect.size.height);
}

- (NSRect)radioCircleHitTestRectForButton:(NSUInteger)button
{
    return [self radioCircleDrawingRectForButton:button];
}

- (NSRect)radioCircleDrawingRectForButton:(NSUInteger)button
{
    NSRect buttonRect = [self rectForButton:button];
    return NSMakeRect(buttonRect.origin.x,
                      buttonRect.origin.y + (buttonRect.size.height - AAPLRadioCircleHeight) / 2.0f + 2.0f,
                      AAPLRadioCircleWidth,
                      AAPLRadioCircleHeight);
}

- (NSUInteger)buttonForPoint:(NSPoint)point
{
    return (self.bounds.size.height - point.y) / AAPLRadioButtonHeight;
}

- (void)mouseDown:(NSEvent *)mouseEvent
{
    NSPoint point = [self convertPoint:mouseEvent.locationInWindow fromView:nil];
    self.mouseDownButton = [self buttonForPoint:point];
}

- (void)mouseUp:(NSEvent *)mouseEvent
{
    NSPoint point = [self convertPoint:mouseEvent.locationInWindow fromView:nil];
    NSUInteger mouseUpButton = [self buttonForPoint:point];
    if ( mouseUpButton == self.mouseDownButton )
    {
        self.selectedButton = mouseUpButton;
    }
}

- (void)setSelectedButton:(NSUInteger)selectedButton
{
    if ( selectedButton >= self.radioButtonText.count )
    {
        selectedButton = self.radioButtonText.count - 1;
    }

    _selectedButton = selectedButton;

    NSAccessibilityPostNotification(self, NSAccessibilityFocusedUIElementChangedNotification);
    [self setNeedsDisplay:YES];
}

- (void)keyDown:(NSEvent *)keyEvent
{
    if ( [keyEvent modifierFlags] & NSNumericPadKeyMask )
    {
        NSString *charactersIgnoringModifiers = [keyEvent charactersIgnoringModifiers];
        unichar keyChar = 0;
        if ( [charactersIgnoringModifiers length] == 1 )
        {
            keyChar = [charactersIgnoringModifiers characterAtIndex:0];
            NSUInteger selectedButton = self.selectedButton;

            if ( keyChar == NSDownArrowFunctionKey )
            {
                self.selectedButton = selectedButton + 1;
                return;
            }
            if ( keyChar == NSUpArrowFunctionKey )
            {
                self.selectedButton = selectedButton - 1;
                return;
            }
        }
    }
    [super keyDown:keyEvent];
}

- (void)drawRect:(NSRect)dirtyRect
{
    BOOL isFirstResponder = [[[NSApp mainWindow] firstResponder] isEqual:self];
    NSUInteger selectedButton = self.selectedButton;
    NSBundle *bundle = [NSBundle mainBundle];
    NSDictionary *textAttributes = @{ NSFontAttributeName : [NSFont systemFontOfSize:[NSFont systemFontSize]],
                                      NSForegroundColorAttributeName : [NSColor blackColor]};

    NSUInteger radioButtonCount = self.radioButtonText.count;
    for ( NSUInteger i = 0; i < radioButtonCount; i++ )
    {
        // Draw the radio circle
        NSRect radioCircleRect = [self radioCircleDrawingRectForButton:i];
        NSImage *radioCircleImage = nil;
        
        if ( i == selectedButton )
        {
            radioCircleImage = [bundle imageForResource:@"CustomRadioButtonSelected"];
        }
        else
        {
            radioCircleImage = [bundle imageForResource:@"CustomRadioButtonUnselected"];
        }

        [radioCircleImage drawInRect:radioCircleRect fromRect:NSZeroRect operation:NSCompositeSourceOver fraction:1.0];


        // Draw the radio text
        NSRect textRect = [self textDrawingRectForButton:i];
        NSString *buttonText = self.radioButtonText[i];
        [buttonText drawInRect:textRect withAttributes:textAttributes];

        // Draw the focus ring
        if ( isFirstResponder && i == selectedButton )
        {
            [NSGraphicsContext saveGraphicsState];
            NSSetFocusRingStyle(NSFocusRingOnly);
            [[NSBezierPath bezierPathWithOvalInRect:radioCircleRect] fill];
            [NSGraphicsContext restoreGraphicsState];
        }
    }
}


#pragma mark Accessibility

- (id)accessibilityFocusedUIElement
{
    return self.accessibilityChildren[self.selectedButton];
}

- (NSArray *)accessibilityChildren
{
    if ( _accessibilityChildren == nil )
    {
        NSUInteger count = self.radioButtonText.count;
        NSMutableArray *children = [[NSMutableArray alloc] initWithCapacity:count];
        for ( NSUInteger button = 0; button < count; button++ )
        {
            NSString *buttonText = self.radioButtonText[button];

            AAPLRadioButtonAccessibilityElement *radioButton = [AAPLRadioButtonAccessibilityElement new];

            NSRect bounds = [self rectForButton:button];
            bounds = NSAccessibilityFrameInView(self, bounds);
            radioButton.button = button;
            radioButton.accessibilityParent = self;
            radioButton.accessibilityRole = NSAccessibilityRadioButtonRole;
            radioButton.accessibilityFrame = bounds;
            radioButton.accessibilityLabel = buttonText;
            [children addObject:radioButton];
        }

        _accessibilityChildren = [children copy];
    }

    // Ensure activation point and value are up to date whenever the children are returned
    for ( NSUInteger button = 0; button < _accessibilityChildren.count; button++ )
    {
        AAPLRadioButtonAccessibilityElement *radioButton = _accessibilityChildren[button];
        NSRect activationBounds = [self radioCircleHitTestRectForButton:button];
        NSPoint activationBoundsCenterPoint = NSMakePoint(NSMidX(activationBounds), NSMidY(activationBounds));
        radioButton.accessibilityActivationPoint = NSAccessibilityPointInView(self, activationBoundsCenterPoint);
        radioButton.accessibilityValue = (button == self.selectedButton) ? @YES : @NO;
    }

    return _accessibilityChildren;
}

@end

@implementation AAPLRadioButtonAccessibilityElement
- (void)setAccessibilityFocused:(BOOL)accessibilityFocused
{
    if ( accessibilityFocused )
    {
        AAPLCustomRadioButtonsView *parent = (AAPLCustomRadioButtonsView *)self.accessibilityParent;
        [parent becomeFirstResponder];

        parent.selectedButton = self.button;
    }
}
@end

