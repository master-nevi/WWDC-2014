/*
 
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 An example demonstrating adding accessibility to an NSView subclass that behaves like a radio button group by implementing the NSAccessibilityGroup protocol and using NSAccessibilityElement.
 
 */

#import <Cocoa/Cocoa.h>

@interface AAPLCustomRadioButtonsView : NSView <NSAccessibilityGroup>

@property (nonatomic, readonly) NSUInteger selectedButton;

@end
