# Implementing Accessibility on OS X

This sample contains examples of several common control elements with various implementations and code to make them accessible by utilizing accessibility properties, accessibility protocols, and NSAccessibilityElement.

## Requirements

### Build

OS X 10.10 SDK, Xcode 6

### Runtime

OS X 10.10 or later

Copyright (C) 2014 Apple Inc. All rights reserved.


## 10.10 API Overview

The OS X 10.10 Accessibility API transitions from a key based API to a method based API.

The goals of this API are:

* Make it easy to add accessibility
* Better API parity with iOS
* Compatibility with existing apps and code


The 10.9 and prior API is deprecated, but can coexist along with the 10.10 API. No changes are required for applications that currently implement accessibility, nor for accessibility clients (e.g., VoiceOver), to continue working with the new API. Going forward, all new accessibility code should be implemented using the new API. If both the new API and old API are implemented, the new API always wins.

### Accessibility Properties

A majority of the accessibility attributes used in 10.9 and prior are now properties on certain AppKit classes:

* NSApplication
* NSWindow
* NSView
* NSDrawer
* NSPopover
* NSCell

Set the accessibility attribute on an instance of one of these classes (or a subclass) by calling the setter for the property:

```objective-c
myObject.accessibilityLabel = NSLocalizedString(@"My label", nil);

```

or by overriding the getter in the implementation file:

```objective-c
// MyObject.m
...

- (NSString *)accessibilityLabel
{
	return NSLocalizedString(@"My label", nil);
}
```

Accessibility should be added to the cell of cell based controls.

### Accessibility Protocols

The 10.10 Accessibility API includes accessibility protocols for many common accessibility elements and which define the required accessibility methods for each. Conformance to an accessibility protocol is not required to use the new API, but is helpful when adding accessibility to custom controls. Conforming to an accessibility protocol displays a warning for each unimplemented required method and allows the new API to automatically infer the accessibility role and isAccessibilityElement.

Standard AppKit controls conform to the appropriate accessibility protocol (e.g., NSButton conforms to NSAccessibilityButton protocol, NSSlider conforms to NSAccessibilitySlider protocol). Whenever possible, sublass from the appropriate AppKit control to leverage the built-in accessibility.

To add accessibility to a custom control, (e.g., an NSView subclass that draws and behaves like button):

1. Pick and conform to the appropriate protocol
2. Implement all the required methods (a warning is given for each unimplemented required method)
3. Test using VoiceOver and Accessibility Inspector

Accessibility protocol conformance is not required to add accessibility to custom controls using the new API, however if not used, accessibilityRole and accessibilityIsIgnored must be implemented.

Example:

```objective-c
// MyButton.m (NSView subclass, no protocol conformance)
...
-  (NSString *)accessibilityRole
{
	return NSAccessibilityButtonRole;
}

- (BOOL)accessibilityIsIgnored
{
	return NO;
}
```
### NSAccessibilityElement

For objects that don't have a backing view (e.g. a view draws several items, each of which should be individually accessible), create an instance of NSAccessibilityElement for each object.

This can be done directly:

```objective-c

AccessibilityElement *image = [NSAccessibilityElement new];
image.accessibilityRole = NSAccessibilityImageRole;
image.accessibilityFrame = Frame;
image.accessibilityParent = parent;
image.accessibilityLabel = NSLocalizedString(label;

```

### Testing

Verify accessibility with AccessibilityInspector, a tool that ships with Xcode in the Developer Tools menu, or VoiceOver, the built-in screen reader on OS X. Enable VoiceOver from System Preferences > Accessibility > VoiceOver > Enable VoiceOver or by pressing Command-F5
