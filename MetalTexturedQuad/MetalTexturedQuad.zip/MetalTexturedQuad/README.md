# MetalTexturedQuad

This basic sample shows how to create a basic textured quad in metal.

## Requirements

### Build

iOS 8 SDK

### Runtime

iOS 8 SDK and A7 Devices

Copyright (C) 2014 Apple Inc. All rights reserved.
