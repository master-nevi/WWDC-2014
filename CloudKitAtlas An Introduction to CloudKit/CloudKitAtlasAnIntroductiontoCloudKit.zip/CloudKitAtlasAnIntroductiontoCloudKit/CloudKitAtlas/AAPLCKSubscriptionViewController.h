/*
    Copyright (C) 2014 Apple Inc. All Rights Reserved.
    See LICENSE.txt for this sample’s licensing information
    
    Abstract:
    
            This lets you subscribe and unsubscribe to Items
         
*/

@import UIKit;
#import "AAPLCloudManager.h"

@interface AAPLCKSubscriptionViewController : UITableViewController

@property (strong) AAPLCloudManager *cloudManager;

@end
