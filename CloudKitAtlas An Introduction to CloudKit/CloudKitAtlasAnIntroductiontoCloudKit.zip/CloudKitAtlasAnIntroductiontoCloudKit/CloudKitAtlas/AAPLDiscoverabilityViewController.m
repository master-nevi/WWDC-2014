/*
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information

 */

#import "AAPLDiscoverabilityViewController.h"
#import "AAPLCloudManager.h"

@interface AAPLDiscoverabilityViewController()

@property (weak) IBOutlet UILabel *name;

@end

@implementation AAPLDiscoverabilityViewController

- (void)viewDidAppear:(BOOL)animated {
    [self.cloudManager requestDiscoverabilityPermission:^(BOOL discoverable) {
        
        if (discoverable) {
            [self.cloudManager discoverUserInfo:^(CKDiscoveredUserInfo *user) {
                [self discoveredUserInfo:user];
            }];
        } else {
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"CloudKitAtlas"
                                                                           message:@"Getting your name using Discoverability requires permission."
                                                                    preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction *action = [UIAlertAction actionWithTitle:@"OK"
                                                             style:UIAlertActionStyleDefault
                                                           handler:^(UIAlertAction *act) {
                                                               [self dismissViewControllerAnimated:YES completion:nil];
                                                           }];
            [alert addAction:action];
            [self presentViewController:alert animated:YES completion:nil];
        }
    }];
}

- (void)discoveredUserInfo:(CKDiscoveredUserInfo *)user {
    if (user != nil) {
        NSString *fullName = [NSString stringWithFormat:@"%@ %@", user.firstName, user.lastName];
        self.name.text = fullName;
    } else {
        self.name.text = @"Anonymous";
    }
}

@end
