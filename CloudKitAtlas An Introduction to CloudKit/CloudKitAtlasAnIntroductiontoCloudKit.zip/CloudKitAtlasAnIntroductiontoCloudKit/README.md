# CloudKitAtlas: An Introduction to CloudKit

CloudKitAtlas is a sample intended as a quick introduction to CloudKit. It teaches you how to use Discoverability to get the first name and last name of the user logged into iCloud. It can add a CKRecord with a location and query for CKRecords near a location. You can upload and retrieve images as CKAssets. It also shows how to use CKReferences with CKReferenceActionDeleteSelf so the child records are deleted when the parent record is deleted. Finally, it also shows how to use CKSubscription to get push notifications when a new item is added for a record type.


## Requirements

### Build

- iOS 8.0 SDK and Xcode 6
- Enable the CloudKit entitlement in iCloud (from Capabilities)
- Change your container name to provision a container in your developer account

### Runtime

- iOS 8.0

Copyright (C) 2014 Apple Inc. All rights reserved.
