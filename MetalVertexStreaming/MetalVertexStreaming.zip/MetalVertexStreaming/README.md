# MetalVertexStreaming

This sample shows how to stream vertex data between 3 command buffers using one block of memory shared by both the CPU and GPU.

## Requirements

### Build

iOS 8

### Runtime

iOS 8, A7 devices

Copyright (C) 2014 Apple Inc. All rights reserved.
