//
//  AAPLPMiOSAppDelegate.h
//  PhotoMemories-iOS
//
//  Copyright (c) 2014 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AAPLPMiOSAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
