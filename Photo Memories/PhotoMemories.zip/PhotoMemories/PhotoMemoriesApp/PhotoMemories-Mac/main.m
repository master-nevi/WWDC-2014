//
//  main.m
//  PhotoMemories
//
//  Copyright (c) 2014 Apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[])
{
    return NSApplicationMain(argc, argv);
}
