# Using AVFoundation metadata reading APIs to draw recorded location on map view

This sample shows the use of AVAssetReaderOutputMetadataAdaptor to read location metadata from a movie file containing this information. The location data is then plotted on MKMapView to present the location path where the video was recorded. This sample also shows the use of AVPlayerItemMetadataOutput to show current location on the drawn path during playback.

## Requirements

### Build

Xcode 5.0 or later, Mac OS X v10.10 or later

### Runtime

Mac OS X v10.10 or later

Copyright (C) 2014 Apple Inc. All rights reserved.
