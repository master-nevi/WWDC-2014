/*
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 
  Metal Renderer for Metal Basic 3D. Acts as the update and render delegate for the view controller and performs rendering. In MetalBasic3D, the renderer draws two cubes, one whos color values changes and one whos color values are static. This mimics the original Xcode template for OpenGL ES but is renderered using Metal instead.
  
 */

#import "METLRenderer.h"
#import "METLViewController.h"
#import "METLView.h"
#import "METLTransforms.h"
#import "METLSharedTypes.h"

static const long kMaxBufferBytesPerFrame = 1024*1024;
static const long kInFlightCommandBuffers = 3;

static const simd::float4 kBox1AmbientColor = {0.18, 0.24, 0.8, 1.0};
static const simd::float4 kBox1DiffuseColor = {0.4, 0.4, 1.0, 1.0};

static const simd::float4 kBox2AmbientColor = {0.8, 0.24, 0.1, 1.0};
static const simd::float4 kBox2DiffuseColor = {0.8, 0.4, 0.4, 1.0};

static const float kFOVY          = 65.0f;
static const simd::float3 kEye    = {0.0f, 0.0f, 0.0f};
static const simd::float3 kCenter = {0.0f, 0.0f, 1.0f};
static const simd::float3 kUp     = {0.0f, 1.0f, 0.0f};

static const float kWidth  = 0.75f;
static const float kHeight = 0.75f;
static const float kDepth  = 0.75f;

static const float kCubeVertexData[] =
{
    kWidth, -kHeight, kDepth,   0.0, -1.0,  0.0,  
    -kWidth, -kHeight, kDepth,   0.0, -1.0, 0.0,  
    -kWidth, -kHeight, -kDepth,   0.0, -1.0,  0.0,
    kWidth, -kHeight, -kDepth,  0.0, -1.0,  0.0,  
    kWidth, -kHeight, kDepth,   0.0, -1.0,  0.0,  
    -kWidth, -kHeight, -kDepth,   0.0, -1.0,  0.0,
    
    kWidth, kHeight, kDepth,    1.0, 0.0,  0.0,
    kWidth, -kHeight, kDepth,   1.0,  0.0,  0.0,  
    kWidth, -kHeight, -kDepth,  1.0,  0.0,  0.0,  
    kWidth, kHeight, -kDepth,   1.0, 0.0,  0.0,
    kWidth, kHeight, kDepth,    1.0, 0.0,  0.0,
    kWidth, -kHeight, -kDepth,  1.0,  0.0,  0.0,  
    
    -kWidth, kHeight, kDepth,    0.0, 1.0,  0.0,
    kWidth, kHeight, kDepth,    0.0, 1.0,  0.0,
    kWidth, kHeight, -kDepth,   0.0, 1.0,  0.0,
    -kWidth, kHeight, -kDepth,   0.0, 1.0,  0.0,  
    -kWidth, kHeight, kDepth,    0.0, 1.0,  0.0,
    kWidth, kHeight, -kDepth,   0.0, 1.0,  0.0,
    
    -kWidth, -kHeight, kDepth,  -1.0,  0.0, 0.0,  
    -kWidth, kHeight, kDepth,   -1.0, 0.0,  0.0,
    -kWidth, kHeight, -kDepth,  -1.0, 0.0,  0.0,  
    -kWidth, -kHeight, -kDepth,  -1.0,  0.0,  0.0,
    -kWidth, -kHeight, kDepth,  -1.0,  0.0, 0.0,  
    -kWidth, kHeight, -kDepth,  -1.0, 0.0,  0.0,
    
    kWidth, kHeight,  kDepth,  0.0, 0.0,  1.0,    
    -kWidth, kHeight,  kDepth,  0.0, 0.0,  1.0,   
    -kWidth, -kHeight, kDepth,   0.0,  0.0, 1.0,  
    -kWidth, -kHeight, kDepth,   0.0,  0.0, 1.0,  
    kWidth, -kHeight, kDepth,   0.0,  0.0,  1.0,  
    kWidth, kHeight,  kDepth,  0.0, 0.0,  1.0,    
    
    kWidth, -kHeight, -kDepth,  0.0,  0.0, -1.0,  
    -kWidth, -kHeight, -kDepth,   0.0,  0.0, -1.0,
    -kWidth, kHeight, -kDepth,  0.0, 0.0, -1.0,   
    kWidth, kHeight, -kDepth,  0.0, 0.0, -1.0,    
    kWidth, -kHeight, -kDepth,  0.0,  0.0, -1.0,  
    -kWidth, kHeight, -kDepth,  0.0, 0.0, -1.0   
};

@implementation METLRenderer
{
    id <MTLDevice> _device;
    id <MTLCommandQueue> _commandQueue;
    id <MTLLibrary> _defaultLibrary;
    
    dispatch_semaphore_t _inflight_semaphore;
    id <MTLBuffer> _dynamicConstantBuffer[kInFlightCommandBuffers];
    
    // render stage
    id <MTLRenderPipelineState> _pipelineState;
    id <MTLBuffer> _vertexBuffer;
    id <MTLDepthStencilState> _depthState;
    
    // global transform data
    simd::float4x4 _projectionMatrix;
    simd::float4x4 _viewMatrix;
    
    METL::uniforms_t _constant_buffer[2];
    float _rotation;
    int8_t _multiplier;
}

- (void)dealloc
{
    // discard hints to destroy objects right away on dealloc
    _device = nil;
    _commandQueue = nil;
    _defaultLibrary = nil;
    
    for (int i = 0; i < kInFlightCommandBuffers; i++)
        _dynamicConstantBuffer[i] = nil;
    
    _pipelineState = nil;
    _vertexBuffer = nil;
    _depthState = nil;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        
        _sampleCount = 4;
        _depthPixelFormat = MTLPixelFormatDepth32Float;
        _stencilPixelFormat = MTLPixelFormatInvalid;
        
        // find a usable Device
        _device = MTLCreateSystemDefaultDevice();
        
        // create a new command queue
        _commandQueue = [_device newCommandQueue];
        
        _defaultLibrary = [_device newDefaultLibrary];
        if(!_defaultLibrary) {
            NSLog(@">> ERROR: Couldnt create a default shader library");
            
            // assert here becuase if the shader libary isnt loading, nothing good will happen
            assert(0);
        }
        
        _constantDataBufferIndex = 0;
        _inflight_semaphore = dispatch_semaphore_create(kInFlightCommandBuffers);
        
        _constant_buffer[0].ambient_color = kBox1AmbientColor;
        _constant_buffer[0].diffuse_color = kBox1DiffuseColor;
        
        _constant_buffer[1].ambient_color = kBox2AmbientColor;
        _constant_buffer[1].diffuse_color = kBox2DiffuseColor;
        
        _multiplier = 1;
    }
    return self;
}

#pragma mark RENDER VIEW DELEGATE METHODS

- (void)loadAssets
{
    // allocate one region of memory for the constant buffer
    for (int i = 0; i < kInFlightCommandBuffers; i++)
    {
        _dynamicConstantBuffer[i] = [_device newBufferWithLength:kMaxBufferBytesPerFrame options:0];
        _dynamicConstantBuffer[i].label = [NSString stringWithFormat:@"ConstantBuffer%i", i];
    }
    
    // load the fragment program into the library
    id <MTLFunction> fragmentProgram = [_defaultLibrary newFunctionWithName:@"lighting_fragment"];
    if(!fragmentProgram)
        NSLog(@">> ERROR: Couldnt load fragment function from default library");
    
    // load the vertex program into the library
    id <MTLFunction> vertexProgram = [_defaultLibrary newFunctionWithName:@"lighting_vertex"];
    if(!vertexProgram)
        NSLog(@">> ERROR: Couldnt load vertex function from default library");
    
    // setup the vertex buffers
    _vertexBuffer = [_device newBufferWithBytes:kCubeVertexData length:sizeof(kCubeVertexData) options:MTLResourceOptionCPUCacheModeDefault];
    _vertexBuffer.label = @"Vertices";
    
    //  create a reusable pipeline state
    MTLRenderPipelineDescriptor *pipelineStateDescriptor = [[MTLRenderPipelineDescriptor alloc] init];
    pipelineStateDescriptor.label = @"MyPipeline";
    [pipelineStateDescriptor setPixelFormat: MTLPixelFormatBGRA8Unorm atIndex:MTLFramebufferAttachmentIndexColor0];
    [pipelineStateDescriptor setPixelFormat: _depthPixelFormat atIndex:MTLFramebufferAttachmentIndexDepth];
    [pipelineStateDescriptor setPixelFormat: _stencilPixelFormat atIndex:MTLFramebufferAttachmentIndexStencil];
    [pipelineStateDescriptor setSampleCount: _sampleCount];
    [pipelineStateDescriptor setVertexFunction:vertexProgram];
    [pipelineStateDescriptor setFragmentFunction:fragmentProgram];
    
    // enable depth since we're using the depth buffer
    [pipelineStateDescriptor setDepthWriteEnabled: YES];
    _pipelineState = [_device newRenderPipelineStateWithDescriptor:pipelineStateDescriptor error:nil];
    
    MTLDepthStencilDescriptor *depthStateDesc = [[MTLDepthStencilDescriptor alloc] init];
    depthStateDesc.depthCompareFunction = MTLCompareFunctionLess;
    depthStateDesc.depthWriteEnabled = YES;
    _depthState = [_device newDepthStencilStateWithDescriptor:depthStateDesc];
}

- (void)_renderBox:(id <MTLRenderCommandEncoder>)renderEncoder view:(METLView *)view bufferOffset:(uint32_t)offset name:(NSString *)name
{
    [renderEncoder pushDebugGroup:name];
    //  set context state
    [renderEncoder setRenderPipelineState:_pipelineState];
    [renderEncoder setVertexBuffer:_vertexBuffer offset:0 atIndex:0 ];
    [renderEncoder setVertexBuffer:_dynamicConstantBuffer[_constantDataBufferIndex] offset:offset atIndex:1 ];
    
    // tell the render context we want to draw our primitives
    [renderEncoder drawPrimitives:MTLPrimitiveTypeTriangle vertexStart:0 vertexCount:36 instanceCount:1];
    [renderEncoder popDebugGroup];
}

- (void)render:(METLView *)view
{
    dispatch_semaphore_wait(_inflight_semaphore, DISPATCH_TIME_FOREVER);
    
    // prepare assets
    [self _prepareToDraw:view];
    
    // create a new command buffer for each renderpass to the current drawable
    id <MTLCommandBuffer> commandBuffer = [_commandQueue commandBuffer];
    
    // create a render command encoder so we can render into something
    id <MTLRenderCommandEncoder> renderEncoder = [commandBuffer renderCommandEncoderWithFramebuffer:view.currentFramebuffer];
    [renderEncoder setDepthStencilState:_depthState];
    
    [self _renderBox:renderEncoder view:view bufferOffset:0 name:@"Box1"];
    [self _renderBox:renderEncoder view:view bufferOffset:sizeof(METL::uniforms_t) name:@"Box2"];
    
    [renderEncoder endEncoding];
    
    // call the view's completion handler which is required by the view since it will signal its semaphore and set up the next buffer
    __block dispatch_semaphore_t block_sema = _inflight_semaphore;
    [commandBuffer addCompletedHandler:^(id<MTLCommandBuffer> buffer) {
        dispatch_semaphore_signal(block_sema);
    }];
    
    // the renderview assumes it can now increment the buffer index and that the previous index wont be touched
    // until we cycle back around to the same index
    _constantDataBufferIndex = (_constantDataBufferIndex + 1) % kInFlightCommandBuffers;
    
    // schedule a present once the framebuffer is complete
    [commandBuffer addScheduledPresent:view.currentDrawable];
    
    // finalize rendering here. this will push the command buffer to the GPU
    [commandBuffer commit];
}

- (void)_prepareToDraw:(METLView *)view
{
    // load constant buffer data into appropriate buffer at current index
    uint8_t *bufferPointer = (uint8_t *)[_dynamicConstantBuffer[_constantDataBufferIndex] contents];
    
    // 1st box
    memcpy(bufferPointer, &_constant_buffer[0], sizeof(_constant_buffer));
    bufferPointer += sizeof(_constant_buffer);
    
    // 2nd box
    memcpy(bufferPointer, &_constant_buffer[0], sizeof(_constant_buffer));
}

- (void)reshape:(METLView *)view
{
    // when reshape is called, update the view and projection matricies since this means the view orientation or size changed
    float aspect = fabsf(view.bounds.size.width / view.bounds.size.height);
    _projectionMatrix = METL::perspective_fov(kFOVY, aspect, 0.1f, 100.0f);
    _viewMatrix = METL::lookAt(kEye, kCenter, kUp);
}

#pragma mark VIEW CONTROLLER DELEGATE METHODS

- (void)renderViewControllerUpdate:(METLViewController *)controller
{
    simd::float4x4 base_model = METL::translate(0.0f, 0.0f, 5.0f) * METL::rotate(_rotation, 0.0f, 1.0f, 0.0f);
    simd::float4x4 base_mv = _viewMatrix * base_model;
    
    simd::float4x4 modelViewMatrix = METL::translate(0.0f, 0.0f, 1.5f) * METL::rotate(_rotation, 1.0f, 1.0f, 1.0f);
    modelViewMatrix = base_mv * modelViewMatrix;
    _constant_buffer[0].normal_matrix = simd::inverse(simd::transpose(modelViewMatrix));
    _constant_buffer[0].modelview_projection_matrix = _projectionMatrix * modelViewMatrix;
    
    modelViewMatrix = METL::translate(0.0f, 0.0f, -1.5f);
    modelViewMatrix = modelViewMatrix * METL::rotate(_rotation, 1.0f, 1.0f, 1.0f);
    modelViewMatrix = base_mv * modelViewMatrix;
    _constant_buffer[1].normal_matrix = simd::inverse(simd::transpose(modelViewMatrix));
    _constant_buffer[1].modelview_projection_matrix = _projectionMatrix * modelViewMatrix;
    
    // change the color each frame
    // reverse direction if we've reached a boundary
    if (_constant_buffer[1].ambient_color.y >= 0.8) {
        _multiplier = -1;
        _constant_buffer[1].ambient_color.y = 0.79;
    } else if (_constant_buffer[1].ambient_color.y <= 0.2) {
        _multiplier = 1;
        _constant_buffer[1].ambient_color.y = 0.21;
    } else
        _constant_buffer[1].ambient_color.y += _multiplier * 0.01;
    
    _rotation += controller.timeSinceLastDraw * 50.0f;
}

- (void)renderViewController:(METLViewController *)controller willPause:(BOOL)pause
{
    // timer is suspended/resumed
    // Can do any non-rendering related background work here when suspended
}


@end
