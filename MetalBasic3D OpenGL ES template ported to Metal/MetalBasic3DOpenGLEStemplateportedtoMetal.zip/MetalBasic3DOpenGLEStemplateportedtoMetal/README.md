# MetalBasic3D: OpenGL ES template ported to Metal

This example has been ported from the Xcode OpenGL ES template to Metal and includes a geometric math library built on top of the simd.h library. The math library has been created for performing geometric graphics operations within Metal's left hand coordinate system and is used in this sample to set up a basic perspective, look at and model view projection matrix for objects rendered in the scene. Additional effects have been added to one of the spinning cubes from the template to demonstrate altering a single object's uniform values per frame while keeping the other constant, all the while sharing the same buffer in memory. The cube geometry is defined with interlaced vertex and normal data and demonstrates how stride can be read within a shader. 

## Requirements

### Build

iOS 8 SDK

### Runtime

iOS 8 SDK using an A7 device.

Copyright (C) 2014 Apple Inc. All rights reserved.
