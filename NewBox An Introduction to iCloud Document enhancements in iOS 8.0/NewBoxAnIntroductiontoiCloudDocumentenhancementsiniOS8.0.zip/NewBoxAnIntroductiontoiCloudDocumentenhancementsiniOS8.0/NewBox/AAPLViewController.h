/*
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 
  Sample code to present a UIDocumentPickerViewController and a UIDocumentMenuViewController
  
 */

#import <UIKit/UIKit.h>

@interface AAPLViewController : UIViewController <UIDocumentPickerDelegate, UIDocumentMenuDelegate>

@property (strong, nonatomic) NSURL *documentURL;

@end

