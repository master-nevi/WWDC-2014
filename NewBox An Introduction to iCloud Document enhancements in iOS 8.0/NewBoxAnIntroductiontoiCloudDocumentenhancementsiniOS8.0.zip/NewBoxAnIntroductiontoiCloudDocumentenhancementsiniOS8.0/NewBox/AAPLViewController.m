/*
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 
  Sample code to present a UIDocumentPickerViewController and a UIDocumentMenuViewController
  
 */

#import "AAPLViewController.h"
#import <MobileCoreServices/MobileCoreServices.h>


@interface AAPLViewController ()


@end

@implementation AAPLViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //TODO: Developer should reference document in iCloud Container. This is given as an example document
    self.documentURL = [[NSBundle mainBundle] URLForResource:@"TestUIDocument_0" withExtension:@"txt"];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)importFromDocPicker:(id)sender {
    UIDocumentPickerViewController *vc = [[UIDocumentPickerViewController alloc] initWithDocumentTypes:@[(NSString *)kUTTypeRTF,(NSString *)kUTTypePNG,(NSString *)kUTTypeText,(NSString *)kUTTypePlainText,(NSString *)kUTTypePDF, (NSString *)kUTTypeImage] inMode:UIDocumentPickerModeImport];
    vc.delegate = self;
    [self presentViewController:vc animated:YES completion:^{}];
}

- (IBAction)openDocPicker:(id)sender {
    UIDocumentPickerViewController *vc = [[UIDocumentPickerViewController alloc] initWithDocumentTypes:@[(NSString *)kUTTypeRTF,(NSString *)kUTTypePNG,(NSString *)kUTTypeText,(NSString *)kUTTypePlainText,(NSString *)kUTTypePDF, (NSString *)kUTTypeImage] inMode:UIDocumentPickerModeOpen];
    vc.delegate = self;
    [self presentViewController:vc animated:YES completion:^{}];
}

- (IBAction)exportToDocPicker:(id)sender {
    UIDocumentPickerViewController *vc = [[UIDocumentPickerViewController alloc] initWithURL:self.documentURL inMode:UIDocumentPickerModeExportToService];
    vc.delegate = self;
    [self presentViewController:vc animated:YES completion:^{}];
}

- (IBAction)moveToDocPicker:(id)sender {
    UIDocumentPickerViewController *vc = [[UIDocumentPickerViewController alloc] initWithURL:self.documentURL inMode:UIDocumentPickerModeMoveToService];
    vc.delegate = self;
    [self presentViewController:vc animated:YES completion:^{}];
}

#pragma mark - DocumentPicker Delegate Methods
- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentAtURL:(NSURL *)url {
    BOOL startAccessingWorked = [url startAccessingSecurityScopedResource];
    NSURL *ubiquityURL = [[NSFileManager defaultManager] URLForUbiquityContainerIdentifier:nil];
    NSLog(@"ubiquityURL %@",ubiquityURL);
    NSLog(@"start %d",startAccessingWorked);
    
    NSFileCoordinator *fileCoordinator = [[NSFileCoordinator alloc] init];
    NSError *error;
    [fileCoordinator coordinateReadingItemAtURL:url options:0 error:&error byAccessor:^(NSURL *newURL) {
        NSData *data = [NSData dataWithContentsOfURL:newURL];
        NSLog(@"error %@",error);
        NSLog(@"data %@",data);
    }];
    [url stopAccessingSecurityScopedResource];
    
}

- (void)documentPickerWasCancelled:(UIDocumentPickerViewController *)controller {
}

#pragma mark - DocumentMenu Methods
- (IBAction)importFromDocMenu:(id)sender {
    UIDocumentMenuViewController *vc = [[UIDocumentMenuViewController alloc] initWithDocumentTypes:@[(NSString *)kUTTypeRTF,(NSString *)kUTTypePNG,(NSString *)kUTTypeText,(NSString *)kUTTypePlainText,(NSString *)kUTTypePDF, (NSString *)kUTTypeImage] inMode:UIDocumentPickerModeImport];
    vc.delegate = self;
    [vc addOptionWithTitle:@"New Document" image:nil order:UIDocumentMenuOrderFirst handler:^{
        NSLog(@"completionHandler Hit");
    }];
    
    vc.modalPresentationStyle = UIModalPresentationPopover;
    [self presentViewController:vc animated:YES completion:^{}];
    UIPopoverPresentationController *presentationPopover = [vc popoverPresentationController];
    vc.popoverPresentationController.sourceView = [self view];
    presentationPopover.permittedArrowDirections = UIPopoverArrowDirectionDown;
    presentationPopover.sourceRect = [(UIButton *)sender frame];
    
    
}

- (IBAction)openDocMenu:(id)sender {
    UIDocumentMenuViewController *vc = [[UIDocumentMenuViewController alloc] initWithDocumentTypes:@[(NSString *)kUTTypeRTF,(NSString *)kUTTypePNG,(NSString *)kUTTypeText,(NSString *)kUTTypePlainText,(NSString *)kUTTypePDF, (NSString *)kUTTypeImage] inMode:UIDocumentPickerModeOpen];
    vc.delegate = self;
    [vc addOptionWithTitle:@"New Document" image:nil order:UIDocumentMenuOrderFirst handler:^{
        NSLog(@"completionHandler Hit");
    }];
    
    vc.modalPresentationStyle = UIModalPresentationPopover;
    [self presentViewController:vc animated:YES completion:^{}];
    UIPopoverPresentationController *presentationPopover = [vc popoverPresentationController];
    vc.popoverPresentationController.sourceView = [self view];
    presentationPopover.permittedArrowDirections = UIPopoverArrowDirectionDown;
    presentationPopover.sourceRect = [(UIButton *)sender frame];
}

- (IBAction)exportToDocMenu:(id)sender {
    UIDocumentMenuViewController *vc = [[UIDocumentMenuViewController alloc] initWithURL:self.documentURL inMode:UIDocumentPickerModeExportToService];
    vc.delegate = self;
    [vc addOptionWithTitle:@"New Document" image:nil order:UIDocumentMenuOrderLast handler:^{
        NSLog(@"completionHandler Hit");
    }];
    
    vc.modalPresentationStyle = UIModalPresentationPopover;
    [self presentViewController:vc animated:YES completion:^{}];
    UIPopoverPresentationController *presentationPopover = [vc popoverPresentationController];
    vc.popoverPresentationController.sourceView = [self view];
    presentationPopover.permittedArrowDirections = UIPopoverArrowDirectionDown;
    presentationPopover.sourceRect = [(UIButton *)sender frame];
}

- (IBAction)moveToDocMenu:(id)sender {
    UIDocumentMenuViewController *vc = [[UIDocumentMenuViewController alloc] initWithURL:self.documentURL inMode:UIDocumentPickerModeMoveToService];
    vc.delegate = self;
    [vc addOptionWithTitle:@"New Document" image:nil order:UIDocumentMenuOrderLast handler:^{
        NSLog(@"completionHandler Hit");
    }];
    
    vc.modalPresentationStyle = UIModalPresentationPopover;
    [self presentViewController:vc animated:YES completion:^{}];
    UIPopoverPresentationController *presentationPopover = [vc popoverPresentationController];
    vc.popoverPresentationController.sourceView = [self view];
    presentationPopover.permittedArrowDirections = UIPopoverArrowDirectionDown;
    presentationPopover.sourceRect = [(UIButton *)sender frame];
}

#pragma mark - DocMenu Delegate Methods
- (void)documentMenu:(UIDocumentMenuViewController *)documentMenu didPickDocumentPicker:(UIDocumentPickerViewController *)documentPicker{
    documentPicker.delegate = self;
    [self presentViewController:documentPicker animated:YES completion:^{}];
}

- (void)documentMenuWasDismissed:(UIDocumentMenuViewController *)documentMenu{
    
}

@end
