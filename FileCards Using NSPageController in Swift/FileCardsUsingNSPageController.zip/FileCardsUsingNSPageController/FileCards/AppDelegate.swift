
/*
Copyright (C) 2014 Apple Inc. All Rights Reserved.
See LICENSE.txt for this sample’s licensing information

Abstract:

Application delegate.

*/


import Cocoa

class AppDelegate : NSObject, NSApplicationDelegate {

    @IBOutlet var window: NSWindow
    @IBOutlet var pageController: NSPageController
    @IBOutlet var tableView: NSTableView


    var displayItems = DisplayItem[]()

    /**
    Set up an array of DisplayItem instances to represent the contents of the /Application directory.
    */
    func applicationDidFinishLaunching(aNotification : NSNotification) {

        let fileManager = NSFileManager.defaultManager()

        let appsDirectoryURLs = fileManager.URLsForDirectory(.ApplicationDirectory, inDomains: .SystemDomainMask)
        let appsDirectoryURL = appsDirectoryURLs[0] as NSURL

        let propertyKeys = [NSURLLocalizedNameKey, NSURLEffectiveIconKey, NSURLIsPackageKey, NSURLTypeIdentifierKey]

        let URLs = fileManager.contentsOfDirectoryAtURL(appsDirectoryURL, includingPropertiesForKeys:propertyKeys, options:.SkipsHiddenFiles, error:nil)

        for URL in URLs as NSURL[] {

            let displayItem = DisplayItem(URL: URL)
            displayItems.append(displayItem)
        }

        // Select the first card on the list.
        if displayItems.count > 0 {
            pageController.arrangedObjects = displayItems
            tableView.selectRowIndexes(NSIndexSet(index: 0), byExtendingSelection:false)
        }
    }


    /**
    Update the transition style from a popup menu.
    */
    @IBAction func takeTransitionStyleFrom(sender: NSButton) {

        if let transitionStyle = NSPageControllerTransitionStyle.fromRaw(sender.selectedTag()) {

            pageController.transitionStyle = transitionStyle
        }
    }


    /**
    Animate to the new selection.
    */
    func tableViewSelectionDidChange(aNotification: NSNotification) {

        let selectedIndex = tableView.selectedRow

        if (selectedIndex >= 0) && (selectedIndex != pageController.selectedIndex) {

            /*
            Because we are performing the animation manually, the pageControllerDidEndLiveTransition method will not be called--we must call completeTransition when the animation completes.
            */
            let animator = pageController.animator()

            let animationGroup: ((NSAnimationContext!) -> Void) = { _ in
                animator.selectedIndex = selectedIndex
                self.pageController.selectedIndex = selectedIndex
            }

            NSAnimationContext.runAnimationGroup(animationGroup, completionHandler: {
                self.pageController.completeTransition()
            })
        }
    }


    /**
    Update the table view selection and tell the page controller to complete the transition and display the updated card.
    */
    func pageControllerDidEndLiveTransition(pageController: NSPageController) {

        let indexSet = NSIndexSet(index:pageController.selectedIndex)
        tableView.selectRowIndexes(indexSet, byExtendingSelection:false)

        pageController.completeTransition()
    }


    /**
    Required method for BookUI mode of NSPageController.
    */
    func pageController(pageController: NSPageController, identifierForObject obj: AnyObject) -> String {

        /*
        If the URL represents an application, show the AppCard, otherwise show the DirectoryCard.
        */
        if let appRep = obj as? DisplayItem {
            if appRep.typeIdentifier == "com.apple.application-bundle" {
                return "AppCard"
            }
        }
        return "DirectoryCard"
    }


    /**
    Required method for BookUI mode of NSPageController.
    */
    func pageController(pageController: NSPageController, viewControllerForIdentifier identifier: String) -> NSViewController {

        return NSViewController(nibName:identifier, bundle:nil)
    }


    /**
    Optional NSPageController delegate method used to inset the card from its parent view.
    */
    func pageController(pageController: NSPageController, frameForObject: AnyObject) -> NSRect {
        
        let inset: CGFloat = 5.0
        let bounds = pageController.view.bounds
        return NSInsetRect(bounds, inset, inset)
    }
}

