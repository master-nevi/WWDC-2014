
/*
Copyright (C) 2014 Apple Inc. All Rights Reserved.
See LICENSE.txt for this sample’s licensing information

Abstract:

Object to represent an item in the filesystem.

*/


import Cocoa


class DisplayItem : NSObject {


    let URL: NSURL


    var name: String! {
        let resourceValues = URL.resourceValuesForKeys([NSURLNameKey], error: nil)
        return resourceValues[NSURLNameKey] as? String
    }


    var localizedName: String! {
        let resourceValues = URL.resourceValuesForKeys([NSURLLocalizedNameKey], error: nil)
        return resourceValues[NSURLLocalizedNameKey] as? String
    }


    var icon: NSImage! {
        let resourceValues = URL.resourceValuesForKeys([NSURLEffectiveIconKey], error: nil)
        return resourceValues[NSURLEffectiveIconKey] as? NSImage
    }


    var dateOfCreation: NSDate! {
        let resourceValues = self.URL.resourceValuesForKeys([NSURLCreationDateKey], error: nil)
        return resourceValues[NSURLCreationDateKey] as? NSDate
    }


    var dateOfLastModification: NSDate! {
        let resourceValues = URL.resourceValuesForKeys([NSURLContentModificationDateKey], error: nil)
        return resourceValues[NSURLContentModificationDateKey] as? NSDate
    }


    var typeIdentifier: String! {
        let resourceValues = URL.resourceValuesForKeys([NSURLTypeIdentifierKey], error: nil)
        return resourceValues[NSURLTypeIdentifierKey] as? String
    }

    
    init (URL: NSURL) {
        self.URL = URL
    }
}
