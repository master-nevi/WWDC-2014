
/*
Copyright (C) 2014 Apple Inc. All Rights Reserved.
See LICENSE.txt for this sample’s licensing information

Abstract:

Application delegate.

*/


import Cocoa

class CardBackgroundView : NSView {

    override var opaque: Bool {
        return false
    }


    override func drawRect(dirtyRect: NSRect) {

        NSColor.whiteColor().set()

        let bezierPath = NSBezierPath(roundedRect:self.bounds, xRadius:5, yRadius:5)
        bezierPath.lineWidth = 1.0
        bezierPath.fill()
    }


    override func menuForEvent(event: NSEvent) -> NSMenu? {
        return nil
    }
}
