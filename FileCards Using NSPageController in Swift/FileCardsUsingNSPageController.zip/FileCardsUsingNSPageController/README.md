# FileCards: Using NSPageController

"FileCards" demonstrates how to use of NSPageController, displaying the contents of the Applications directory. You can swipe, click the arrow buttons or click on the entry in the table to switch between cards.


## Requirements

### Build

Xcode 6.0 or later, OS X 10.9 or later

### Runtime

OS X 10.9 or later

----
Copyright (C) 2014 Apple Inc. All rights reserved.
