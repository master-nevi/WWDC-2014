
/*
Copyright (C) 2014 Apple Inc. All Rights Reserved.
See LICENSE.txt for this sample’s licensing information

Abstract:

View controller to manage a a table view that displays a collection of quakes.

When requested (by clicking the Fetch Quakes button), the controller creates an asynchronous NSURLSession task to retrieve JSON data about earthquakes. Earthquake data are compared with any existing managed objects to determine whether there are new quakes. New managed objects are created to represent new data, and saved to the persistent store on a private queue.

*/


import Cocoa

class QuakesViewController : NSViewController, NSTableViewDataSource, NSTableViewDelegate {

    @IBOutlet var tableView: NSTableView
    @IBOutlet var fetchQuakesButton: NSButton

    var quakes = Quake[]()


    override func viewDidLoad(){

        reloadTableView(self)
    }


    @IBAction func fetchQuakes(sender: AnyObject) {

        // Ensure the button can't be pressed again until the fetch is complete.
        fetchQuakesButton.enabled = false

        // Create an NSURLSession and then session task to contact the earthquake server and retrieve JSON data.
        let jsonURL = NSURL.URLWithString("http://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_month.geojson")

        let sessionConfiguration = NSURLSessionConfiguration.ephemeralSessionConfiguration()
        let session = NSURLSession(configuration: sessionConfiguration)

        let task = session.dataTaskWithURL(jsonURL, completionHandler: {(data: NSData!, response: NSURLResponse!, error: NSError!) in

            if !data {
                println("Error connecting: \(error.localizedDescription)")
                fatalError("Couldn't create connection to server")
                return
            }

            var anyError: NSError?

            let jsonDictionary = NSJSONSerialization.JSONObjectWithData(data, options: NSJSONReadingOptions(0), error: &anyError) as? NSDictionary

            if !jsonDictionary {
                println("Error creating JSON dictionary: \(anyError!.localizedDescription)")
                fatalError("Couldn't create JSON dictionary")
                return
            }

            /*
            Set up a new Core Data stack to deal with the data.
            It uses the same store and model, but a new persistent store coordinator and context.
            */
            let mainCoordinator = self.managedObjectContext.persistentStoreCoordinator

            let localCoordinator = NSPersistentStoreCoordinator(managedObjectModel:mainCoordinator.managedObjectModel)

            let store = mainCoordinator.persistentStores[0] as NSPersistentStore
            let storeURL = store.URL

            if !localCoordinator.addPersistentStoreWithType(NSSQLiteStoreType, configuration:nil, URL:storeURL, options:nil, error:&anyError) {
                println("Error adding persistent store: \(anyError!.localizedDescription)")
                fatalError("Couldn't add persistent store")
                return
            }

            /*
            Create a context on a private queue to:
            * Fetch existing quakes to compare with incoming data
            * Create new quakes as required
            */
            let localContext = NSManagedObjectContext(concurrencyType: .PrivateQueueConcurrencyType)
            localContext.persistentStoreCoordinator = localCoordinator
            localContext.undoManager = nil

            /*
            Sort the dictionaries by code; this way they can be compared in parallel with existing quakes.
            */
            var results = jsonDictionary!["features"] as NSArray
            results = results.sortedArrayUsingDescriptors([NSSortDescriptor(key:"properties.code", ascending:true)])

            let batchSize = 50
            let count = results.count

            var numBatches = count / batchSize
            numBatches += count % batchSize > 0 ? 1 : 0

            var batchNumber: Int

            for batchNumber = 0; batchNumber < numBatches; batchNumber++ {

                let range = NSMakeRange(batchNumber * batchSize, min(batchSize, count - batchNumber * batchSize))
                let subResults = results.subarrayWithRange(range) as NSArray

                /*
                Create a request to fetch existing quakes with the same codes as those in the JSON data.
                Existing quakes will be updated with new data; if there isn't a match, then create a new quake to represent the event.
                */
                let matchingQuakeRequest = NSFetchRequest(entityName:"Quake")

                let codes = subResults.valueForKeyPath("properties.code") as NSArray

                matchingQuakeRequest.predicate = NSPredicate(format:"code in %@", codes)
                matchingQuakeRequest.sortDescriptors = [NSSortDescriptor(key: "code", ascending:true)]

                let matchingQuakes: NSArray! = localContext.executeFetchRequest(matchingQuakeRequest, error:&anyError)
                if !matchingQuakes {
                    println("Error fetching: \(anyError!.localizedDescription)")
                    fatalError("Fetch failed")
                    return
                }

                let matchingQuakeEnumerator = matchingQuakes.objectEnumerator()
                var quakeOptional = matchingQuakeEnumerator.nextObject() as? Quake

                for quakeDictionary: NSDictionary! in subResults {

                    let properties = quakeDictionary["properties"] as NSDictionary
                    var isUpdate = false
                    let code = properties["code"] as String

                    var quake: Quake

                    if let quakeTest = quakeOptional as? Quake {

                        if code == quakeTest.code {
                            isUpdate = true
                        }
                    }

                    if isUpdate {
                        quake = quakeOptional!
                        quakeOptional = matchingQuakeEnumerator.nextObject() as? Quake
                    } else {
                        quake = NSEntityDescription.insertNewObjectForEntityForName("Quake", inManagedObjectContext:localContext) as Quake
                    }

                    if let code = properties["code"] as? String {
                        quake.code = code
                    }
                    if let magnitude = properties["mag"] as? NSNumber {
                        quake.magnitude = magnitude
                    }
                    if let placeName = properties["place"] as? String {
                        quake.placeName = placeName
                    }
                    if let tsunami = properties["tsunami"] as? NSNumber {
                        quake.tsunami = tsunami.boolValue
                    }
                    if let detail = properties["detail"] as? String {
                        quake.detailURL = detail
                    }
                    if let time = properties["time"] as? NSNumber {
                        let timeInterval = time.doubleValue / 1000.0
                        quake.time = NSDate(timeIntervalSince1970:timeInterval)
                    }

                    if let geometry = properties["geometry"] as? NSDictionary {

                        let coordinates = geometry["coordinates"] as NSArray

                        var coordNumber = 0
                        for number: NSNumber! in coordinates {

                            var key: String
                            switch coordNumber {
                            case 0:
                                key = "longitude"
                            case 1:
                                key = "latitude"
                            case 2:
                                key = "depth"
                            default:
                                fatalError("Unexpected key in geometry coordinates")
                            }
                            quake.setValue(number, forKey:key)
                            coordNumber++
                        }
                    }
                }

                if !localContext.save(&anyError) {
                    println("Error saving batch: \(anyError!.localizedDescription)")
                    fatalError("Saving batch failed")
                    return
                }

                localContext.reset()
            }

            /*
            Bounce back to the main queue to reload the table view and reenable the fetch button.
            */
            NSOperationQueue.mainQueue().addOperationWithBlock {
                self.reloadTableView(nil)
                self.fetchQuakesButton.enabled = true
            }
        })

        task.resume()
    }


    /**
    Fetch quakes ordered in time and reload the table view.
    */
    @IBAction func reloadTableView(sender: AnyObject?) {

        let request = NSFetchRequest(entityName:"Quake")
        request.sortDescriptors = [NSSortDescriptor(key: "time", ascending:false)]

        var anyError: NSError?

        let fetchedQuakes = managedObjectContext.executeFetchRequest(request, error:&anyError)
        if !fetchedQuakes {
            println("Error fetching: \(anyError!.localizedDescription)")
            fatalError("Fetch failed")
            return
        }

        quakes = fetchedQuakes as Quake[]

        tableView.reloadData()
    }


    func numberOfRowsInTableView(tableView: NSTableView?) -> Int {

        return quakes.count
    }


    func tableView(tableView: NSTableView?, viewForTableColumn tableColumn: NSTableColumn?, row: Int) -> NSView? {

        var returnView: NSView? = nil
        let identifier = tableColumn!.identifier

        if let propertyEnum = QuakeDisplayProperty.fromRaw(identifier) {

            let cellView = tableView!.makeViewWithIdentifier(identifier, owner:self) as NSTableCellView

            let quake = quakes[row]

            switch propertyEnum {

            case .Place:
                cellView.textField.stringValue = quake.placeName
            case .Time:
                cellView.textField.objectValue = quake.time
            case .Magnitude:
                cellView.textField.objectValue = quake.magnitude
            }
            
            returnView = cellView
        }
        
        return returnView
    }
    
    
    /**
    Returns the managed object context for the view controller (which is bound to the persistent store coordinator for the application).
    */
    @lazy var managedObjectContext: NSManagedObjectContext = {
        let moc = NSManagedObjectContext(concurrencyType: .MainQueueConcurrencyType)
        moc.persistentStoreCoordinator = CoreDataStackManager.sharedInstance.persistentStoreCoordinator
        return moc
    }()
    
}

enum QuakeDisplayProperty : String {
    case Place = "placeName"
    case Time = "time"
    case Magnitude = "magnitude"
}
