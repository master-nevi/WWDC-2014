
/*
Copyright (C) 2014 Apple Inc. All Rights Reserved.
See LICENSE.txt for this sample’s licensing information

Abstract:

Managed object class for the Quake entity.

*/


import Foundation
import CoreData


@objc class Quake : NSManagedObject {

   @NSManaged var magnitude: NSNumber
   @NSManaged var placeName: String
   @NSManaged var time: NSDate
   @NSManaged var tsunami: Bool
   @NSManaged var longitude: Float
   @NSManaged var latitude: Float
   @NSManaged var depth: Float
   @NSManaged var detailURL: String
   @NSManaged var code: String
}



