# Using a second Core Data stack to fetch data in background

Earthquakes shows how to use a second Core Data stack to fetch data on a background queue.

## Requirements

### Build

Xcode 6.0 or later, OS X v10.10 SDK or later.

### Runtime

OS X v10.9 or later.

----
Copyright (C) 2014 Apple Inc. All rights reserved.
