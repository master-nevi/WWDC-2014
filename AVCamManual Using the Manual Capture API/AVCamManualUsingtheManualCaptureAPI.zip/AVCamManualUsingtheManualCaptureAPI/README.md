# AVCamManual: Using the Manual Capture API

AVCamManual adds manual controls for focus, exposure, and white balance to the AVCam sample application.

## Requirements

### Build

iOS 8 SDK

### Runtime

iOS 8 or later

Copyright (C) 2014 Apple Inc. All rights reserved.
